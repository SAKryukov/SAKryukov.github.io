﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Enumeration Editor Demo")]
[assembly: AssemblyDescription("Demo application of the editors for PropertyGrid: EnumerationEditor, BitwiseEnumerationEditor")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("Enumeration Editor Demo")]
[assembly: AssemblyCopyright("Copyright © 2014, 2017, Sergey A Kryukov")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("c1f6ba96-1d9d-4318-b097-e6f32fd56001")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
