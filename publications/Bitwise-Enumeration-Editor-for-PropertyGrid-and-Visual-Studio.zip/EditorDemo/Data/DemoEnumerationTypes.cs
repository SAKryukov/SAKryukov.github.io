﻿namespace EnumerationEditorDemo {
    using FlagsAttribute = System.FlagsAttribute;
    using EditorAttribute = System.ComponentModel.EditorAttribute;
    using TypeConverterAttribute = System.ComponentModel.TypeConverterAttribute;
    using DisplayNameAttribute = SA.Universal.Enumerations.DisplayNameAttribute;
    using DescriptionAttribute = SA.Universal.Enumerations.DescriptionAttribute;
    using AbbreviationAttribute = SA.Universal.Enumerations.AbbreviationAttribute;
    using EnumerationEditor = SA.Universal.Enumerations.UI.EnumerationEditor;
    using BitwiseEnumerationEditor = SA.Universal.Enumerations.UI.BitwiseEnumerationEditor;
    using UITypeEditor = System.Drawing.Design.UITypeEditor;
    using NonEnumerableAttribute = SA.Universal.Enumerations.NonEnumerableAttribute;
    using SA.Universal.Enumerations.UI;

    [Editor(typeof(BitwiseEnumerationEditor), typeof(UITypeEditor))]
    [DisplayName(typeof(Data.DisplayNames)), Description(typeof(Data.Descriptions))]
    [Flags]
	public enum FeatureSet : byte {
        [NonEnumerable]
        None = 0,
        AutoCenterX = 1 << 0,
        AutoCenterY = 1 << 2,
        Border = 1 << 3,
        [Abbreviation(6)]
        TransparentBackground = 1 << 4,
        [Abbreviation(11)]
        BackgroundImage = 1 << 5,
        [NonEnumerable]
        Center = AutoCenterX | AutoCenterY,
        [NonEnumerable]
        All = AutoCenterX | AutoCenterY | Border | TransparentBackground | BackgroundImage,
    } //enum FeatureSet

    [Editor(typeof(EnumerationEditor), typeof(UITypeEditor))]
    [DisplayName(typeof(Data.DisplayNames)), Description(typeof(Data.Descriptions))]
    public enum Position {
        SoftwareArchitect,
        PrincipalSoftwareEngineer,
        TeamLeader,
        TechnicalLead,
        SeniorSoftwareEngineer,
        SoftwareEngineer,
        JuniorSoftwareEngineer,
    } //enum Position

} //namespace EnumerationEditorDemo
