﻿namespace EnumerationEditorDemo {
    partial class FormMain {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
			this.splitter = new System.Windows.Forms.Splitter();
			this.propertyGrid = new System.Windows.Forms.PropertyGrid();
			this.testControl = new EnumerationEditorDemo.UI.TestControl();
			this.SuspendLayout();
			// 
			// splitter
			// 
			this.splitter.Location = new System.Drawing.Point(107, 0);
			this.splitter.Name = "splitter";
			this.splitter.Size = new System.Drawing.Size(17, 458);
			this.splitter.TabIndex = 1;
			this.splitter.TabStop = false;
			// 
			// propertyGrid
			// 
			this.propertyGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.propertyGrid.Location = new System.Drawing.Point(124, 0);
			this.propertyGrid.Name = "propertyGrid";
			this.propertyGrid.Size = new System.Drawing.Size(487, 458);
			this.propertyGrid.TabIndex = 2;
			this.propertyGrid.ToolbarVisible = false;
			// 
			// testControl
			// 
			this.testControl.BackColor = System.Drawing.Color.Gold;
			this.testControl.Dock = System.Windows.Forms.DockStyle.Left;
			this.testControl.FeatureSet = ((EnumerationEditorDemo.FeatureSet)((EnumerationEditorDemo.FeatureSet.AutoCenterY | EnumerationEditorDemo.FeatureSet.TransparentBackground)));
			this.testControl.Location = new System.Drawing.Point(0, 0);
			this.testControl.Name = "testControl";
			this.testControl.Position = EnumerationEditorDemo.Position.SoftwareArchitect;
			this.testControl.Size = new System.Drawing.Size(107, 458);
			this.testControl.TabIndex = 0;
			// 
			// FormMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(611, 458);
			this.Controls.Add(this.propertyGrid);
			this.Controls.Add(this.splitter);
			this.Controls.Add(this.testControl);
			this.Name = "FormMain";
			this.ResumeLayout(false);

        }

        #endregion

        private EnumerationEditorDemo.UI.TestControl testControl;
        private System.Windows.Forms.Splitter splitter;
        private System.Windows.Forms.PropertyGrid propertyGrid;
    }
}

