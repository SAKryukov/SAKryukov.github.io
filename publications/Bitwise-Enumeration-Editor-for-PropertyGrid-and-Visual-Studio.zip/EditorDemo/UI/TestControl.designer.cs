﻿namespace EnumerationEditorDemo.UI {
    using System.Windows.Forms;
    using System.ComponentModel;

    public partial class TestControl : Control {
        const string DemoCategogy = "Demo";
        [Category(DemoCategogy)]
        [DisplayName("Feature Set")]
        public FeatureSet FeatureSet { get; set; }
        [Category(DemoCategogy)]
        [DisplayName("Software Engineering Position")]
        public Position Position { get; set; }
    } //class TestControl

} //EnumerationEditorDemo.UI
