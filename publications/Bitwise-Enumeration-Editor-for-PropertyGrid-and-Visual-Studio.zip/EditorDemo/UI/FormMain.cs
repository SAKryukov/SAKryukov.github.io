﻿namespace EnumerationEditorDemo {
    using System;
    using System.Windows.Forms;   

    public partial class FormMain : Form {
        
        public FormMain() {
            InitializeComponent();
            Text = Application.ProductName;
            Application.ThreadException += (sender, eventArgs) => {
                MessageBox.Show(
                    string.Format("{0}:\n\n{1}", eventArgs.Exception.GetType().FullName, eventArgs.Exception.Message),
                    Application.ProductName,
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }; 
            this.propertyGrid.SelectedObject = this.testControl;
            this.testControl.Visible = DesignMode;
            this.splitter.Visible = DesignMode;
        } //FormMain

        [STAThread]
        static void Main() {
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormMain());
        } //Main

    } //class FormMain

} //namespace EditorDemo
