/*

Named C++ Function Parameters, Yet Another Approach

Copyright (C) 2017 by Sergey A Kryukov0
http://www.SAKryukov.org
http://www.codeproject.com/Members/SAKryukov

CPOL license:
https://en.wikipedia.org/wiki/CPOL
http://www.codeproject.com/info/cpol10.aspx

Original publication:
https://www.codeproject.com/Articles/1171605/Named-Cpp-Function-Parameters

*/

#pragma once
#include "NamedParameters.h"
#include "NamedParametersWriteonly.h"
#include <iostream>

class FreeReadSample {
public:
	Named::Parameter<int> ip;
	Named::Parameter<double> dp;
	void A(int a, Named::Parameter<void>*, double b) {}
}; //class FreeReadSample

class RestrictedReadSample {
public:
	RestrictedReadSample() { assign(0, 0); }
	Named::Parameter<int> ip;
	Named::Parameter<double> dp;
	void A(int a, Named::Parameter<void>*, double b) {
		assign(a, b);
	} //A
	void ShowAssignmentResult() {
		printf("Parameter a: %d; parameter ip: %d; parameter dp: %g; parameter b: %g\n",
			aValue, ipValue, dpValue, bValue);
	} //ShowAssignmentResult
private:
	int ipValue, aValue;
	double dpValue, bValue;
	void assign(int a, double b) {
		aValue = a;
		bValue = b;
		ipValue = ip;
		dpValue = dp;
		ip.unassign();
		dp.unassign();
	} //assign
}; //class RestrictedReadSample

class PrivateReadSample {
public:
	NamedWriteonly::Parameter<int, PrivateReadSample> ip;
	NamedWriteonly::Parameter<double, PrivateReadSample> dp;
	void A(int a, NamedWriteonly::Parameter<void>*, double b) {
		aValue = a;
		bValue = b;
		ipValue = ip;
		dpValue = dp;
	} //A
	void ShowAssignmentResult() {
		printf("Parameter a: %d; parameter ip: %d; parameter dp: %g; parameter b: %g\n",
			aValue, ipValue, dpValue, bValue);
	} //ShowAssignmentResult
private:
	int ipValue, aValue;
	double dpValue, bValue;
}; //class PrivateReadSample

class NamedParametersDemo {
public:
	void Run() {
		printf("Restricted-read (exception-based) named function parameters:\n\n");
		DemoNamed();
		printf("\nPrivate-read (in parametrized friend class, presumably declaring class)\nnamed function parameters:\n\n");
		DemoPrivateRead();
	} //Run
private:
	void DemoNamed() {
		FreeReadSample s;
		s.dp = 0.13; //comment out this line to get exception:
		try {
			double value = s.dp;
			printf("Parameter dp before passing to A: %g\n", value);
		} catch(decltype(s.dp)::unassigned_named_parameter&) {
			printf("Named parameter s.dp not assigned\n");
		} //exception
		s.A(1, (s.ip = 2, s.dp = 3.3), 4.4);
		double value = s.dp;
		printf("Parameter dp after passing to A: %g\n", value);
		RestrictedReadSample rs;
		rs.A(5, (rs.ip = 6, rs.dp = 7.7), 8.8);
		rs.ShowAssignmentResult();
		try {
			value = rs.dp;
			printf("Parameter dp after passing to A: %g\n", value);
		} catch(decltype(s.dp)::unassigned_named_parameter&) {
			printf("Named parameter rs.dp not assigned\n");
		} //exception
	} //DemoNamed
	void DemoPrivateRead() {
		PrivateReadSample ps;
		ps.A(9, (ps.ip = 10, ps.dp = 11.11), 12.12);
		ps.ShowAssignmentResult();
	} //DemoPrivateRead
}; /* class NamedParametersDemo */
