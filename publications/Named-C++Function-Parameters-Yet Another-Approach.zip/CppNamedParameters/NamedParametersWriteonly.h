/*

Named C++ Function Parameters, Yet Another Approach

Copyright (C) 2017 by Sergey A Kryukov0
http://www.SAKryukov.org
http://www.codeproject.com/Members/SAKryukov

CPOL license:
https://en.wikipedia.org/wiki/CPOL
http://www.codeproject.com/info/cpol10.aspx

Original publication:
https://www.codeproject.com/Articles/1171605/Named-Cpp-Function-Parameters

*/

#pragma once

namespace NamedWriteonly {

	template <typename T, typename OWNER = void>
	class Parameter {
	public:

		Parameter<void>* operator =(const T &value) {
			this->value = value;
			return nullptr;
		} //operator =

	private:

		operator T() const {
			return value;
		} //operator T()

		T value;
		friend OWNER; // since C++11

	}; //class Parameter

	// This specialization is just a guard against members/variables like
	// NamedWriteOnly::Parameter<void> parameter;
	template<> class Parameter<void> {};

} /* namespace NamedWriteOnly */