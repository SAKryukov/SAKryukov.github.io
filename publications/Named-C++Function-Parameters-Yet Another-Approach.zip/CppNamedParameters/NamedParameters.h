/*

Named C++ Function Parameters, Yet Another Approach

Copyright (C) 2017 by Sergey A Kryukov0
http://www.SAKryukov.org
http://www.codeproject.com/Members/SAKryukov

CPOL license:
https://en.wikipedia.org/wiki/CPOL
http://www.codeproject.com/info/cpol10.aspx

Original publication:
https://www.codeproject.com/Articles/1171605/Named-Cpp-Function-Parameters

*/

#pragma once
#include <stdexcept>

namespace Named {

	template <typename T>
	class Parameter {
	public:

		Parameter<void>* operator =(const T &value) {
			this->value = value;
			assigned = true;
			return nullptr;
		} //operator =

		operator T() const {
			if (!assigned)
				throw unassigned_named_parameter();
			return value;
		} //operator T()

		void unassign() { assigned = false; }

		struct unassigned_named_parameter : private std::logic_error {
			unassigned_named_parameter() : std::logic_error(std::string()) {}
		}; //unassigned_named_parameter

	private:

		T value;
		bool assigned = false;

	}; //class Parameter

	// This specialization is just a guard against members like
	// Named::Parameter<void> parameter;
	template<> class Parameter<void> {};

} /* namespace Named */