/*

Named C++ Function Parameters, Yet Another Approach

Copyright (C) 2017 by Sergey A Kryukov0
http://www.SAKryukov.org
http://www.codeproject.com/Members/SAKryukov

CPOL license:
https://en.wikipedia.org/wiki/CPOL
http://www.codeproject.com/info/cpol10.aspx

Original publication:
https://www.codeproject.com/Articles/1171605/Named-Cpp-Function-Parameters

*/

#pragma once
#include <cmath>
// naive:

template <typename T>
class NamedParameter {
public:

	NamedParameter<void>* operator =(const T &value) {
		this->value = value;
		return nullptr;
	} //operator =

	operator T() const {
		return value;
	} //operator T()

private:

	T value;

}; //class NamedParameter

// naive code sample:

class Sample {
public:

	Sample() { setDefaults(); }

	NamedParameter<int> ip;

	NamedParameter<double> dp;
	void A(int a, double b, NamedParameter<void>*) {
		// use parameters...
		setDefaults();
	} //A
	void B(int a, NamedParameter<void>*, double b) {
		// use parameters...
		setDefaults();
	} //B

private:

	int defaultIp = 0;
	double defaultDp = acos(-1);
	void setDefaults() {
		ip = defaultIp;
		dp = defaultDp;
	} //setDefaults

public:

	static void Demo() {
		Sample s;
		// positional and named parameters can be mixed:
		s.A(1, 2.2, (s.ip = 3, s.dp = 4.4));
		// the order of named actual arguments doesn't matter:
		s.A(1, 2.2, (s.dp = 4.4, s.ip = 3));
		// ... and they don't need to be at the end:
		s.B(5, (s.dp = 6.6, s.ip = 7), 8.8);
		// round brackets are not needed if one passes only one value
		// to a named parameter:
		s.B(5, s.ip = 7, 8.8);
	} //Demo

}; //class Sample

