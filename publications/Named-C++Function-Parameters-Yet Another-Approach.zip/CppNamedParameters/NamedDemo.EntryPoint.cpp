#include "NamedParametersDemo.h"
#include "ArticleCodeSamples.h"

int main() {
	NamedParametersDemo().Run();
	//ArticleCodeSamples.h:
	Sample::Demo();

	return 0;
} /* main */
