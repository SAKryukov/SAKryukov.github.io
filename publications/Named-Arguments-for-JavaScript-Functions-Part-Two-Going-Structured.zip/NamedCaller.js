/*

namedCaller: passing JavaScript function arguments by name

v.2.0

Copyright (c) 2015 by Sergey A Kryukov
http://www.SAKryukov.org
http://SAKryukov.org/freeware/calculator
http://www.codeproject.com/Members/SAKryukov

*/
"use strict";

function namedCaller(targetFunction, defaults, targetFunctionPropertyName) {

	if (!targetFunctionPropertyName) targetFunctionPropertyName = "targetFunction";

	var initialize = function (self, defaults) {
		for (var index = 0; index < argumentNames.length; ++index)
			self[argumentNames[index]] = undefined;
		if (!defaults) return;
		for (var index in defaults)
			self[index] = defaults[index];
	} //initialize

	var wrapper = (function createWrapperFunction() {
		var prepareArguments = function (self) {
			var argumentValues = [];
			for (var index = 0; index < argumentNames.length; ++index)
				argumentValues[index] = self[argumentNames[index]];
			return argumentValues;
		} //prepareArguments
		return function () {
			if (!targetFunction) return;
			var argumentValues = prepareArguments(wrapper);
			initialize(wrapper, defaults);
			return targetFunction.apply(this, argumentValues);
		} //wrapper
	})(); //createWrapperFunction

	var argumentNames = (function parseArguments(self) {
		if (!targetFunction) return;
		var argumentNames = targetFunction.toString().match(/function[^(]*\(([^)]*)\)/)[1].split(/,\s*/);
		if (!argumentNames || !argumentNames[0]) // case of "function () {...}"
			argumentNames = [];
		for (var index = 0; index < argumentNames.length; ++index)
			self[argumentNames[index]] = undefined;
		return argumentNames;
	})(wrapper); //parseArguments

	Object.defineProperty(wrapper, targetFunctionPropertyName, { enumerable: true, value: targetFunction });

	(function sealAndCheckUpDefaults(defaults, wrapper){
		Object.seal(wrapper);
		if (!defaults) return;
		initialize(wrapper, defaults);
	})(defaults, wrapper); //sealAndCheckUpDefaults

	return wrapper;

}; //namedCaller
