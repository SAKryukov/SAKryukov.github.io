// Alternative Analog SVG Clock
//
// Copyright (c) Sergey A Kryukov, 2023
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
// Original publication
// https://www.codeproject.com/Articles/5356856/Alternative-Analog-SVG-Clock

createClock = parent => {

    const halfSize = 1;
    const width = 0.01;
    const lengthSecond = 0.88;
    const lengthHour = 0.6;
    const lengthMinute = 0.8;
    const relativeArrowWidth = 2.8;
    const backSecond = 0.2;
    const svg = parent.constructor == SVG ? parent : new SVG({
        x: { from: -halfSize, to: halfSize, },
        y: { from: -halfSize, to: halfSize, }
    });

    createCompoundArrow = (length, back, relativeWidth) => {
        const arrow = svg.group();
        if (relativeWidth == undefined)
            relativeWidth = 1;
        svg.lineStrokeWidth = width * relativeWidth;
        svg.line(0, 0, back, -length, arrow);
        return arrow;
    }; //createCompoundArrow

    svg.lineStrokeWidth = width;
    svg.circleStrokeWidth = "0.04";
    svg.element.style.marginLeft = "0";
    svg.element.style.marginTop = "0";
    svg.circleStrokeWidth = 0;

    svg.circleFillColor = "azure";
    svg.circleStrokeWidth = width;
    svg.circle(0, 0, 0.9);
    svg.circleFillColor = "black";
    const tickCount = 12 * 5;
    for (let tick = 0; tick < tickCount; ++tick) {
        const angle = tick * 360 / tickCount;
        const x = 0.85 * Math.sin(angle * Math.PI / 180);
        const y = 0.85 * Math.cos(angle * Math.PI / 180);
        const radius = tick % 5 == 0 ? 0.03 : 0.007;
        svg.circle(x, y, radius);
    } //loop

    const arrowHour = createCompoundArrow(lengthHour, 0, relativeArrowWidth);
    const arrowMinute = createCompoundArrow(lengthMinute, 0, relativeArrowWidth);
    svg.lineStrokeColor = "red";
    const arrowSecond = createCompoundArrow(lengthSecond, backSecond);

    svg.circle(0, 0, 0.04);

    if (parent.constructor != SVG)
        parent.appendChild(svg.element);

    let currentTime = null;

    const set = time => {
        if (currentTime == time) return;
        currentTime = time;
        const date = new Date(time);
        let hour = date.getHours() % 12;
        let minute = date.getMinutes();
        let second = date.getSeconds();
        hour = (hour + minute / 60 + second / 3600) / 12;
        minute = (minute + second / 60) / 60;
        second = second / 60;
        arrowHour.style.transform = `rotate(${hour}turn)`;
        arrowMinute.style.transform = `rotate(${minute}turn)`;
        arrowSecond.style.transform = `rotate(${second}turn)`;
    }; //set

    return set;

}; //createClock
