// Alternative Analog SVG Clock
//
// Copyright (c) Sergey A Kryukov, 2023
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
// Original publication
// https://www.codeproject.com/Articles/5356856/Alternative-Analog-SVG-Clock

window.onload = () => {

    const clockSet = createClock(document.querySelector("section"));
    clockSet(Date.now());
    
    setInterval(() => {
        clockSet(Date.now());
    }, 333);

}; //window.onload