﻿namespace FirstTimeWindowsFormsSample {
    partial class FormOwned {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.panelButton = new System.Windows.Forms.Panel();
            this.panelSpacer = new System.Windows.Forms.Panel();
            this.panelList = new System.Windows.Forms.Panel();
            this.buttonClose = new System.Windows.Forms.Button();
            this.listBoxReport = new System.Windows.Forms.ListBox();
            this.panelButton.SuspendLayout();
            this.panelList.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelButton
            // 
            this.panelButton.Controls.Add(this.buttonClose);
            this.panelButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelButton.Location = new System.Drawing.Point(0, 0);
            this.panelButton.Name = "panelButton";
            this.panelButton.Padding = new System.Windows.Forms.Padding(4);
            this.panelButton.Size = new System.Drawing.Size(279, 37);
            this.panelButton.TabIndex = 0;
            // 
            // panelSpacer
            // 
            this.panelSpacer.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSpacer.Location = new System.Drawing.Point(0, 37);
            this.panelSpacer.Name = "panelSpacer";
            this.panelSpacer.Size = new System.Drawing.Size(279, 10);
            this.panelSpacer.TabIndex = 1;
            // 
            // panelList
            // 
            this.panelList.Controls.Add(this.listBoxReport);
            this.panelList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelList.Location = new System.Drawing.Point(0, 47);
            this.panelList.Name = "panelList";
            this.panelList.Size = new System.Drawing.Size(279, 108);
            this.panelList.TabIndex = 2;
            // 
            // buttonClose
            // 
            this.buttonClose.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonClose.Location = new System.Drawing.Point(4, 4);
            this.buttonClose.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(271, 29);
            this.buttonClose.TabIndex = 1;
            this.buttonClose.Text = "&Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            // 
            // listBoxReport
            // 
            this.listBoxReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxReport.FormattingEnabled = true;
            this.listBoxReport.ItemHeight = 20;
            this.listBoxReport.Location = new System.Drawing.Point(0, 0);
            this.listBoxReport.Name = "listBoxReport";
            this.listBoxReport.Size = new System.Drawing.Size(279, 104);
            this.listBoxReport.TabIndex = 0;
            // 
            // FormOwned
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(279, 155);
            this.Controls.Add(this.panelList);
            this.Controls.Add(this.panelSpacer);
            this.Controls.Add(this.panelButton);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FormOwned";
            this.Text = "FirstTime Test: Owned Form";
            this.panelButton.ResumeLayout(false);
            this.panelList.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelButton;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Panel panelSpacer;
        private System.Windows.Forms.Panel panelList;
        private System.Windows.Forms.ListBox listBoxReport;

    }
}