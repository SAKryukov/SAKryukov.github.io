﻿/*
    FirstTime Utility Test
    
    Copyright (C) 2009-2017 by Sergey A Kryukov
    http://www.SAKryukov.org
*/
using System;
using System.Windows.Forms;

namespace FirstTimeWindowsFormsSample {
    using FirstTime = SA.Univeral.Utilities.FirstTime;

    public partial class FormOwned : Form {
        
        public FormOwned() {
            InitializeComponent();
            this.buttonClose.Click += delegate(object sender, EventArgs e) { Close(); };
            this.listBoxReport.MouseEnter += delegate(object sender, EventArgs e) {
                if (FirstTime.Here)
                    ReportItem("FIRST TIME Mouse Entered HERE!");
            }; //listBoxReport.MouseEnter
            this.listBoxReport.MouseLeave += delegate(object sender, EventArgs e) {
                if (FirstTime.Here)
                    ReportItem("FIRST TIME Mouse Leaved HERE!");
            }; //listBoxReport.MouseLeave
        } //FormOwned

        void ReportItem(string item) {
            listBoxReport.SelectedIndex = this.listBoxReport.Items.Add(item);
        } //ReportItem

        protected override void OnActivated(EventArgs e) {
            base.OnActivated(e);
            if (FirstTime.Here)
                ReportItem("FIRST TIME ACTIVATED HERE");
        } //OnActivated

        FirstTime.Instance FirstTime = new FirstTime.Instance();

    } //class FormOwned

} //namespace FirstTimeWindowsFormsSample
