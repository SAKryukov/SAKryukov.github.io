﻿namespace FirstTimeWindowsFormsSample {
    partial class FormMain {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.panelInstructions = new System.Windows.Forms.Panel();
            this.panelButton = new System.Windows.Forms.Panel();
            this.buttonTestCodeInstance = new System.Windows.Forms.Button();
            this.panelInstruction = new System.Windows.Forms.Panel();
            this.labelInstructions = new System.Windows.Forms.Label();
            this.panelDemo = new System.Windows.Forms.Panel();
            this.listBoxDemo = new System.Windows.Forms.ListBox();
            this.panelInstructions.SuspendLayout();
            this.panelButton.SuspendLayout();
            this.panelInstruction.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelInstructions
            // 
            this.panelInstructions.Controls.Add(this.panelButton);
            this.panelInstructions.Controls.Add(this.panelInstruction);
            this.panelInstructions.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelInstructions.Location = new System.Drawing.Point(0, 0);
            this.panelInstructions.Name = "panelInstructions";
            this.panelInstructions.Padding = new System.Windows.Forms.Padding(4);
            this.panelInstructions.Size = new System.Drawing.Size(458, 85);
            this.panelInstructions.TabIndex = 1;
            // 
            // panelButton
            // 
            this.panelButton.Controls.Add(this.buttonTestCodeInstance);
            this.panelButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelButton.Location = new System.Drawing.Point(269, 4);
            this.panelButton.Name = "panelButton";
            this.panelButton.Padding = new System.Windows.Forms.Padding(4, 20, 4, 20);
            this.panelButton.Size = new System.Drawing.Size(185, 77);
            this.panelButton.TabIndex = 1;
            // 
            // buttonTestCodeInstance
            // 
            this.buttonTestCodeInstance.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonTestCodeInstance.Location = new System.Drawing.Point(4, 20);
            this.buttonTestCodeInstance.Name = "buttonTestCodeInstance";
            this.buttonTestCodeInstance.Size = new System.Drawing.Size(177, 37);
            this.buttonTestCodeInstance.TabIndex = 0;
            this.buttonTestCodeInstance.Text = "&Test Code Instance...";
            this.buttonTestCodeInstance.UseVisualStyleBackColor = true;
            // 
            // panelInstruction
            // 
            this.panelInstruction.Controls.Add(this.labelInstructions);
            this.panelInstruction.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelInstruction.Location = new System.Drawing.Point(4, 4);
            this.panelInstruction.Name = "panelInstruction";
            this.panelInstruction.Size = new System.Drawing.Size(265, 77);
            this.panelInstruction.TabIndex = 0;
            // 
            // labelInstructions
            // 
            this.labelInstructions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelInstructions.Location = new System.Drawing.Point(0, 0);
            this.labelInstructions.Name = "labelInstructions";
            this.labelInstructions.Size = new System.Drawing.Size(265, 77);
            this.labelInstructions.TabIndex = 1;
            this.labelInstructions.Text = "instructions";
            // 
            // panelDemo
            // 
            this.panelDemo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelDemo.Location = new System.Drawing.Point(0, 85);
            this.panelDemo.Name = "panelDemo";
            this.panelDemo.Size = new System.Drawing.Size(458, 47);
            this.panelDemo.TabIndex = 2;
            // 
            // listBoxDemo
            // 
            this.listBoxDemo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxDemo.FormattingEnabled = true;
            this.listBoxDemo.Location = new System.Drawing.Point(0, 0);
            this.listBoxDemo.Name = "listBoxDemo";
            this.listBoxDemo.Size = new System.Drawing.Size(458, 121);
            this.listBoxDemo.TabIndex = 1;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 132);
            this.Controls.Add(this.panelDemo);
            this.Controls.Add(this.panelInstructions);
            this.Controls.Add(this.listBoxDemo);
            this.Name = "FormMain";
            this.Text = " FirstTime Test: Main Form";
            this.panelInstructions.ResumeLayout(false);
            this.panelButton.ResumeLayout(false);
            this.panelInstruction.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelInstructions;
        private System.Windows.Forms.Panel panelDemo;
        private System.Windows.Forms.ListBox listBoxDemo;
        private System.Windows.Forms.Panel panelButton;
        private System.Windows.Forms.Button buttonTestCodeInstance;
        private System.Windows.Forms.Panel panelInstruction;
        private System.Windows.Forms.Label labelInstructions;
    }
}

