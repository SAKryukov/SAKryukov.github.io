﻿/*
    FirstTime Utility Test
    
    Copyright (C) 2009-2017 by Sergey A Kryukov
    http://www.SAKryukov.org
*/
using System;
using System.Windows.Forms;
using System.Drawing;

namespace FirstTimeWindowsFormsSample {
    using SA.Univeral.Utilities.Diagnostics;
    using Cardinal = System.UInt64;
    
    public partial class FormMain : Form {
        
        public FormMain() {
            InitializeComponent();
            listBoxDemo.Items.Clear();
            Shown += delegate(object sender, EventArgs e) {
                Top = 0; Left = 0; Height = Screen.FromControl(this).WorkingArea.Height;
                Form owned = new FormOwned();
                owned.ShowInTaskbar = false;
                AddOwnedForm(owned);
                owned.Show(this);
                owned.Left = this.Left + this.Width;
                this.buttonTestCodeInstance.Click += delegate(object buttonSender, EventArgs buttonEvent) {
                    Form form = new FormOwned();
                    AddOwnedForm(form);
                    form.Show(this);
                }; //buttonTestCodeInstance.Click
            }; //Shown
            Font = new System.Drawing.Font(Font.FontFamily, 12f);
            listBoxDemo.Parent = this.panelDemo;
            this.panelInstructions.BackColor = Color.Azure;
            listBoxDemo.KeyDown += delegate(object sender, KeyEventArgs e) {
                if (FirstTime.Here)
                    ReportItem("FIRST TIME Key Down HERE!");
            }; //listBox.KeyDown
            listBoxDemo.MouseEnter += delegate(object sender, EventArgs e) {
                if (FirstTime.Here)
                    ReportItem("FIRST TIME Mouse Entered HERE!");
            }; //listBox.MouseEnter
            listBoxDemo.MouseLeave += delegate(object sender, EventArgs e) {
                if (FirstTime.Here)
                    ReportItem("FIRST TIME Mouse Leaved HERE!");
            }; //listBox.MouseLeave
            this.labelInstructions.Text = "Try to do the following repeatedly:\n          Open new onwed form (Alt-T);\n          Close owned window (Alt+C);\n          Press any key;\n          Move mouse in and out;\n          Re-activate this window.";
        } //FormMain

        [STAThread]
        static void Main() {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormMain());
        } //Main

        void ReportItem(string item) {
            listBoxDemo.SelectedIndex = this.listBoxDemo.Items.Add(item);
        } //ReportItem

        protected override void OnActivated(EventArgs e) {
            base.OnActivated(e);
            Cardinal activationNumber = FirstTime.Here;
            ReportItem(string.Format("Activation #{0}", activationNumber));
            if (FirstTime.Here)
                ReportItem("FIRST TIME visited OnActivated handler in THIS place.");
            if (FirstTime.Here)
                ReportItem("FIRST TIME visited OnActivated handler in DIFFERENT place.");
            OverloadedMethod();
            OverloadedMethod(0);
        } //OnActivated

        protected override void OnMouseEnter(EventArgs e) {
            base.OnMouseEnter(e);
            if (FirstTime.Here)
                ReportItem("FIRST TIME Mouse Entered HERE!");
        } //OnMouseEnter

        protected override void OnMouseLeave(EventArgs e) {
            base.OnMouseLeave(e);
            base.OnMouseEnter(e);
            if (FirstTime.Here)
                ReportItem("FIRST TIME Mouse Leaved HERE!");
        } //OnMouseLeave

        void OverloadedMethod() {
            if (FirstTime.Here)
                ReportItem("FIRST TIME Overloaded Method HERE!");
        } //OverloadedMethod
        void OverloadedMethod(int value) {
            if (FirstTime.Here)
                ReportItem("FIRST TIME Another Overloaded Method with the Same Name HERE!");
        } //OverloadedMethod

    } //class FormMain

} //namespace FirstTimeWindowsFormsSample