﻿/*
    FirstTime Utility Test
    
    Copyright (C) 2009-2017 by Sergey A Kryukov
    http://www.SAKryukov.org
*/
namespace FirstTimeWpfSample {
    using System.Windows;
    public partial class App : Application {
    }
}
