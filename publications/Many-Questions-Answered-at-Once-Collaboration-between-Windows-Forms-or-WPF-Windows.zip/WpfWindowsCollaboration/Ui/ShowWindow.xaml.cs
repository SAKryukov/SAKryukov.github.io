﻿using System.Windows;

namespace WpfWindowsCollaboration.Ui {

    public partial class ShowWindow : Window {
        public ShowWindow() {
            InitializeComponent();
            this.ShowInTaskbar = false;
            this.Closed += (sender, eventArgs) => { Application.Current.Shutdown(); };
        }
    }
}
