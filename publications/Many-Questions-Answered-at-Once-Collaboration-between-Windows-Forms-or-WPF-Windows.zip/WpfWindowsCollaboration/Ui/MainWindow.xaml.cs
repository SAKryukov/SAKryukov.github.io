﻿using System.Windows;

namespace WpfWindowsCollaboration.Ui {

    public partial class MainWindow : Window {

        public MainWindow() {
            InitializeComponent();
            this.button.Click += (sender, ev) => {
                if (CollaborationWindow != null)
                    CollaborationWindow.Add(this.textBox.Text);
            }; //this.button.Click
        } //MainWindow

        internal ICollaboration CollaborationWindow { get; set; } 

    } //class MainWindow

} //namespace WpfWindowsCollaboration.Ui
