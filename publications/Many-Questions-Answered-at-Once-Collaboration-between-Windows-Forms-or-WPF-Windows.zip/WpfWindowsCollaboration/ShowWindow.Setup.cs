﻿namespace WpfWindowsCollaboration.Ui {
    using System.Windows;
    using System.Windows.Controls;

    interface ICollaboration {
        void Add(string text);
    } //interface ICollaboration

    public partial class ShowWindow : ICollaboration {

        void ICollaboration.Add(string text) {
            Border border = new Border();
            border.BorderThickness = new Thickness(1);
            border.BorderBrush = System.Windows.Media.Brushes.Black;
            border.Padding = new Thickness(4);
            border.Margin = new Thickness(1);
            TextBlock textBlock = new TextBlock();
            textBlock.Text = text;
            border.Child = textBlock;
            this.listBox.Items.Add(border);
            this.listBox.ScrollIntoView(border);
            this.listBox.SelectedIndex = this.listBox.Items.Count - 1;
        } //ICollaboration.Add

    } //ShowWindow

} //namespace WpfWindowsCollaboration.Ui
