﻿namespace WpfWindowsCollaboration.Main {
    using System;
    using System.Windows;

    class TheApplication : Application {

        protected override void OnStartup(StartupEventArgs e) {
            this.ShutdownMode = ShutdownMode.OnMainWindowClose;
            Ui.MainWindow mainWindow = new Ui.MainWindow();
            MainWindow = mainWindow;
            Ui.ShowWindow secondWindow = new Ui.ShowWindow();
            mainWindow.CollaborationWindow = secondWindow;
            secondWindow.Show();
            MainWindow.Show();
            secondWindow.Owner = mainWindow;
        } //OnStartup

        [STAThread]
        static void Main(string[] args) {
            Application app = new TheApplication();
            app.Run();
        } //Main
    } //class TheApplication

} //namespace WpfWindowsCollaboration.Main
