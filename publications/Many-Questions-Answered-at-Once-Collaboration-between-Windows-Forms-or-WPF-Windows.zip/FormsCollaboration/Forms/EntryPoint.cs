﻿namespace FormsCollaboration {
    using System;
    using System.Windows.Forms;

    class Program {

        static void Main() {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            MainForm main = new MainForm();
            ShowForm secondForm = new ShowForm();
            main.CollaborationForm = secondForm;
            secondForm.Owner = main;
            Application.Run(main);
        } //Main

    } //class Program

} //namespace FormsCollaboration
