﻿namespace FormsCollaboration {
    using System.Windows.Forms;

    public partial class MainForm {

        void Setup() {
            this.Text = Application.ProductName + ", Main";
            this.buttonAdd.Click += (sender, ev) => {
                if (CollaborationForm != null)
                    CollaborationForm.Add(this.textBox.Text);
            };
            this.textBox.ScrollBars = ScrollBars.Both;
            textBox.TextChanged += (sender, eventsArgs) => {
                buttonAdd.Enabled = !string.IsNullOrEmpty(textBox.Text);
            }; //textBox.TextChanged
            buttonAdd.Enabled = false;
        } //Setup

        internal ICollaboration CollaborationForm { get; set; }

    } //class MainForm

} //namespace FormsCollaboration
