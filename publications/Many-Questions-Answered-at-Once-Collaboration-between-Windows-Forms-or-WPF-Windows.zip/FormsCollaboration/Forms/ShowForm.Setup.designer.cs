﻿namespace FormsCollaboration {
    using System.Windows.Forms;

    interface ICollaboration {
        void Add(string text);
    } //interface ICollaboration

    public partial class ShowForm : ICollaboration {

        void Setup() {
            this.Text = Application.ProductName;
            this.ShowInTaskbar = false;
            flowLayoutPanel.AutoScroll = true;
            this.FormClosed += (sender, eventArgs) => { Application.Exit(); };
        } //Setup

        void ICollaboration.Add(string text) {
            Show();
            TextBox textBox = new TextBox();
            textBox.Text = text;
            textBox.ReadOnly = true;
            textBox.Multiline = true;
            textBox.ScrollBars = ScrollBars.Both;
            textBox.Height *= 4; 
            flowLayoutPanel.Controls.Add(textBox);
            flowLayoutPanel.ScrollControlIntoView(textBox);
            textBox.Focus();
        } //ICollaboration.Add

    } //class ShowForm

} //namespace FormsCollaboration