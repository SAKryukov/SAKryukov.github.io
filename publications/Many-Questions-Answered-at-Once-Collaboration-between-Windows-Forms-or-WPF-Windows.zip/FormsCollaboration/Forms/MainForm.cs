﻿namespace FormsCollaboration {
    using System;
    using System.Windows.Forms;
    using StringList = System.Collections.Generic.List<string>;
    using IStringList = System.Collections.Generic.IList<string>;
    using StringBuilder = System.Text.StringBuilder;

    public partial class MainForm : Form {

        public MainForm() {
            InitializeComponent();
            Text = Application.ProductName;
            Setup();
        } //MainForm

    } //class MainForm

} //namespace FormsCollaboration
