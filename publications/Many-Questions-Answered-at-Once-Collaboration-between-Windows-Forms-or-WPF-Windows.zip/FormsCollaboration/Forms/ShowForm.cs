﻿namespace FormsCollaboration {
    using System.Windows.Forms;

    public partial class ShowForm : Form {
        
        public ShowForm() {
            InitializeComponent();
            Setup();
        } //ShowForm

    } //class ShowForm

} //namespace FormsCollaboration
