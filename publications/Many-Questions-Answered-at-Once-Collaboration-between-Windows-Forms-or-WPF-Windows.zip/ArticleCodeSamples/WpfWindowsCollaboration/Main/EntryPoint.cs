﻿using System;
using System.Windows;
using System.Windows.Controls;

static class DefinitionSet {
    internal const string button = "_Add";
    internal const string label = "Item _Text";
    internal const string showWindow = "Forms Collaboration";
    internal const string mainWindow = showWindow + ", Main";
} //class DefinitionSet

class MainWindow : Window {
    internal MainWindow() {
        Title = DefinitionSet.mainWindow;
        this.Padding = new Thickness(4);
        DockPanel panel = new DockPanel();
        panel.LastChildFill = true;
        Label label = new Label();
        label.Content = DefinitionSet.label;
        TextBox textBox = new TextBox();
        textBox.AcceptsReturn = true;
        label.Target = textBox;
        Button button = new Button();
        button.Margin = new Thickness(4);
        button.Content = DefinitionSet.button;
        panel.Children.Add(label);
        panel.Children.Add(button);
        panel.Children.Add(textBox);
        DockPanel.SetDock(label, Dock.Top);
        DockPanel.SetDock(button, Dock.Bottom);
        this.Content = panel;
        button.Click += (sender, eventArgs) => {
            if (CollaborationWindow != null)
                CollaborationWindow.Add(textBox.Text);
        }; //button.Click
        textBox.TextChanged += (sender, eventArgs) => {
            button.IsEnabled = !string.IsNullOrEmpty(textBox.Text);
        }; //textBox.TextChanged
        button.IsEnabled = false;
    } //MainWindow
    internal ICollaboration CollaborationWindow { get; set; }
} //class MainWindow

partial class ShowWindow : Window {
    internal ShowWindow() {
        this.Title = DefinitionSet.showWindow;
        this.Content = listBox;
        this.ShowInTaskbar = false;
        this.Closed += (sender, eventArgs) => { Application.Current.Shutdown(); };
    } //ShowWindow
} //class ShowWindow

internal interface ICollaboration {
    void Add(string text);
} //interface ICollaboration

partial class ShowWindow : ICollaboration {
    ListBox listBox = new ListBox();
    void ICollaboration.Add(string text) {
        Border border = new Border();
        border.BorderThickness = new Thickness(1);
        border.BorderBrush = System.Windows.Media.Brushes.Black;
        border.Padding = new Thickness(4);
        border.Margin = new Thickness(1);
        TextBlock textBlock = new TextBlock();
        textBlock.Text = text;
        border.Child = textBlock;
        this.listBox.Items.Add(border);
        this.listBox.ScrollIntoView(border);
        this.listBox.SelectedIndex = this.listBox.Items.Count - 1;
    } //ICollaboration.Add
} //class ShowWindow

class EntryPoint : Application {
    protected override void OnStartup(StartupEventArgs e) {
        this.ShutdownMode = ShutdownMode.OnMainWindowClose;
        MainWindow mainWindow = new MainWindow();
        this.MainWindow = mainWindow;
        ShowWindow anotherWindow = new ShowWindow();
        mainWindow.CollaborationWindow = anotherWindow;
        anotherWindow.Show();
        mainWindow.Show();
        anotherWindow.Owner = mainWindow;
    } //OnStartup
    [STAThread]
    static void Main() {
        new EntryPoint().Run();
    } //Main
} //class EntryPoint
