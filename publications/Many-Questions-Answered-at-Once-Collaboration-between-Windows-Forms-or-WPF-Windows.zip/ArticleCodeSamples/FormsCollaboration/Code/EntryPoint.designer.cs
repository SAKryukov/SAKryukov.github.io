﻿using System.Windows.Forms;

static class DefinitionSet {
    internal const string button = "&Add";
    internal const string showWindow = "Forms Collaboration";
    internal const string mainWindow = showWindow + ", Main";
} //class DefinitionSet

class MainForm : Form {
    internal MainForm() {
        Text = DefinitionSet.mainWindow;
        this.Padding = new Padding(4);
        Panel fill = new Panel();
        fill.TabIndex = 1;
        fill.Dock = DockStyle.Fill;
        TextBox textBox = new TextBox();
        textBox.TabIndex = 1;
        textBox.Multiline = true;
        textBox.Dock = DockStyle.Fill;
        textBox.Parent = fill;
        Panel bottom = new Panel();
        bottom.TabIndex = 2;
        bottom.Dock = DockStyle.Bottom;
        Button button = new Button();
        bottom.Height = button.Height * 2;
        button.Dock = DockStyle.Left;
        button.Parent = bottom;
        button.Text = DefinitionSet.button;
        bottom.Padding = new Padding(0, 4, 0, 0);
        Controls.Add(fill);
        Controls.Add(bottom);
        button.Click += (sender, eventArgs) => {
            if (CollaborationForm != null)
                CollaborationForm.Add(textBox.Text); // it makes it a closure
        }; //button.Click
        textBox.TextChanged += (sender, eventsArgs) => {
            button.Enabled = !string.IsNullOrEmpty(textBox.Text);
        }; //textBox.TextChanged
        button.Enabled = false;
    } //MainForm
    internal ICollaboration CollaborationForm { get; set; }
} //class MainForm

partial class ShowForm : Form {
    internal ShowForm() {
        Text = DefinitionSet.showWindow;
        panel.Dock = DockStyle.Fill;
        panel.Parent = this;
        panel.AutoScroll = true;
        this.ShowInTaskbar = false;
        this.FormClosed += (sender, eventArgs) => { Application.Exit(); };
    } //ShowForm
} //class ShowForm

internal interface ICollaboration {
    void Add(string text);
} //interface ICollaboration

partial class ShowForm : ICollaboration {
    FlowLayoutPanel panel = new FlowLayoutPanel();
    void ICollaboration.Add(string text) {
        Show();
        TextBox textBox = new TextBox();
        textBox.Text = text;
        textBox.ReadOnly = true;
        textBox.Multiline = true;
        textBox.ScrollBars = ScrollBars.Both;
        textBox.Height *= 4;
        panel.Controls.Add(textBox);
        panel.ScrollControlIntoView(textBox);
        textBox.Focus();
    } //ICollaboration.Add
} //class ShowForm

class EntryPoint {
    static void Main() {
        MainForm main = new MainForm();
        ShowForm secondForm = new ShowForm();
        main.CollaborationForm = secondForm;
        secondForm.Owner = main;
        Application.Run(main);
    } //void Main
} //class TheApplication
