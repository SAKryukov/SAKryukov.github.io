﻿/*  
    Unicode Art

    Copyright © 1 April, 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1179876/Unicode-Art
 
*/

namespace UnicodeArt.Main {
	using System.Windows;
	using System.Windows.Media;
	using System.Windows.Media.Imaging;
	using System.IO;
	using StringBuilder = System.Text.StringBuilder;
	using Encoding = System.Text.Encoding;

	class Renderer {

		static void Render(DrawingContext drawingContext, char[,] unicodePixels, Typeface typeface, int fontSize, byte frameWidth) {
			int size = fontSize;
			int xMax = unicodePixels.GetUpperBound(1);
			int yMax = unicodePixels.GetUpperBound(0);
			drawingContext.DrawRectangle(Brushes.White, null, new Rect(new Size(size * (xMax + 1) + 2 * frameWidth, size * (yMax + 1) + 2 * frameWidth)));
			if (frameWidth > 0)
				drawingContext.DrawRectangle(Brushes.Transparent, new Pen(Brushes.Black, frameWidth), new Rect(new Size(size * (xMax + 1) + 2 * frameWidth - frameWidth, size * (yMax + 1) + 2 * frameWidth - 1 - frameWidth)));
			int currentY = 0, currentX = 0;
			for (var indexY = 0; indexY <= yMax; ++indexY) {
				currentY = indexY * size;
				for (var indexX = 0; indexX <= xMax; ++indexX) {
					currentX = indexX * size;
					FormattedText glyph = new FormattedText(new string(new char[] { unicodePixels[indexY, indexX] }),
							System.Globalization.CultureInfo.InvariantCulture,
							FlowDirection.LeftToRight,
							typeface,
							size,
							Brushes.Black);
					int offsetX = (size - (int)System.Math.Round(glyph.Width)) / 2;
					int offsetY = (size - (int)System.Math.Round(glyph.Height)) / 2;
					drawingContext.DrawText(glyph, new Point(currentX + offsetX + frameWidth, currentY + offsetY + frameWidth));
					currentX += size;
				} //loop x
			} //loop y
		} //Render

		internal static RenderTargetBitmap RenderBitmapSource(char[,] unicodePixels, Typeface typeface, int fontSize, byte frameWidth) {
			DrawingVisual dv = new DrawingVisual();
			using (DrawingContext drawingContext = dv.RenderOpen()) {
				Render(drawingContext, unicodePixels, typeface, fontSize, frameWidth);
				drawingContext.Close();
				int xMax = unicodePixels.GetUpperBound(1);
				int yMax = unicodePixels.GetUpperBound(0);
				int size = fontSize;
				RenderTargetBitmap rb = new RenderTargetBitmap(size * (xMax + 1) + 2 * frameWidth, size * (yMax + 1) + 2 * frameWidth, DefinitionSet.defaultDpi, DefinitionSet.defaultDpi, PixelFormats.Default);
				rb.Render(dv);
				return rb;
			} //using
		} //RenderBitmapSource

		internal ImageSource Render(BitmapImage source, Typeface typeface, int fontSize, byte frameWidth) {
			if (characterRepertoire.IsEmpty)
				characterRepertoire.Build(typeface);
			BitmapSource bs = source;
			if (bs.Format != PixelFormats.Gray8)
				bs = new FormatConvertedBitmap(source, PixelFormats.Gray8, null, 0);
			byte[] pixels = new byte[source.PixelWidth * source.PixelHeight * source.Format.BitsPerPixel / 8];
			bs.CopyPixels(pixels, source.PixelWidth, 0);
			unicodePixels = new char[source.PixelHeight, source.PixelWidth];
			int xMax = unicodePixels.GetUpperBound(1);
			int yMax = unicodePixels.GetUpperBound(0);
				for (var indexY = 0; indexY <= yMax; ++indexY)
					for (var indexX = 0; indexX <= xMax; ++indexX) {
						int pixelIndex = source.PixelWidth * indexY + indexX;
						unicodePixels[indexY, indexX] =
							characterRepertoire.GetPixel(pixels[pixelIndex]);
					} //loop x
			renderTargetBitmap = RenderBitmapSource(unicodePixels, typeface, fontSize, frameWidth);
			renderTargetBitmap.Freeze();
			double width = source.PixelWidth * fontSize + 2 * frameWidth;
			double height = source.PixelHeight * fontSize + 2 * frameWidth;
			return renderTargetBitmap;
		} //Render

		internal void SaveImage(string fileName) {
			PngBitmapEncoder encoder = new PngBitmapEncoder();
			encoder.Frames.Add(BitmapFrame.Create(this.renderTargetBitmap));
			using (Stream stream = File.Create(fileName)) {
				encoder.Save(stream);
			} //using
		} //SaveImage

		internal void SaveToText(string fileName) {
			using (StreamWriter writer = new StreamWriter(fileName, false, Encoding.UTF8)) {
				int xMax = unicodePixels.GetUpperBound(1);
				int yMax = unicodePixels.GetUpperBound(0);
				for (var indexY = 0; indexY <= yMax; ++indexY) {
					StringBuilder sb = new StringBuilder();
					for (var indexX = 0; indexX <= xMax; ++indexX)
						sb.Append(unicodePixels[indexY, indexX]);
					writer.WriteLine(sb.ToString());
				} //loop Y
			} //using
		} //SaveToText

		internal void SaveToHtml(string fileName, string originalFileName, Typeface typeface, int fontSize) {
			if (originalFileName == null) originalFileName = string.Empty;
			int xMax = unicodePixels.GetUpperBound(1);
			int yMax = unicodePixels.GetUpperBound(0);
			StringBuilder sb = new StringBuilder();
			for (var indexY = 0; indexY <= yMax; ++indexY) {
				for (var indexX = 0; indexX <= xMax; ++indexX)
					sb.Append(unicodePixels[indexY, indexX]);
				if (indexY < yMax) sb.Append(System.Environment.NewLine);
			} //loop Y
			GlyphTypeface glyphTypeface;
			typeface.TryGetGlyphTypeface(out glyphTypeface);
			System.Collections.Generic.IDictionary<ushort, double>
				advanceHeights = glyphTypeface.AdvanceHeights;
			System.Collections.Generic.IDictionary<ushort, double>
				advanceWidths = glyphTypeface.AdvanceWidths;
			double aspect = 1;
			double width, height;
			ushort testCharachter = DefinitionSet.fullSizeSampleCharacter;
			if (advanceWidths.TryGetValue(testCharachter, out width) &&
				advanceHeights.TryGetValue(testCharachter, out height))
					// then sample character is supported by typeface
					aspect = width / height;
			string html = string.Format(
				Resources.Resources.HtmlFormat,
				originalFileName,
				1,
				aspect,
				typeface.FontFamily.ToString(),
				System.Web.HttpUtility.HtmlEncode(sb.ToString()));	
			using (StreamWriter writer =
				new StreamWriter(fileName, false, Encoding.UTF8)) {
				writer.WriteLine(html);
			} //using
		} //SaveToHtml

		static CharacterRepertoire characterRepertoire = new CharacterRepertoire();
		RenderTargetBitmap renderTargetBitmap; 
		char[,] unicodePixels;

	} //class Renderer

} //namespace UnicodeArt.Main
