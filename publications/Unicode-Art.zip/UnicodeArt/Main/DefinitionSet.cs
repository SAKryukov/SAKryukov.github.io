﻿/*  
    Unicode Art

    Copyright © 1 April, 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1179876/Unicode-Art
 
*/

namespace UnicodeArt.Main {

	class UnicodeRange {
		internal UnicodeRange(ushort first, ushort last) { this.first = first; this.last = last; }
		internal ushort first { get; private set; }
		internal ushort last { get; private set; }
	} //UnicodeRange

	static class DefinitionSet {
		internal static int normalFontWeight = 400;
		internal static int boldFontWeight = 700;
		internal const double defaultDpi = 96;
		internal readonly static string fontSample = "█❤✲☆∵…";
		internal const char tonalRangeMax = ' ';
		internal const int brigtnessMeasurementGlyphSize = 8;
		internal const ushort fullSizeSampleCharacter = 0x57; // 'W', for HTML rendering only
		internal static readonly UnicodeRange[] charset = new UnicodeRange[] {
			new UnicodeRange(0x20, 127),
			new UnicodeRange(0x2100, 0x33DD),
		};
	} //class DefinitionSet

} //namespace UnicodeArt.Main
