﻿/*  
    Unicode Art

    Copyright © 1 April, 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1179876/Unicode-Art
 
*/

namespace UnicodeArt.Main {
	using System.Windows;
	using System.Windows.Media;
	using System.Windows.Media.Imaging;
	using Random = System.Random;
	using CharacterList = System.Collections.Generic.List<char>;
	using DoubleList = System.Collections.Generic.List<double>;

	class CharacterRepertoire {

		static double GetBrightness(char pixel, Typeface typeface) {
			int size = DefinitionSet.brigtnessMeasurementGlyphSize;
			DrawingVisual dv = new DrawingVisual();
			FormattedText ft = new FormattedText(
				new string(new char[] { pixel }),
				System.Globalization.CultureInfo.InvariantCulture,
				FlowDirection.LeftToRight,
				typeface, size, Brushes.Black);
			using (DrawingContext drawingContext = dv.RenderOpen()) {
				drawingContext.DrawRectangle(Brushes.White, null, new Rect(new Size(size * 2, size * 2)));
				drawingContext.DrawText(ft, new Point(0, 0));
				drawingContext.Close();
			} // using
			RenderTargetBitmap rb = new RenderTargetBitmap((int)size, (int)size, DefinitionSet.defaultDpi, DefinitionSet.defaultDpi, PixelFormats.Default);
			rb.Render(dv);
			BitmapSource bs = rb;
			if (bs.Format != PixelFormats.Gray8)
				bs = new FormatConvertedBitmap(rb, PixelFormats.Gray8, null, 0);
			byte[] pixels = new byte[size * size];
			bs.CopyPixels(pixels, size, 0);
			double result = 0;
			for (byte index = 0; index < pixels.Length; ++index)
				result += pixels[index];
			return result / (size * size * (byte.MaxValue + 1));
		} //GetBrightness

		internal bool IsEmpty { get { return total < 1; } }

		internal void Build(Typeface typeface) {
			GlyphTypeface glyphTypeface;
			bool success = typeface.TryGetGlyphTypeface(out glyphTypeface);
			var map = glyphTypeface.CharacterToGlyphMap;			
			System.Predicate<ushort> isCharacterSupported = (codePoint) => {
				ushort glyphIndexDummy;
				return map.TryGetValue(codePoint, out glyphIndexDummy);
			}; //isCharacterSupported
			CharacterList list = new CharacterList();
			DoubleList brightnessList = new DoubleList();
			foreach (var range in DefinitionSet.charset)
				for (ushort codePoint = range.first; codePoint <= range.last; ++codePoint) {
					if (!isCharacterSupported(codePoint)) continue;
					char character = System.Char.ConvertFromUtf32(codePoint)[0];
					if (char.IsSeparator(character) || char.IsControl(character)) continue;
					list.Add(character);
					brightnessList.Add(GetBrightness(character, typeface));
				} //loop
			double[] brightnessValues = brightnessList.ToArray();
			double min = double.PositiveInfinity;
			for (int index = 0; index < brightnessValues.Length; ++index)
				if (brightnessValues[index] < min) min = brightnessValues[index];
			total = list.Count;
			for (int index = 0; index <= byte.MaxValue; ++index) body[index] = new CharacterList();
			for (int index = 0; index < brightnessValues.Length; ++index) {
				if (double.IsNaN(brightnessValues[index]))
					continue;
				char symbol = list[index];
				double symbolBrightness = brightnessValues[index];
				double dValue = (symbolBrightness - min) / (1 - min) * (byte.MaxValue);
				body[(int)dValue].Add(symbol);
			} //loop
			//// research:
			//int good = 0;
			//System.Array.ForEach<CharacterList>(body, new System.Action<CharacterList>((val) => { if (val.Count > 1) ++good; }));
			//++good;
			//double quality = 1f * good / (byte.MaxValue + 1);
			//// histogram:
			//// ...
			//// end research:
			body[byte.MaxValue].Add(DefinitionSet.tonalRangeMax);
			int lackStart = 0;
			bool inLack = false;
			System.Text.StringBuilder sb = new System.Text.StringBuilder();
			for (int index = 0; index <= byte.MaxValue; ++index) {
				bool none = body[index].Count == 0;
				if ((!inLack) && none) {
					inLack = true;
					lackStart = index;
				} else if (inLack && (!none)) {
					int lackEnd = index - 1;
					inLack = false;
					for (int lackIndex = lackStart; lackIndex <= lackEnd; ++lackIndex) {
						int loDistance = lackIndex - lackStart;
						int hiDistance = lackEnd - lackEnd;
						if (loDistance < hiDistance)
							body[lackIndex] = body[lackStart - 1];
						else
							body[lackIndex] = body[lackEnd + 1];
					} //lack loop
				} //if
			} //loop
		} //Build

		internal char GetPixel(byte value) {
			return body[value][random.Next(0, body[value].Count)];
		} //GetPixel

		CharacterList[] body = new CharacterList[byte.MaxValue + 1];
		int total;
		static Random random = new Random(System.DateTime.Now.Millisecond);
	} //class CharacterRepertoire

} //namespace UnicodeArt.Main
