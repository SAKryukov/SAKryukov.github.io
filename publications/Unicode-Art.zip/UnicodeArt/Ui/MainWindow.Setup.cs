﻿/*  
    Unicode Art

    Copyright © 1 April, 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1179876/Unicode-Art
 
*/

namespace UnicodeArt.Ui {
	using System;
	using System.Windows;
	using System.Windows.Media;
	using System.Windows.Media.Imaging;
	using System.Windows.Input;
	using FontDialog = System.Windows.Forms.FontDialog;
	using FontDialogResult = System.Windows.Forms.DialogResult;
	using DrawingFontFamily = System.Drawing.FontFamily;
	using DrawingFont = System.Drawing.Font;
	using DrawingFontStyle = System.Drawing.FontStyle;
	using Path = System.IO.Path;
	using OpenFileDialog = Microsoft.Win32.OpenFileDialog;
	using App = Main.TheApplication;

	public partial class MainWindow {

		void Setup() {
			bool alreadyOpened = false;
			string initialFontButtonCaption = buttonFont.Content.ToString();
			setupDialogs();
			var fontCommand = ApplicationCommands.Properties;
			var previewCommand = ApplicationCommands.PrintPreview;
			buttonFont.Content = string.Format(UnicodeArt.Resources.Resources.buttonFontTextFormat, initialFontButtonCaption, textBlockFontSample.FontFamily.ToString(), textBlockFontSample.FontSize.ToString());
			textBlockFontSample.Text = Main.DefinitionSet.fontSample;
			this.CommandBindings.Add(new System.Windows.Input.CommandBinding(fontCommand,
				(sender, eventArgs) => {
					DrawingFontStyle fontStyle = 0;
					if (textBlockFontSample.FontWeight.ToOpenTypeWeight() == boldFontWeight)
						fontStyle = DrawingFontStyle.Bold;
					fontDialog.Font = new DrawingFont(new DrawingFontFamily(textBlockFontSample.FontFamily.ToString()),
						(float)textBlockFontSample.FontSize,
						fontStyle);
					if (fontDialog.ShowDialog() != FontDialogResult.OK) return;
					textBlockFontSample.FontFamily = new System.Windows.Media.FontFamily(fontDialog.Font.FontFamily.Name);
					textBlockFontSample.FontSize = fontDialog.Font.Size;
					if ((fontDialog.Font.Style & System.Drawing.FontStyle.Bold) > 0)
						textBlockFontSample.FontWeight = FontWeight.FromOpenTypeWeight(boldFontWeight);
					else
						textBlockFontSample.FontWeight = FontWeight.FromOpenTypeWeight(normalFontWeight);
					buttonFont.Content = string.Format(UnicodeArt.Resources.Resources.buttonFontTextFormat, initialFontButtonCaption, textBlockFontSample.FontFamily.ToString(), textBlockFontSample.FontSize.ToString());
				}));
			System.Action loadSource = () => {
				if (openDialog.ShowDialog() != true) return;
				BitmapImage src = new BitmapImage();
				src.BeginInit();
				src.UriSource = new Uri(openDialog.FileName, UriKind.RelativeOrAbsolute);
				src.EndInit();
				originalFileName = Path.GetFileName(openDialog.FileName);
				this.image.Width = src.Width;
				this.image.Height = src.Height;
				this.image.Source = src;
				imagePlaceholder.Visibility = Visibility.Hidden;
				bitmapImage = src;
				alreadyOpened = true;
				Title = string.Format(UnicodeArt.Resources.Resources.titleFormat, App.Current.ProductName, Path.GetFileName(openDialog.FileName));
			}; //loadSource
			this.CommandBindings.Add(new System.Windows.Input.CommandBinding(ApplicationCommands.Open,
				(sender, eventArgs) => { loadSource(); }));
			this.imagePlaceholder.MouseDown += (sender, eventArgs) => { loadSource(); };
			this.CommandBindings.Add(new System.Windows.Input.CommandBinding(previewCommand,
				(sender, eventArgs) => {
					if (bitmapImage == null) return;
					PreviewWindow preview = new PreviewWindow();
					preview.Icon = this.Icon;
					preview.Render(
						bitmapImage,
						new Typeface(textBlockFontSample.FontFamily, textBlockFontSample.FontStyle, textBlockFontSample.FontWeight, textBlockFontSample.FontStretch),
						(int)System.Math.Round(textBlockFontSample.FontSize),
						originalFileName);
					preview.Title = string.Format(UnicodeArt.Resources.Resources.titleFormat, preview.Title, Path.GetFileName(openDialog.FileName));
				}, (sender, eventArgs) => {
					eventArgs.CanExecute = alreadyOpened && textBlockFontSample.Text.Length > 0;
				}));
		} //Setup

		protected override void OnClosing(System.ComponentModel.CancelEventArgs e) {
			if (bitmapImage == null) return;
			App.Closer.HandleClosing(e, this,
				string.Format(UnicodeArt.Resources.Resources.closingMessageMain, Environment.NewLine),
				ClosingWindowControl.DefaultItems.cancelOrExit, null);
			base.OnClosing(e);
		} //OnClosing

		OpenFileDialog openDialog = new OpenFileDialog();
		FontDialog fontDialog = new FontDialog();
		int normalFontWeight, boldFontWeight;
		string originalFileName;
		BitmapImage bitmapImage;

		void setupDialogs() {
			openDialog.Title = UnicodeArt.Resources.Resources.openDialogTitle;
			openDialog.Filter = UnicodeArt.Resources.Resources.openDialogFilter;
			normalFontWeight = textBlockFontSample.FontWeight.ToOpenTypeWeight();
			boldFontWeight = Main.DefinitionSet.boldFontWeight;
		} //setupDialogs

	} //class MainWindow

} //namespace UnicodeArt.Ui