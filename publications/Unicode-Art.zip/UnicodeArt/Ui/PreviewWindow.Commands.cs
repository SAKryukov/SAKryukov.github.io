﻿/*  
    Unicode Art

    Copyright © 1 April, 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1179876/Unicode-Art
 
*/

namespace UnicodeArt.Ui {
	using System;
	using System.Windows;
	using System.Windows.Media;
	using System.Windows.Media.Imaging;
	using System.Windows.Input;
	using System.Threading;
	using System.Windows.Threading;
	using Image = System.Windows.Controls.Image;
	using SaveFileDialog = Microsoft.Win32.SaveFileDialog;
	using App = Main.TheApplication;

	public partial class PreviewWindow {

		internal enum RenderTarget { realPixelSize, scaled };

		void SetTarget(RenderTarget target) {
			this.renderingSign.Visibility = Visibility.Collapsed;
			if (target == RenderTarget.scaled) {
				scrollViewer.Visibility = Visibility.Hidden;
				scrollViewer.Content = null;
				viewBox.Child = image;
				viewBox.Visibility = Visibility.Visible;
			} else {
				viewBox.Visibility = Visibility.Hidden;
				viewBox.Child = null;
				scrollViewer.Content = image;
				scrollViewer.Visibility = Visibility.Visible;
			} //if
		} //SetTarget

		public void Setup() {
			InitializeComponent();
			menu.Visibility = Visibility.Collapsed;
			renderer = new Main.Renderer();
			dialogAsBitmap.Title = UnicodeArt.Resources.Resources.saveDialogAsBitmapTitle;
			dialogAsBitmap.Filter = UnicodeArt.Resources.Resources.saveDialogAsBitmapFilter;
			dialogAsText.Title = UnicodeArt.Resources.Resources.saveDialogAsTextTitle;
			dialogAsText.Filter = UnicodeArt.Resources.Resources.saveDialogAsTextFilter;
			dialogAsHtml.Title = UnicodeArt.Resources.Resources.saveDialogAsHtmlTitle;
			dialogAsHtml.Filter = UnicodeArt.Resources.Resources.saveDialogAsHtmlFilter;
			var saveAsBitmapCommand = ApplicationCommands.Save;
			var saveAsTextCommand = ApplicationCommands.SelectAll;
			var saveAsHtmlCommand = NavigationCommands.Favorites;
			var switchTargetCommand = ApplicationCommands.PrintPreview;
			this.CommandBindings.Add(new System.Windows.Input.CommandBinding(saveAsBitmapCommand,
				(sender, eventArgs) => {
					if (dialogAsBitmap.ShowDialog() != true) return;
					renderer.SaveImage(dialogAsBitmap.FileName);
					bitmapSaved = true;
				}));
			this.CommandBindings.Add(new System.Windows.Input.CommandBinding(saveAsTextCommand,
				(sender, eventArgs) => {
					if (dialogAsText.ShowDialog() != true) return;
					renderer.SaveToText(dialogAsText.FileName);
					textSaved = true;
				}));
			this.CommandBindings.Add(new System.Windows.Input.CommandBinding(saveAsHtmlCommand,
				(sender, eventArgs) => {
					if (dialogAsHtml.ShowDialog() != true) return;
					renderer.SaveToHtml(dialogAsHtml.FileName, originalFileName, this.typeface, this.fontSize);
					bitmapSaved = true;
				}));
			//NavigationCommands.Favorites
			this.CommandBindings.Add(new System.Windows.Input.CommandBinding(switchTargetCommand,
				(sender, eventArgs) => {
					if (meniItemViewSwitch.IsChecked)
						SetTarget(RenderTarget.realPixelSize);
					else
						SetTarget(RenderTarget.scaled);
				}, (sender, eventArgs) => {
					eventArgs.CanExecute = true;
				}));
		} //Setup

		internal void ShowException(System.Exception e) {
			renderingSign.Text = string.Format(UnicodeArt.Resources.Resources.exceptionFormat, e.GetType().Name, e.Message);
			renderingSign.Visibility = Visibility.Visible;
			viewBox.Visibility = Visibility.Hidden;
			scrollViewer.Visibility = Visibility.Hidden;
			threadException = true;
		} //ShowException

		class ThreadWrapper {
			internal ThreadWrapper(PreviewWindow presentation, Image image, Main.Renderer renderer, BitmapImage source, Typeface typeface, int fontSize, Dispatcher dispatcher) {
				this.presentation = presentation;
				this.image = image;
				this.typeface = typeface;
				this.fontSize = fontSize;
				this.renderer = renderer;
				this.source = source;
				source.Freeze();
				this.dispatcher = dispatcher;
			} //ThreadWrapper
			internal void Start() {
				thread = new Thread(Body);
				thread.TrySetApartmentState(ApartmentState.STA);
				thread.Start();
			} //Start
			internal void Abort() {
				thread.Abort();
			} //Abort
			internal void Join() {
				thread.Join();
			} //Join
			void Body() {
				try {
					ImageSource imageSource = renderer.Render(source, typeface, fontSize, 0);
					dispatcher.Invoke(new System.Action(() => {
						image.Source = imageSource;
						image.Width = source.Width * fontSize;
						image.Height = source.Height * fontSize;
						presentation.menu.Visibility = Visibility.Visible;
						presentation.SetTarget(RenderTarget.scaled);
					}));
				} catch (ThreadAbortException) {
				} catch (System.Exception e) {
					dispatcher.Invoke(new System.Action<Exception>((Exception exception) => {
						presentation.ShowException(exception);
					}), e);
				} //exception
			} //Body
			Thread thread;
			Dispatcher dispatcher;
			Main.Renderer renderer;
			BitmapImage source;
			PreviewWindow presentation;
			Image image;
			Typeface typeface;
			int fontSize;
		} //class ThreadWrapper

		internal void Render(BitmapImage source, Typeface typeface, int fontSize, string originalFileName) {
			this.typeface = typeface;
			this.fontSize = fontSize;
			this.originalFileName = originalFileName;
			Show();
			currentThreadWrapper = new ThreadWrapper(this, image, renderer, source, typeface, fontSize, Dispatcher);
			currentThreadWrapper.Start();
		} //Render

		protected override void OnClosing(System.ComponentModel.CancelEventArgs e) {
			ClosingWindowControl.DefaultItems items = ClosingWindowControl.DefaultItems.all;
			string msg = string.Format(UnicodeArt.Resources.Resources.closingMessagePreview, Environment.NewLine);
			if (threadException) {
				msg = UnicodeArt.Resources.Resources.closingMessagePreviewRenderingException;
				items = ClosingWindowControl.DefaultItems.Close | ClosingWindowControl.DefaultItems.ExitApplication;
			} //if
			if (! (textSaved && bitmapSaved) )
				App.Closer.HandleClosing(e, this,
					msg,
					items,
					(wnd, act) => {
						if (threadException) return;
						if (currentThreadWrapper == null) return;
						currentThreadWrapper.Abort();
						currentThreadWrapper.Join();
					});
			base.OnClosing(e);
		} //OnClosing

		ThreadWrapper currentThreadWrapper;

		Main.Renderer renderer;
		SaveFileDialog dialogAsText = new SaveFileDialog();
		SaveFileDialog dialogAsHtml = new SaveFileDialog();
		SaveFileDialog dialogAsBitmap = new SaveFileDialog();
		string originalFileName;
		Image image = new Image();
		bool textSaved, bitmapSaved, threadException;
		Typeface typeface;
		int fontSize;

	} //class PreviewWindow

} //namespace UnicodeArt.Ui
