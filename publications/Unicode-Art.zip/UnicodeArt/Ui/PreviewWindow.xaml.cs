﻿/*  
    Unicode Art

    Copyright © 1 April, 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1179876/Unicode-Art
 
*/

namespace UnicodeArt.Ui {
	using System.Windows;

	public partial class PreviewWindow : Window {
	
		public PreviewWindow() {
			InitializeComponent();
			Setup();
		} //PreviewWindow

	} //class PreviewWindow

} //namespace UnicodeArt.Ui
