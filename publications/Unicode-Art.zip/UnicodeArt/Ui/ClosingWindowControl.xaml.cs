﻿/*  
    Unicode Art

    Copyright © 1 April, 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1179876/Unicode-Art
 
*/

namespace UnicodeArt.Ui {
	using System;
	using System.Windows;
	using System.Windows.Controls;
	using System.Windows.Media;
	using System.Windows.Input;
	using CancelEventArgs = System.ComponentModel.CancelEventArgs;

	public partial class ClosingWindowControl : Window {

		internal enum DefaultItems {
			Cancel = 1, Close = 2, ShowMainWindow = 4, ExitApplication = 8,
			all = Cancel | Close | ShowMainWindow | ExitApplication,
			cancelOrExit = Cancel | ExitApplication,
		} //DefaultItems
		internal enum ClosingAction { closeWindow, exitApplication, }
		internal delegate void ClientClosingAction(Window window, ClosingAction action);

		public ClosingWindowControl() {
			InitializeComponent();
			foreach (var item in menu.Items) {
				MenuItem mi = item as MenuItem;
				if (mi != null)
					mi.LostKeyboardFocus += (sender, eventArgs) => {
						if (menu.IsFocused) return;
						foreach (var testItem in menu.Items) {
							MenuItem testMenuItem = testItem as MenuItem;
							if (Keyboard.FocusedElement == testItem)
								return;
						} //handler loop
						// this is the point when none of menu items has focus:
						Hide();
					}; //mi.LostFocus
			} // loop
			close.Click += (sender, eventArgs) => {
				if (Owner == null) return;
				closing = Owner;
				Owner = null;
				if (clientClosingAction != null)
					clientClosingAction.Invoke(closing, ClosingAction.closeWindow);
				closing.Close();
				Application.Current.MainWindow.Activate();
			};
			this.main.Click += (sender, eventArgs) => {
				Owner = null;
				Application.Current.MainWindow.Activate();
			};
			shutdown.Click += (sender, eventArgs) => {
				if (Owner == null) return;
				closing = Owner;
				if (clientClosingAction != null)
					clientClosingAction.Invoke(closing, ClosingAction.closeWindow);
				shuttingDown = true;
				Application.Current.Shutdown();
			};
		} //ClosingWindowControl

		internal void HandleClosing(CancelEventArgs e, Window window, string title, DefaultItems defaultItems, ClientClosingAction clientClosingAction) {
			if (shuttingDown) return;
			if (window == closing) return;
			Owner = window;
			this.clientClosingAction = clientClosingAction;
			e.Cancel = true;
			bool dirty = this.title.Text != title || defaultItems != lastItemUsage;
			this.title.Text = title;
			SetVisibility(window, defaultItems);
			lastItemUsage = defaultItems;
			if (dirty) {
				Show();
				SetLocation(window);
			} else {
				SetLocation(window);
				Show();
			} //if
			foreach (var item in menu.Items) {
				MenuItem mi = item as MenuItem;
				if (mi != null && mi.Visibility == Visibility.Visible) {
					mi.Focus();
					break;
				} //if
			} // loop
		} //HandleClosing

		protected override void OnClosing(CancelEventArgs e) {
			base.OnClosing(e);
			if (shuttingDown) return;
			Hide();
			e.Cancel = true;
		} //OnClosing

		void SetVisibility(Window user, DefaultItems items) {
			foreach (var item in menu.Items) {
				MenuItem mi = item as MenuItem;
				if (mi != null)
					mi.Visibility = Visibility.Collapsed;
			} // loop
			int visibleCount = 0;
			if ((items & DefaultItems.Cancel) > 0) {
				cancel.Visibility = Visibility.Visible;
				++visibleCount;
			} //if
			if ((items & DefaultItems.Close) > 0) {
				close.Visibility = Visibility.Visible;
				++visibleCount;
			} //if
			if ((items & DefaultItems.ShowMainWindow) > 0 && user.Owner != Application.Current.MainWindow) {
				main.Visibility = Visibility.Visible;
				++visibleCount;
			} //if
			if ((items & DefaultItems.ExitApplication) > 0) {
				shutdown.Visibility = Visibility.Visible;
				++visibleCount;
			} //if
			if (visibleCount > 2 && shutdown.Visibility == Visibility.Visible)
				separator.Visibility = Visibility.Visible;
		} //SetVisibility

		protected override void OnDeactivated(EventArgs e) {
			base.OnDeactivated(e);
			foreach (var item in menu.Items) {
				MenuItem mi = item as MenuItem;
				if (mi != null)
					mi.Visibility = Visibility.Visible;
			} // loop
			Hide();
		} //OnDeactivated

		static Rect? ClienAreaOnScreen(Window window) {
			int cnt = VisualTreeHelper.GetChildrenCount(window);
			if (cnt < 1) return null;
			var obj = VisualTreeHelper.GetChild(window, 0);
			Visual vi = obj as Visual;
			if (vi == null) return null;
			var bounds = VisualTreeHelper.GetContentBounds(vi);
			Point origin = vi.PointToScreen(new Point()); ;
			Size size = bounds.Size;
			Rect rect = new Rect(origin, size);
			return rect;
		} //ClienAreaOnScreen

		void SetLocation(Window window) {
			Rect? rect = ClienAreaOnScreen(window);
			if (rect == null) return; //SA go to mouse?
			double top = rect.Value.Top;
			if (top < 0) top = 0;
			if ((top + this.ActualHeight) > SystemParameters.WorkArea.Height)
				top = SystemParameters.WorkArea.Height - this.ActualHeight;
			double left = rect.Value.Right - ActualWidth / 2;
			if (left < 0) left = 0;
			if ((left + this.ActualWidth) > SystemParameters.WorkArea.Width)
				left = SystemParameters.WorkArea.Width - this.ActualWidth;
			this.Left = left;
			this.Top = top;
		} //SetLocation

		Window closing;
		DefaultItems lastItemUsage;
		bool shuttingDown;

		ClientClosingAction clientClosingAction;

	} //class ClosingWindowControl

} //namespace
