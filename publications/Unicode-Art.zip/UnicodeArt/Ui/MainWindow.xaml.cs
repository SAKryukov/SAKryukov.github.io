﻿/*  
    Unicode Art

    Copyright © 1 April, 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1179876/Unicode-Art
 
*/

using System.Windows;

namespace UnicodeArt.Ui {

	public partial class MainWindow : Window {

		public MainWindow() {
			InitializeComponent();
			Setup();			
		} //MainWindow

	} //class MainWindow

} //namespace UnicodeArt.Ui
