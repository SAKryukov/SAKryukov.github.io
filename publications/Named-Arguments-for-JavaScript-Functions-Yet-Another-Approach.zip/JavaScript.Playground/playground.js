var settings = {
	keys: {
		evaluate: 113, //F2
		enter: 13,
		escape: 27,
		hideConsole: 27 //Escape
	}, //keys
	colors: {
		consoleData: { background: "PaleGreen", foreground: "Black" },
		consoleError: { background: "Yellow", foreground: "DarkRed" },
		consoleDataFocused: { background: "#C6FDC6", foreground: "Black" },
		consoleErrorFocused: { background: "#FFFFAA", foreground: "DarkRed" }
	}, //colors
	textFeatures: { newLine: "\n", indentPad: "\t",
		autocompleteIndicatorStyle: "top: 0.3em; right: 2.2em; padding: 0.4em 1em 0.4em 1em; color: snow; background-color: rgba(96, 98, 120, 0.5);" +
			"border-radius: 0.3em; opacity: 0.7; font-size: 70%; " // font-family: Verdana, sans-serif"
	},
	smartFormatting: {
		features: { useSmartIndent: true, useTabs: true, tabSize: 4, useAutoBracket: true, useTidy: true, useCodeCompletion: true },
		formattingRules: {
			indent: [
				{ bra: "[", ket: "]", endOfLineKet: true, matchLeftWord: false, matchRightWord: false },
				{ bra: "{", ket: "}", endOfLineKet: true, matchLeftWord: false, matchRightWord: false }
			],
			autoBracket: [
				{ bra: "[", ket: "]", endOfLineOnly: true },
				{ bra: "{", ket: "}", endOfLineOnly: true },
				{ bra: "(", ket: ")", endOfLineOnly: true },
				{ bra: "'", ket: "'", endOfLineOnly: true },
				{ bra: "\"", ket: "\"", endOfLineOnly: true }
			],
			tidy: [
				{ before: ["===", "!==", "==", "++", "--", "&&", "||", "+=", "-=", "*=", "/=", "|=", "//", "&=", "^=", "!=", "=", "+", "-", "*", "/", "|", "&", "^", "{"], after: " $1 " },
				{ before: [",", ";", ":"], after: "$1 " },
				{ before: ["}"], after: " $1" }
			],
			tidyVerbatim: [ // inside these brackets, tidy is not applied, the content is used verbatim
				{ bra: "'", ket: "'" },
				{ bra: "\"", ket: "\"" }
			],
			autoComplete: [
				{ pattern: "wri*teLine (|);", breakPoint: "*", insertPoint: "|" }, //JavaScript.Playground/Calculator-specific
				{ pattern: "do* {|} while ()", breakPoint: "*", insertPoint: "|" },
				{ pattern: "whi*le (|)", breakPoint: "*", insertPoint: "|" },
				{ pattern: "swi*tch (|) {}", breakPoint: "*", insertPoint: "|" },
				{ pattern: "cas*e |: break;", breakPoint: "*", insertPoint: "|" },
				{ pattern: "try* {|} catch(exception) {}", breakPoint: "*", insertPoint: "|" },
				{ pattern: "thr*ow new |;", breakPoint: "*", insertPoint: "|" },
				{ pattern: "if* (|)", breakPoint: "*", insertPoint: "|" },
				{ pattern: "els*e |", breakPoint: "*", insertPoint: "|" },
				{ pattern: "var* |", breakPoint: "*", insertPoint: "|" },
				{ pattern: "ret*urn;|", breakPoint: "*", insertPoint: "|" },
				{ pattern: "fun*ction () {|}", breakPoint: "*", insertPoint: "|" },
				{ pattern: "for* (var index = 0; index < |; ++index) {}", breakPoint: "*", insertPoint: "|" }
			]
		}
	} //smartFormatting
}; //settings

var types = { string: typeof "?", object: typeof {}, function: typeof function () { }, number: typeof 1 };

if (!String.prototype.format) {
	Object.defineProperty(String.prototype, "format", {
		enumerable: false,
		configurable: false,
		writable: false,
		value: function () {
			var args = arguments;
			return this.replace(/{(\d+)}/g, function (match, number) {
				return args[number] != undefined
				? args[number]
       	 		: match;
			})
		}
	});
} //if !String.prototype.format

if (!String.empty) {
	Object.defineProperty(String, "empty", {
		enumerable: false,
		configurable: false,
		writable: false,
		value: ""
	});
} //if !String.empty

var write, writeLine; //API
var unlimited = { value: Number.POSITIVE_INFINITY };
if (!Object.prototype.dump) {
	Object.defineProperty(Object.prototype, "dump", {
		enumerable: false,
		configurable: false,
		writable: false,
		value: function (name, showFunctionBodies, maxRecursionLevels) {
			if (maxRecursionLevels === unlimited)
				maxRecursionLevels = unlimited.value;
			else if (!(maxRecursionLevels && typeof maxRecursionLevels == types.number && maxRecursionLevels > 0))
				maxRecursionLevels = 1;
			if (name === undefined || name === null) name = this;
			var recursionBreaker = [];
			recursionBreaker.push(this);
			function singleLevel(object, name, level) {
				var pad = String.empty;
				if (level && typeof level == types.number)
					for (var index = 0; index < level; ++index)
						pad += settings.textFeatures.indentPad;
				writeLine("{0}{1}:".format(pad, name));
				for (var index in object) {
					try { // maybe access exception:
						var value = object[index];
					} catch (e) {
						writeLine("{0}{1}{2}: <not accessible>".format(pad, settings.textFeatures.indentPad, index));
						continue;
					}
					if (level < maxRecursionLevels - 1 && value && (typeof value === types.object)) {
						if (recursionBreaker.indexOf(value) < 0) {
							recursionBreaker.push(value);
							singleLevel(value, index, level + 1);
						} else
							writeLine("{0}{1}: {2}&hellip;".format(pad + settings.textFeatures.indentPad, index, value));
						continue;
					} //if object
					var showQuotes = typeof value === types.string;
					var incomplete = String.empty;
					if (showQuotes) {
						var values = value.split(/[\r\n]/);
						if (values.length  == 2  && values[1] == String.empty)
							incomplete = "&ldsh;";
						else if (values.length > 1)
							incomplete = "&ldsh;&hellip;";
						value = values[0];
					} //if
					if (value === undefined || value === null) { value = value + String.empty; showQuotes = false; }
					if ((!showFunctionBodies) && (typeof value === types.function)) {
						var bodyIndex = value.toString().indexOf(")");
						value = value.toString().substr(0, bodyIndex + 1);
						showQuotes = false;
					} //if
					writeLine("{3}{0}: {2}{1}{4}{2}".format(
						index,
						value,
						showQuotes ? "\"" : String.empty,
						pad + settings.textFeatures.indentPad,
						incomplete));
				} //loop
			} //singleLevel
			singleLevel(this, name, 0);
			writeLine("end {0}".format(name))
			return this;
		} //value
	});
} //if !Object.prototype.dump

function Console(elements) {
	var text = null;
	var visible = true;
	var collapsedParent = elements.left.parentNode;
	this.reset = function () { text = null; setText(elements.editor, String.empty); };
	var writeArguments = function(argumentCollection, newLine) {
		if (!text) text = String.empty;
		for (var index = 0; index < argumentCollection.length; ++index) {
			text += argumentCollection[index];
			if (index < argumentCollection.length - 1)
				text += ", ";
		} //loop
		if (newLine)
			text += settings.textFeatures.newLine;
		return Array.prototype.slice.call(argumentCollection);
	};
	this.write = function () {
		return writeArguments(arguments); 
	}; //write
	this.writeLine = function () {
		return writeArguments(arguments, true);
	}; //this.writeLine 
	this.hide = function () {
		if (!visible) return;
		visible = false;
		[elements.splitter, elements.right].forEach(function (element) { collapsedParent.removeChild(element) })
		elements.editor.focus(); 
	}; //hide
	this.hide();
	elements.console.tabIndex = 0; // to make focusable
	elements.console.onfocus = function () {
		var colorSet;
		if (this.isError)
			colorSet = settings.colors.consoleErrorFocused;
		else
			colorSet = settings.colors.consoleDataFocused;
		this.style.background = colorSet.background;
		this.style.color = colorSet.foreground;
	}; //elements.right.onfocus
	elements.console.onblur = function () {
		var colorSet;
		if (this.isError)
			colorSet = settings.colors.consoleError;
		else
			colorSet = settings.colors.consoleData;
		this.style.background = colorSet.background;
		this.style.color = colorSet.foreground;
	}; //elements.right.onblur
	var colorIt = function (error) {
		elements.console.isError = error;
		if (document.activeElement === elements.console)
			elements.console.onfocus()
		else
			elements.console.onblur();
	}; //colorIt
	this.show = function (error, scrollDown) {
		setText(elements.console, text);
		colorIt(error);
		if (!visible) {
			visible = true;
			[elements.splitter, elements.right].forEach(function (element) { collapsedParent.appendChild(element) });
			setText(elements.console, text);
		} //if !visible
		if (scrollDown)
			elements.console.scrollTop = elements.console.scrollHeight;
	}; //show
	this.showException = function (exception) {
		colorIt(true);
		this.writeLine(exception.name + ":");
		this.writeLine(exception.message);
		var isKnown = function(object) {
			if (typeof object != types.number) return false;
			return !isNaN(object);
		}; //isKnown
		var knownPosition = isKnown(exception.lineNumber) && isKnown(exception.columnNumber);
		if (knownPosition)
			this.writeLine("Line: {0}, column: {1}".format(exception.lineNumber - 1, exception.columnNumber + 1)); //sic: -1 +1! see "bra" below
		this.show(true);
		if (knownPosition)
			setCaret(elements.editor, exception.lineNumber - 1, exception.columnNumber);
	}; //showException
	Object.defineProperty(this.constructor.prototype, "isVisible", {
		get: function () {
			return visible;
		} //get
	}); //isVisible
	Object.defineProperty(this.constructor.prototype, "isEmpty", {
		get: function () {
			return text === null;
		} //get
	}); //isEmpty
	Object.defineProperty(this.constructor.prototype, "current", {
		get: function () {
			return getText(elements.console);
		} //get
	}); //current
} //Console

var theConsole;

function setDockLayout() {
	var children = document.body.childNodes;
	var parts = [];
	for (var index = 0; index < document.body.childNodes.length; ++index)
		if (document.body.childNodes[index].nodeName.toLowerCase() == "div")
			parts.push(document.body.childNodes[index]);
	var top = [];
	for (var index = 0; index < 3; ++index) {
		var topElement = document.createElement("div");
		top.push(topElement);
		topElement.appendChild(parts[index]);
		document.body.appendChild(topElement);
	} //loop
	top[0].style.cssText = "position: absolute; top:0; right:0; left:0";
	top[1].style.cssText = "position: absolute; left:0; right:0";
	top[1].style.backgroundColor = window.getComputedStyle(parts[1]).backgroundColor;
	top[2].style.cssText = "position: absolute; bottom:0; right:0; left:0";
	parts[1].style.backgroundColor = window.getComputedStyle(parts[1]).backgroundColor;
	parts[1].style.position = "absolute";
	parts[1].style.left = 0; parts[1].style.right = 0;
	parts[1].style.top = 0; parts[1].style.bottom = 0;
	var margin = "0.2em";
	parts[1].style["margin-top"] = margin; parts[1].style["margin-bottom"] = margin;
	(window.onresize = function () {
		var topHeight = top[0].offsetHeight;
		top[1].style.top = topHeight;
		top[1].style.height = window.innerHeight - top[0].offsetHeight - top[2].offsetHeight;
	})();
} //setDockLayout

function setSmartFormatting(editor, options, autoCompleteMatchNotification) {
	var constants = { objectType: types.object, stringType: types.string, keyEnter: settings.keys.enter, keyEscape: settings.keys.escape, tab: settings.textFeatures.indentPad, blankSpace: " ", empty: String.empty };
	var indentPad = (options.features.useTabs) ? constants.tab : new String(new Array(options.features.tabSize + 1).join(constants.blankSpace));
	var newLine = "\n";
	(function autoDetectNewLineAndSetupTabs() {
		var saveValue = editor.value;
		editor.value = newLine;
		newLine = editor.value; //auto-detected
		editor.value = saveValue;
		if (editor.style.OTabSize !== undefined) editor.style.OTabSize = options.features.tabSize;
		if (editor.style.MozTabSize !== undefined) editor.style.MozTabSize = options.features.tabSize;
		if (editor.style.tabSize !== undefined) editor.style.tabSize = options.features.tabSize;
	})() //autoDetectNewLineAndSetupTabs
	var tidyRegex = (function createRegexTidyRules(rules) {
		var regex = [];
		for (var rule in rules) {
			var newRule = { before: constants.empty, after: rules[rule].after };
			for (var wordIndex = 0; wordIndex < rules[rule].before.length; ++wordIndex) {
				var word = constants.empty;
				for (var charIndex in rules[rule].before[wordIndex])
					word += "\\" + rules[rule].before[wordIndex][charIndex];
				if (newRule.before != constants.empty)
					newRule.before += "|";
				newRule.before += word;
			} //loop word
			newRule.before = "(" + newRule.before + ")";
			newRule.before = new RegExp(newRule.before, "g");
			regex.push(newRule);
		} //loop rule
		return regex;
	})(options.formattingRules.tidy); //createRegexTidyRules
	var tidyVerbatimRegex = (function createTidyVerbatimRegex(rules) {
		var escape = function(value) {
			var word = constants.empty
			for (var charIndex in value)
				word += "\\" + value[charIndex];
			return word;
		} //escape
		var regex = constants.empty;
		for (var rule in rules) {
			if (regex)
				regex += "|";
			regex += escape(rules[rule].bra) + ".*?" + escape(rules[rule].ket);
		} //loop
		regex = "(" + regex + ")";
		return new RegExp(regex, "g");
	})(options.formattingRules.tidyVerbatim); //createTidyVerbatimRegex
	var getCursor = function(editor) {
		return editor.selectionStart;
	} //getCursor
	var setCursor = function (editor, pos) {
		editor.selectionStart = pos;
		editor.selectionEnd = pos;
	} //setCursor
	var endsWith = function (src, key) {
		if (typeof src != constants.stringType) return false;
		if (typeof key != constants.stringType) return false;
		var index = src.lastIndexOf(key)
		return index >= 0 && index == src.length - key.length;
	} //endsWith
	var startsWith = function (src, key) {
		if (typeof src != constants.stringType) return false;
		if (typeof key != constants.stringType) return false;
		return src.lastIndexOf(key) == 0;
	} //startsWith
	var findWords = function (value, right) {
		var words = value.split(/[\s\n\r]/);
		var clearWords = [];
		for (var index = 0; index < words.length; ++index)
			if (words[index] != constants.empty)
				clearWords.push(words[index]);
		return (right) ? clearWords[0] : clearWords[clearWords.length - 1];
	} //findWords
	var parseCursorContext = function (editor) {
		var pos = getCursor(editor);
		var allText = editor.value;
		var leftChar = allText[pos - 1];
		var rightChar = allText[pos];
		var leftChar = allText[pos - 1];
		var rightChar = allText[pos];
		if (!leftChar) return;
		var left = allText.substring(0, pos);
		var right = allText.substring(pos);
		var rightmost = right.indexOf(newLine);
		if (rightmost >= 0)
			right = right.substr(0, rightmost);
		var leftmost = left.lastIndexOf(newLine);
		if (leftmost >= 0)
			left = left.substr(leftmost + newLine.length, pos);
		var leftWord = findWords(left, false);
		var rightWord = findWords(right, true);
		return { cursor: pos, left: { char: leftChar, word: leftWord, line: left }, right: { char: rightChar, word: rightWord, line: right } };
	} //parseCursorContext
	var insert = function (aValue) {
		if (!aValue) return;
		var startPos = editor.selectionStart;
		var endPos = editor.selectionEnd;
		editor.value = editor.value.substring(0, startPos)
			+ aValue
			+ editor.value.substring(endPos, editor.value.length);
	} //insert
	var removeBack = function (cursorContext, count) {
		if (!count) return;
		var left = editor.value.substring(0, cursorContext.cursor);
		var right = editor.value.substring(cursorContext.cursor);
		left = left.slice(0, -count);
		editor.value = left + right;
	} //removeBack
	var countTabs = function (source) {
		var match = (options.features.useTabs) ? constants.tab : constants.blankSpace;
		var result = 0;
		for (var index = 0; index < source.length; ++index)
			if (source[index] == match)
				++result;
			else
				break;
		return source.substr(0, result);
	} //countTabs	
	function tidy(value) {
		var preserveQuotationMatchBefore = value.match(tidyVerbatimRegex);
		for (var index in tidyRegex)
			value = value.replace(tidyRegex[index].before, tidyRegex[index].after);
		value = value.replace(/\s+/g, constants.blankSpace);
		if (preserveQuotationMatchBefore) {
			var preserveQuotationMatchAfter = value.match(tidyVerbatimRegex);
			if (preserveQuotationMatchAfter)
				for (var index=0; index < preserveQuotationMatchAfter.length; ++index)
					value = value.replace(preserveQuotationMatchAfter[index], preserveQuotationMatchBefore[index]);
		} //if
		return value.trim();
	} //tidy
	function handleCharacter(character, context) {
		var trimmedRightLine = context.right.line.trim();
		for (var index = 0; index < options.formattingRules.autoBracket.length; ++index) {
			var rule = options.formattingRules.autoBracket[index];
			if (!(rule.bra && rule.ket)) continue;
			if (character != rule.bra) continue;
			if (rule.endOfLineOnly && trimmedRightLine != constants.empty) continue;
			insert(character + rule.ket);
			setCursor(this, context.cursor + 1);
			return true;
		} //loop
	} //handleCharacter
	function recognizeAutocomplete(context) {
		if (context.right.line) return;
		for (var index = 0; index < options.formattingRules.autoComplete.length; ++index) {
			var rule = options.formattingRules.autoComplete[index];
			if (!rule.breakPoint) continue;
			if (!rule.insertPoint) continue;
			if (rule.breakPoint.length != 1) continue;
			if (rule.insertPoint.length != 1) continue;
			var reg = new RegExp("[" + rule.breakPoint + rule.insertPoint + "]", "g");
			var parts = rule.pattern.split(reg);
			if (parts.length != 3) continue;
			var all = parts.join(constants.empty);
			var min = parts[0].length;
			var match;
			for (length = all.length - 1; length >= min; --length)
				if (endsWith(context.left.line, all.slice(0, length))) {
					match = length; break;
				} //if
			if (!match) continue;
			return { all: all, toInsert: all.slice(length), cursorPosition: context.cursor + all.length - match - parts[2].length }
		} //loop
	} //recognizeAutocomplete
	var keyPressHandler = function (ev) {
		ev = ev || window.event;
		var character = String.fromCharCode(ev.charCode);
		var context = parseCursorContext(this);
		if (handleCharacter.call(this, character, context)) {
			ev.preventDefault();
			return false;
		} //if
	}; //keyPressHandler
	var keyUpClickHandler = function (ev) {
		ev = ev || window.event;
		if (ev.keyCode && ev.keyCode == constants.keyEscape)
			return;
		var context = parseCursorContext(this);
		this.match = recognizeAutocomplete.call(this, context);
		if (!autoCompleteMatchNotification) return;
		var autoCompleteMatchNotificationArgument = (this.match) ? this.match.all : constants.empty;
		autoCompleteMatchNotification(autoCompleteMatchNotificationArgument);
	} //keyUpClickHandler
	var keyDownHandler = function (ev) {
		ev = ev || window.event;
		if (ev.shiftKey || ev.ctrlKey || ev.altKey || ev.metaKey) return;
		if (ev.keyCode == constants.keyEscape) {
			this.match = null;
			if (autoCompleteMatchNotification)
				autoCompleteMatchNotification(null);
			return;
		} //if keyEscape
		if (ev.keyCode != constants.keyEnter) return;
		var context = parseCursorContext(this);
		if (this.match && options.features.useCodeCompletion) {
			insert(this.match.toInsert);
			setCursor(this, this.match.cursorPosition);
			ev.preventDefault();
			return false;			
		} // if 			
		var pad = countTabs(context.left.line);
		var indent = false;
		if (options.features.useTidy) {
			var tidyLine = pad + tidy(context.left.line);
			var cursorShift = tidyLine.length - context.left.line.length;
			removeBack(context, context.left.line.length);
			setCursor(this, context.cursor - context.left.line.length)
			var cursorShift = tidyLine.length - context.left.line.length;
			insert(tidyLine); setCursor(this, context.cursor + cursorShift);
			context = parseCursorContext(this);
		} //if useTidy
		if (options.features.useSmartIndent) {
			for (var index = 0; index < options.formattingRules.indent.length; ++index) {
				var rule = options.formattingRules.indent[index];
				var ket = rule.ket || constants.empty;
				var leftMatches = (rule.matchLeftWord) ? context.left.word == rule.bra : endsWith(context.left.line, rule.bra);
				if (leftMatches) {
					var rightMatches = (rule.matchRightWord) ? context.right.word && context.right.word == ket : context.right.word && startsWith(context.right.line, ket);
					var lineEndMatches = rule.endOfLineKet && !context.right.word;
					if (rightMatches)
						insert(newLine + pad + indentPad + newLine + pad);
					else if (lineEndMatches)
						insert(newLine + pad + indentPad);
					if (rightMatches || lineEndMatches) {
						setCursor(this, context.cursor + pad.length + indentPad.length + 1);
						indent = true;
						break;
					} //if right/end-of-line matches
				} //if left matches		
			} //loop
			if (!indent) {
				insert(newLine + pad);
				setCursor(this, context.cursor + pad.length + 1);
			} //if
		} else
			return; //if useSmartIndent
		ev.preventDefault();
		return false;			
	}; //keyDownHandler
	var pasteHandler = function (ev) {
		if (!ev.clipboardData) return;
		var data = ev.clipboardData.getData('text/plain');
		if (!data) return;
		this.match = undefined;
		if (!autoCompleteMatchNotification) return;
		autoCompleteMatchNotification(constants.empty);
	} //pasteHandler	
	editor.removeEventListener("keydown", keyDownHandler);
	editor.removeEventListener("keypress", keyPressHandler);
	editor.removeEventListener("keyup", keyUpClickHandler);
	editor.removeEventListener("click", keyUpClickHandler);
	editor.removeEventListener("paste", pasteHandler);
	if (options.features.useSmartIndent || options.features.useTidy || options.features.useCodeCompletion)
		editor.addEventListener("keydown", keyDownHandler);
	if (options.features.useAutoBracket)
		editor.addEventListener("keypress", keyPressHandler);
	if (options.features.useCodeCompletion) {
		editor.addEventListener("keyup", keyUpClickHandler);
		editor.addEventListener("click", keyUpClickHandler);
		editor.addEventListener("paste", pasteHandler);
	} //if
}; //setSmartFormatting

document.body.onload = function () {

	var elements = {
		editor: document.getElementById("editor"),
		strictMode: document.getElementById("strictMode"),
		strictModeLabel: document.getElementById("strictModeLabel"),
		result: document.getElementById("result"),
		left: document.getElementById("left"),
		right: document.getElementById("right"),
		start: document.getElementById("start"),
		console: document.getElementById("console"),
		splitter: document.getElementById("splitter"),
		buttonClose: document.getElementById("buttonClose"),
		status: document.getElementById("status")
	}; //elements

	var indicator = document.createElement("div");
	indicator.style.cssText = settings.textFeatures.autocompleteIndicatorStyle;
	indicator.style.position = "absolute";
	indicator.style.display = "none";
	elements.editor.parentElement.appendChild(indicator);
	setSmartFormatting(elements.editor, settings.smartFormatting, function (value) {
		if (value) {
			indicator.innerHTML = "Insert \"{0}\"? (Enter/Escape)".format(value);
			indicator.style.display = "block";
		} else
			indicator.style.display = "none";
	});

	(function adjustAndApplySettings(elements) {
		var saveValue = elements.editor.value;
		elements.editor.value = settings.textFeatures.newLine;
		settings.textFeatures.newLine = elements.editor.value;
		elements.editor.value = saveValue;
	})(elements); //adjustAndApplySettings

	(function drawCloseButton(buttonClose, borderSample) {
		var style = getComputedStyle(buttonClose);
		var color = style.getPropertyValue("color");
		var size = parseInt(style.getPropertyValue("width"));
		var delta = parseInt(style.getPropertyValue("padding-left"));
		style = getComputedStyle(borderSample);
		var background = style.getPropertyValue("border-left-color");
		buttonClose.style.backgroundColor = background;
		buttonClose.width = size;
		buttonClose.height = size;
		var buttonCloseContent = buttonClose.getContext("2d");
		buttonCloseContent.lineWidth = 2;
		buttonCloseContent.translate(-0.5, -0.5);
		buttonCloseContent.strokeStyle = color;
		buttonCloseContent.beginPath();
		buttonCloseContent.moveTo(delta, delta);
		buttonCloseContent.lineTo(size - delta, size - delta);
		buttonCloseContent.moveTo(size - delta, delta);
		buttonCloseContent.lineTo(delta, size - delta);
		buttonCloseContent.stroke();
	})(elements.buttonClose, elements.left); //drawCloseButton

	setDockLayout();
	var dragging;
	elements.splitter.onmousedown = function (ev) {
		ev = ev || window.event;
		if (ev.button != 0) return;
		var st = window.getComputedStyle(elements.left);
		dragging = { width: parseInt(st.getPropertyValue("width")), mousePositon: ev.pageX };
	}; //elements.splitter.onmousedown
	window.onmouseup = function (ev) {
		ev = ev || window.event;
		if (!dragging) return;
		var ev = ev || window.event;
		if (ev.button != 0) return;
		dragging = null;
	}; //window.onmouseup
	window.onmousemove = function (ev) {
		ev = ev || window.event;
		var ev = ev || window.event;
		if (!dragging) return;
		var newWidth = dragging.width + ev.pageX - dragging.mousePositon;
		elements.left.style.width = newWidth;
	}; //window.onmousemove	

	theConsole = new Console(elements);
	write = theConsole.write;
	writeLine = theConsole.writeLine;

	var evaluateStrictOnly;
	var evaluate = function () {
		function strictEval(text) { "use strict"; return (eval(text)) }
		var isStrict = elements.strictMode.checked;
		if (evaluateStrictOnly != undefined)
			isStrict = evaluateStrictOnly;
		theConsole.reset();
		try {
			var bra = "with (Math) {\n";
			var ket = "\n}";
			if (isStrict) bra = "\n";
			if (isStrict) ket = String.empty;
			var text = bra + elements.editor.value + ket;
			if (isStrict)
				elements.result.value = strictEval(text);
			else
				elements.result.value = eval(text);
		} catch (e) { elements.result.value = String.empty; theConsole.showException(e); return; }
		if (theConsole.isEmpty)
			theConsole.hide();
		else
			theConsole.show(false, true);
	}; //evaluate

	elements.start.onclick = evaluate;
	elements.buttonClose.onclick = function () { theConsole.hide(); };

	(function setCursorPositionEvents() {
		var clipboardDataNormalizer = document.createElement("textarea");
		var showCursorPosition = function (data) {
			var line = elements.editor.value.substring(0, elements.editor.selectionStart);
			if (data) line += data;
			var split = line.split(settings.textFeatures.newLine);
			var y = split.length;
			var x = split[split.length - 1].length + 1;
			elements.status.innerHTML = "{0} : {1}".format(y, x);
		}; //showCursorPosition
		elements.editor.onfocus = function () { showCursorPosition(); };
		elements.editor.onclick = function () { showCursorPosition(); };
		elements.editor.onkeyup = function () { showCursorPosition(); };
		elements.editor.onpaste = function (ev) {
			if (!ev.clipboardData) return;
			var data = ev.clipboardData.getData('text/plain');
			clipboardDataNormalizer.value = data;
			data = clipboardDataNormalizer.value;
			showCursorPosition(data);
		}; //elements.editor.onpaste
		var chainEditorOnKeyDown = elements.editor.onkeydown;
		elements.editor.onkeydown = function (ev) {
			var result = chainEditorOnKeyDown.call(this, ev);
			showCursorPosition();
			return result;
		}; //elements.editor.onkeydown
		showCursorPosition();
	})(); //setCursorPositionEvents

	document.onkeydown = function (event) {
		event = event || window.event;
		switch (event.keyCode) {
			case settings.keys.hideConsole: theConsole.hide(); event.preventDefault(); return false;
			case settings.keys.evaluate: evaluate(); event.preventDefault(); return false;
			case settings.keys.enter:
				if (!event.getModifierState("Control")) return;
				evaluate();
				event.preventDefault();
				return false;
		} //switch
	}; //document.onkeydown	

	// re-loading of page with restoration or controls, for strict mode switch:
	var persistence = {
		key: "S. A. Kryukov JavaScript Playground",
		store: function (checked, code) {
			sessionStorage.setItem(this.key, JSON.stringify({ checked: checked, code: code }));
		}, //store
		load: function () {
			var item = sessionStorage.getItem(this.key);
			if (item)
				return JSON.parse(item);
		} //load
	}; //persistence
	var item = persistence.load();
	if (item) {
		elements.editor.value = item.code;
		elements.strictMode.checked = item.checked;
	} //if

	elements.strictMode.onclick = function () {
		persistence.store(elements.strictMode.checked, elements.editor.value);
		window.location.reload();
	}; //strictMode.onclick
	
	if (typeof APIDataKey != typeof undefined) {
		var extractFileName = function (value) { return value.replace(/.*\/(.+)\..*/g, "$1"); };
		var item = sessionStorage.getItem(APIDataKey);
		sessionStorage.removeItem(APIDataKey);
		if (item) {
			var demoScript = JSON.parse(item);
			if (demoScript) {
				elements.editor.value = demoScript.sample;
				evaluateStrictOnly = demoScript.strict;
				if (evaluateStrictOnly != undefined) {
					elements.strictMode.style.visibility = "hidden";
					elements.strictModeLabel.innerHTML = (evaluateStrictOnly) ? "Strict mode" : String.empty;
				} //if
				if (!demoScript.doNotEvaluate)
					evaluate();
				if (demoScript.title)
					document.title = "{0}: {1}".format(document.title, demoScript.title);
			} //if demoScript
		} //if item
	} //if APIDataKey

}; //document.body.onload

function setText(object, text) { object.innerHTML = text; }
function getText(object) { return object.innerHTML; }
function setCaret(input, line, col) {
	var lines = input.value.split(settings.textFeatures.newLine);
	var position = 0;
	for (var index = 0; (index < lines.length) && (index < line - 1) ; ++index)
		position += lines[index].length + 1;
	input.setSelectionRange(position + col, position + col + 1);
} //setCaret

// API:
function hex (par, upcase) {
	var hexdigit = "0123456789abcdef";
	var result = String.empty;
	if (upcase) hexdigit = hexdigit.toUpperCase();
	for (var jj = 0 ; jj < (32 / 4) ; jj++) {
		index = (par >>> (jj * 4)) & 0xF;
		result = hexdigit.charAt(index) + result;
	} //loop
	return result;
} //hex
function bin (par) {
	var result = String.empty;
	for (var index = 0; index < 32 ; ++index) {
		if ((par & (1 << index)) != 0) result = "1" + result;
		else result = "0" + result;
	} //loop
	return result;
} //bin
function f2c (f) {
	return 5 / 9 * (f - 32);
} //f2c
function c2f (c) {
	return 9 / 5 * c + 32;
} //c2f
