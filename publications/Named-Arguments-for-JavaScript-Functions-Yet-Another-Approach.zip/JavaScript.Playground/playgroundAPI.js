var APIDataKey = "S. A. Kryukov JavaScript Playground API";

function showSample(title, doNotEvaluate, strict) {
	var scripts = document.getElementsByTagName("script");
	var path = scripts[0].src;
	path = path.split('?')[0];
	path = path.split('/').slice(0, -1).join('/')+'/index.html';
	var code = (function() {
		for(var index = 0; index < scripts.length; ++index) {
			var script = scripts[index];
			var text = script.text;
			if (text)
				return text;
		} //loop
	})().trim();
	if (!title)
		title = (function extractFileName(value) {
			return value.replace(/.*\/(.+)\..*/g, "$1");
		})(window.location.toString());
	sessionStorage.setItem(APIDataKey, JSON.stringify({sample:code, doNotEvaluate:doNotEvaluate, strict:strict, title:title}));
	document.location = path;
} //showSample
