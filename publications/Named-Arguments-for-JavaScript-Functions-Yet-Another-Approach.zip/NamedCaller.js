/*

namedCaller: passing JavaScript function arguments by name

Copyright (c) 2015 by Sergey A Kryukov
http://www.SAKryukov.org
http://SAKryukov.org/freeware/calculator
http://www.codeproject.com/Members/SAKryukov

Published: http://www.codeproject.com/Articles/1045966/Named-Arguments-for-JavaScript-Functions-Yet-Anoth

*/
"use strict";

function namedCaller(targetFunction, targetFunctionPropertyName) {

	if (!targetFunctionPropertyName) targetFunctionPropertyName = "targetFunction";

	var wrapper = (function createWrapperFunction() {
		var prepareArguments = function (self) {
			var argumentValues = [];
			for (var index = 0; index < argumentNames.length; ++index)
				argumentValues[index] = self[argumentNames[index]];
			return argumentValues;
		} //prepareArguments
		var cleanUp = function (self) {
			for (var index = 0; index < argumentNames.length; ++index)
				self[argumentNames[index]] = undefined;
		} //cleanUp
		return function () {
			var argumentValues = prepareArguments(wrapper);
			cleanUp(wrapper);
			return targetFunction.apply(this, argumentValues);
		} //wrapper
	})(); //createWrapperFunction

	var argumentNames = (function parseArguments(self) {
		var argumentNames = targetFunction.toString().match(/function[^(]*\(([^)]*)\)/)[1].split(/,\s*/);
		if (!argumentNames || !argumentNames[0]) // case of "function () {...}"
			argumentNames = [];
		for (var index = 0; index < argumentNames.length; ++index)
			self[argumentNames[index]] = undefined;
		return argumentNames;
	})(wrapper); //parseArguments

	Object.defineProperty(wrapper, targetFunctionPropertyName, { enumerable: true, value: targetFunction });

	Object.seal(wrapper);

	return wrapper;

}; //namedCaller
