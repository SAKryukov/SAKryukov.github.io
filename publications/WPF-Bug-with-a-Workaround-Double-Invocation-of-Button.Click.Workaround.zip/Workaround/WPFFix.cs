﻿namespace WpfFix {
    using System;
    using System.Windows.Controls;

    internal class FixedButton : Button {

        protected override void OnClick() {
            if (Click != null)
                Dispatcher.Invoke(new Action(() => {
                    Click.Invoke(this, new EventArgs());
                }));
        } //OnClick

        new internal event EventHandler Click;

    } //class FixedButton

} //namespace WPFFix
