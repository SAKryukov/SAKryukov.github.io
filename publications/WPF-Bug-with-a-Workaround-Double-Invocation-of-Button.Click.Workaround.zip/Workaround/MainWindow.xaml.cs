﻿namespace Workaround {
    using System;
    using System.Windows;
    
    public partial class WorkaroundDemoWindow : Window {

        public WorkaroundDemoWindow() {
            InitializeComponent();
            this.button.Focus();
            this.button.Click += (sender, evenArgs) => {
                throw new ApplicationException("Button click");
            };
        } //ReproduceProblemWindow

    } //class ReproduceProblemWindow

} //namespace HowToReproduce
