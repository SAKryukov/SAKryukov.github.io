﻿namespace Workaround {
    using System;
    using System.Windows;
    using StringBuilder = System.Text.StringBuilder;
    using StringList = System.Collections.Generic.List<string>;
    using IStringList = System.Collections.Generic.IList<string>;

    public partial class App : Application {

        static class DefinitionSet {
            internal const string FormatException = "{0}:\n{1}";
            internal const string FormatTitle = "{0} Exception";
            internal const string ExceptionDelimiter = "\n\n";
        } //class DefinitionSet

        internal App() {
            DispatcherUnhandledException += (sender, eventArgs) => {
                Func<Exception, string> exceptionTextFinder = (ex) => {
                    Action<Exception, IStringList> exceptionTextCollector = null; // for recursiveness
                    exceptionTextCollector = (exc, aList) => {
                        aList.Add(string.Format(
                            DefinitionSet.FormatException,
                            exc.GetType().Name,
                            exc.Message));
                        if (exc.InnerException != null)
                            exceptionTextCollector(exc.InnerException, aList);
                    }; //exceptionTextCollector
                    IStringList list = new StringList();
                    exceptionTextCollector(ex, list);
                    StringBuilder sb = new StringBuilder();
                    bool first = true;
                    foreach (string item in list)
                        if (first) {
                            sb.Append(item);
                            first = false;
                        } else
                            sb.Append(DefinitionSet.ExceptionDelimiter + item);
                    return sb.ToString();
                };
                MessageBox.Show(
                    exceptionTextFinder(eventArgs.Exception),
                    string.Format(
                        DefinitionSet.FormatTitle,
                        App.Current.MainWindow.Title),
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                eventArgs.Handled = true;
            }; //DispatcherUnhandledException
        } //App

    } //class App

} //namespace Workaround