﻿/*
	Never Ever Add Strings to WPF Lists

	Copyright (C) 2017 by Sergey A Kryukov
	http://www.SAKryukov.org
	http://www.codeproject.com/Members/SAKryukov	

	Original publication:
	https://www.codeproject.com/Articles/1176230/WPF-Never-Add-Strings
*/
namespace NeverEverAddStringsToWPFLists {
    using Di = System.Collections.Generic.Dictionary<string, Topic>;

    enum Topic {
        StringProblem, IntProblem, DataBindingProblem,
        SolutionString, SolutionDataBinding, SolutionCustomItemType, SolutionCustomItemTypeDataBinding,
    }

} //namespace NeverEverAddStringsToWPFLists
