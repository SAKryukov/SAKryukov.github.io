﻿/*
	Never Ever Add Strings to WPF Lists

	Copyright (C) 2017 by Sergey A Kryukov
	http://www.SAKryukov.org
	http://www.codeproject.com/Members/SAKryukov	

	Original publication:
	https://www.codeproject.com/Articles/1176230/WPF-Never-Add-Strings
*/
namespace NeverEverAddStringsToWPFLists.Ui {
    using System.Windows;
    using System.Windows.Controls;
    using ImplementaitonDictionary = System.Collections.Generic.Dictionary<Topic, MainWindow.ItemsControlHandlerBase>;

    public partial class MainWindow : Window {

        public MainWindow() {
            InitializeComponent();
            ValidateTreeView(treeView);
            PopulateImplementationTypes();
            help.Text = "\n\n\n\n\n\n"; //SA???
            System.Action scrollToEnd = () => {
                int count = listBox.Items.Count;
                if (count < 1) return;
                listBox.ScrollIntoView(listBox.Items[count - 1]);
            }; //scrollToEnd
            listBox.SelectionChanged += (sender, eventArgs) => { ShowSelectedItem(); };
            textBoxInput.PreviewTextInput += (sender, eventArgs) => {
                eventArgs.Handled = currentImplementation.FilterTextBoxInput(eventArgs.Text);
            }; //textBoxInput.PreviewTextInput
            buttonAdd.Click += (sender, eventArgs) => { currentImplementation.AddNewItem(listBox, textBoxInput.Text); scrollToEnd(); };
            buttonScroll.Click += (sender, eventArgs) => { scrollToEnd(); };
            treeView.SelectedItemChanged += (sender, eventArgs) => { TreeSelectionHandler((TreeView)sender); };
        } //MainWindow

        void ShowSelectedItem() { textBlockSelected.Text = currentImplementation.GetSelectedItem(listBox); }

        protected override void OnContentRendered(System.EventArgs e) {
            base.OnContentRendered(e);
            SizeToContent = SizeToContent.Manual;
            MinHeight = RenderSize.Height;
            MaxHeight = RenderSize.Height;
            MinWidth = RenderSize.Width;
            // fix column width:
            gridFixed.ColumnDefinitions[1].Width = new GridLength(gridFixed.ColumnDefinitions[1].ActualWidth);
            treeView.Focus();
            TreeSelectionHandler(treeView);
            InstantiateImplementation(Topic.StringProblem).Populate(this.listBox); //SA???
            ShowSelectedItem();
        } //OnContentRendered

        void ValidateTreeView(TreeView treeView) {
            foreach (var item in treeView.Items) ValidateTreeViewItem((TreeViewItem)item);
        } //ValidateTreeView
        void ValidateTreeViewItem(TreeViewItem node) {
            object context = node.DataContext;
            if (context != null) {
                System.Enum.Parse(typeof(Topic), context.ToString());
            } //if
            foreach (var item in node.Items) ValidateTreeViewItem((TreeViewItem)item);
        } //ValidateTreeViewItem
        Topic? GetTopic(TreeViewItem item) {
            object context = item.DataContext;
            if (context == null) return null;
            return (Topic)System.Enum.Parse(typeof(Topic), context.ToString());
        } //GetTopic
        void TreeSelectionHandler(TreeView view) {
            Topic? topic = GetTopic((TreeViewItem)view.SelectedItem);
            if (topic == null)
                currentImplementation = null;
            else
                currentImplementation = InstantiateImplementation(topic.Value);
            gridFixed.IsEnabled = currentImplementation != null;
            if (currentImplementation == null) return;
            currentImplementation.Populate(listBox);
            help.Text = currentImplementation.Help;
        } //TreeSelectionHandler

        ItemsControlHandlerBase currentImplementation;
        static ImplementaitonDictionary implementationDictionary = new ImplementaitonDictionary();

        internal abstract class ItemsControlHandlerBase {
            internal virtual void Populate(ListBox listBox) {
                listBox.ItemsSource = null;
                listBox.Items.Clear();
            } //Populate
            internal abstract string GetSelectedItem(ListBox listBox);
            internal abstract void AddNewItem(ListBox listBox, string value);
            internal virtual bool FilterTextBoxInput(string badText) { return false; }
            internal abstract string Help { get; }
        } //PreparationBase

        static void PopulateImplementationTypes() {
            implementationDictionary.Add(Topic.StringProblem, new StringControlHandler());
            implementationDictionary.Add(Topic.IntProblem, new IntControlHandler());
            implementationDictionary.Add(Topic.DataBindingProblem, new DataBindingProblemControlHandler());
            implementationDictionary.Add(Topic.SolutionString, new SolutionStringControlHandler());
            implementationDictionary.Add(Topic.SolutionDataBinding, new SolutionStringDataBindingControlHandler());
            implementationDictionary.Add(Topic.SolutionCustomItemType, new SolutionCustomItemTypeControlHandler());
            implementationDictionary.Add(Topic.SolutionCustomItemTypeDataBinding, new SolutionCustomItemTypeDataBindingControlHandler());
        } //PopulateImplementationTypes
 
        ItemsControlHandlerBase InstantiateImplementation(Topic topic) {
            ItemsControlHandlerBase availableImplementation;
            if (implementationDictionary.TryGetValue(topic, out availableImplementation))
                return availableImplementation;
            else
                return null;
        } //InstantiateImplementation

    } //class MainWindow

} //namespace NeverEverAddStringsToWPFLists.Ui
