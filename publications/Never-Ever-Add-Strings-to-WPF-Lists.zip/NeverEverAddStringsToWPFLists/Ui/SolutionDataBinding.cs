﻿/*
	Never Ever Add Strings to WPF Lists

	Copyright (C) 2017 by Sergey A Kryukov
	http://www.SAKryukov.org
	http://www.codeproject.com/Members/SAKryukov	

	Original publication:
	https://www.codeproject.com/Articles/1176230/WPF-Never-Add-Strings
*/
namespace NeverEverAddStringsToWPFLists.Ui {
    using System.Windows.Controls;
    using ItemObservableCollection = System.Collections.ObjectModel.ObservableCollection<System.Windows.Controls.ListBoxItem>;

    class SolutionStringDataBindingControlHandler : MainWindow.ItemsControlHandlerBase {

        ItemObservableCollection list = new ItemObservableCollection();

        internal override void Populate(ListBox listBox) {
            base.Populate(listBox);
            list.Clear();
            string[] items = new string[] { "one", "two", "one", "two", };
            foreach (var item in items) {
                ListBoxItem lbitem = new ListBoxItem();
                lbitem.Content = item;
                list.Add(lbitem);
            } //loop
            listBox.ItemsSource = list;
        } //Populate

        internal override string GetSelectedItem(ListBox listBox) {
            var item = listBox.SelectedItem;
            if (item == null) return "<none>"; else return ((ListBoxItem)item).Content.ToString();
        } //GetSelectedItem

        internal override void AddNewItem(ListBox listBox, string value) {
            ListBoxItem lbitem = new ListBoxItem();
            lbitem.Content = value;
            list.Add(lbitem);
        } //AddNewItem

        internal override string Help {
            get {
                return "Same item type can be used with Data Binding";
            }
        } //Help

    } //SolutionStringDataBindingControlHandler

} //namespace NeverEverAddStringsToWPFLists.Ui
