﻿/*
	Never Ever Add Strings to WPF Lists

	Copyright (C) 2017 by Sergey A Kryukov
	http://www.SAKryukov.org
	http://www.codeproject.com/Members/SAKryukov	

	Original publication:
	https://www.codeproject.com/Articles/1176230/WPF-Never-Add-Strings
*/
namespace NeverEverAddStringsToWPFLists.Ui {
    using System.Windows.Controls;

    class SolutionStringControlHandler : MainWindow.ItemsControlHandlerBase {

        internal override void Populate(ListBox listBox) {
            base.Populate(listBox);
            string[] items = new string[] { "one", "two", "one", "two", };
            foreach (var item in items) {
                ListBoxItem lbitem = new ListBoxItem();
                lbitem.Content = item;
                listBox.Items.Add(lbitem);
            } //loop
        } //Populate

        internal override string GetSelectedItem(ListBox listBox) {
            var item = listBox.SelectedItem;
            if (item == null) return "<none>"; else return ((ListBoxItem)item).Content.ToString();
        } //GetSelectedItem

        internal override void AddNewItem(ListBox listBox, string value) {
            ListBoxItem lbitem = new ListBoxItem();
            lbitem.Content = value;
            listBox.Items.Add(lbitem);
        } //AddNewItem

        internal override string Help {
            get {
                return "Now everything works correctly.\n"
                    + "Items are not strings; they are of the type ListBoxItem.";
            }
        } //Help

    } //SolutionStringControlHandler

} //namespace NeverEverAddStringsToWPFLists.Ui
