﻿/*
	Never Ever Add Strings to WPF Lists

	Copyright (C) 2017 by Sergey A Kryukov
	http://www.SAKryukov.org
	http://www.codeproject.com/Members/SAKryukov	

	Original publication:
	https://www.codeproject.com/Articles/1176230/WPF-Never-Add-Strings
*/
namespace NeverEverAddStringsToWPFLists.Ui {
    using System.Windows.Controls;
    using ItemCollection = System.Collections.ObjectModel.ObservableCollection<MyItem>;

    class MyItem {
        internal MyItem(string content) { this.Content = content; }
        internal string Content { get; set; }
        public override string ToString() { return Content; }
		// this is what can be used to reproduce the problem:
		/*
		public override bool Equals(object obj) {
			if (obj == null) return false;
			MyItem myItem = obj as MyItem; // dynamic cast
			if (myItem == null) return false;
			return myItem.Content == Content;
		} //Equals
		public override int GetHashCode() {
			return Content.GetHashCode();
		} //GetHashCode
		*/
    } //class MyItem

    class SolutionCustomItemTypeControlHandler : MainWindow.ItemsControlHandlerBase {
        internal override void Populate(ListBox listBox) {
            base.Populate(listBox);
            string[] items = new string[] { "one", "two", "one", "two", };
            foreach (var item in items)
                listBox.Items.Add(new MyItem(item));
        } //Populate
        internal override string GetSelectedItem(ListBox listBox) {
            var item = listBox.SelectedItem;
            if (item == null) return "<none>"; else return ((MyItem)item).Content.ToString();
        } //GetSelectedItem
        internal override void AddNewItem(ListBox listBox, string value) { listBox.Items.Add(new MyItem(value)); }
        internal override string Help {
            get {
                return "A custom reference-type data type can be used to wrap\n"
                + "a primitive-type or string item value.\n\n"
                + "It only needs to return appropriate value in overriden System.Object.ToString().";
            }
        } //Help
    } //SolutionCustomItemTypeControlHandler

    class SolutionCustomItemTypeDataBindingControlHandler : MainWindow.ItemsControlHandlerBase {
        ItemCollection list = new ItemCollection();
        internal override void Populate(ListBox listBox) {
            base.Populate(listBox);
            list.Clear();
            string[] items = new string[] { "one", "two", "one", "two", };
            foreach (var item in items)
                list.Add(new MyItem(item));
            listBox.ItemsSource = list;
        } //Populate
        internal override string GetSelectedItem(ListBox listBox) {
            var item = listBox.SelectedItem;
            if (item == null) return "<none>"; else return ((MyItem)item).Content.ToString();
        } //GetSelectedItem
        internal override void AddNewItem(ListBox listBox, string value) { list.Add(new MyItem(value)); }
        internal override string Help {
            get {
                return "The same custom data type can be used with Data Binding";
            }
        } //Help
    } //SolutionCustomItemTypeDataBindingControlHandler


} //namespace NeverEverAddStringsToWPFLists.Ui
