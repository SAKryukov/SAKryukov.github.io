﻿/*
	Never Ever Add Strings to WPF Lists

	Copyright (C) 2017 by Sergey A Kryukov
	http://www.SAKryukov.org
	http://www.codeproject.com/Members/SAKryukov	

	Original publication:
	https://www.codeproject.com/Articles/1176230/WPF-Never-Add-Strings
*/
namespace NeverEverAddStringsToWPFLists.Ui {
    using System.Windows.Controls;
    using StringObservableCollection = System.Collections.ObjectModel.ObservableCollection<string>;

    class DataBindingProblemControlHandler : MainWindow.ItemsControlHandlerBase {
        StringObservableCollection list = new StringObservableCollection();
        internal override void Populate(ListBox listBox) {
            base.Populate(listBox);
            list.Clear();
            list.Add("one");
            list.Add("two");
            list.Add("one");
            list.Add("two");
            listBox.ItemsSource = list;
        } //Populate
        internal override string GetSelectedItem(ListBox listBox) {
            var item = listBox.SelectedItem;
            if (item == null) return "<none>"; else return item.ToString();
        } //GetSelectedItem
        internal override void AddNewItem(ListBox listBox, string value) {
            list.Add(value);
        } //AddNewItem
        internal override string Help {
            get {
                return "Data Binding does not really help.";
            }
        } //Help
    } //DataBindingProblemControlHandler

} //namespace NeverEverAddStringsToWPFLists.Ui
