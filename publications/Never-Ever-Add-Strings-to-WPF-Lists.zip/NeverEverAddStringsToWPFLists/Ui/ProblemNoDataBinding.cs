﻿/*
	Never Ever Add Strings to WPF Lists

	Copyright (C) 2017 by Sergey A Kryukov
	http://www.SAKryukov.org
	http://www.codeproject.com/Members/SAKryukov	

	Original publication:
	https://www.codeproject.com/Articles/1176230/WPF-Never-Add-Strings
*/
namespace NeverEverAddStringsToWPFLists.Ui {
    using System.Windows.Controls;

    class IntControlHandler : MainWindow.ItemsControlHandlerBase {
        internal override void Populate(ListBox listBox) {
            base.Populate(listBox);
            listBox.Items.Add(1);
            listBox.Items.Add(2);
            listBox.Items.Add(1);
            listBox.Items.Add(2);
		} //Populate
        internal override string GetSelectedItem(ListBox listBox) {
            var item = listBox.SelectedItem;
            if (item == null) return "<none>"; else return item.ToString();
        } //GetSelectedItem
        internal override void AddNewItem(ListBox listBox, string value) {
            listBox.Items.Add(int.Parse(value));
        } //AddNewItem
        internal override bool FilterTextBoxInput(string badText) {
            return !char.IsDigit(badText, badText.Length - 1);
        } //FilterTextBoxInput
        internal override string Help {
            get {
                return "Same thing with integers,\n"
                    + "but actually with all primitive and enumeration types...";
            }
        } //Help
    } //IntControlHandler

    class StringControlHandler : MainWindow.ItemsControlHandlerBase {
        internal override void Populate(ListBox listBox) {
            base.Populate(listBox);
            listBox.Items.Add("one");
            listBox.Items.Add("two");
            listBox.Items.Add("one");
            listBox.Items.Add("two");
        } //Populate
        internal override string GetSelectedItem(ListBox listBox) {
            var item = listBox.SelectedItem;
            if (item == null) return "<none>"; else return item.ToString();
        } //GetSelectedItem
        internal override void AddNewItem(ListBox listBox, string value) {
            listBox.Items.Add(value);
        } //AddNewItem
        internal override string Help {
            get {
                return "Try to click in second item, and then on first one... Can you explain it?\n\n"
                    + "Now, add many identical new items and see how scrolling down works.\n"
                    + "If the last item has unique value, contol scrolls to it. Why not to any item?\n"
                    + "Read the article...";
            }
        } //Help
    } //StringControlHandler

} //namespace NeverEverAddStringsToWPFLists.Ui
