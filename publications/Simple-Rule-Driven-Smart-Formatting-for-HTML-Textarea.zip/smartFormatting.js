/*

Smart Formatting

Simple Rule-Driven Smart Formatting for HTML Textarea

Copyright (c) 2015, 2021 by Sergey A Kryukov
http://www.SAKryukov.org
http://SAKryukov.org/freeware/calculator
http://www.codeproject.com/Members/SAKryukov

Original publication:
https://www.codeproject.com/Articles/1058628/Simple-Rule-Driven-Smart-Formatting-for-HTML-Texta

*/

"use strict";

function setSmartFormatting(editor, autoCompleteMatchNotification, options) {
	const defaultOptions = {
		features: { useSmartIndent: true, useTabs: true, tabSize: 4, useAutoBracket: true, useTidy: true, useCodeCompletion: true },
		formattingRules: {
			indent: [
				{ bra: "[", ket: "]", endOfLineKet: true, matchLeftWord: false, matchRightWord: false },
				{ bra: "{", ket: "}", endOfLineKet: true, matchLeftWord: false, matchRightWord: false }
			],
			autoBracket: [
				{ bra: "[", ket: "]", endOfLineOnly: true },
				{ bra: "{", ket: "}", endOfLineOnly: true },
				{ bra: "(", ket: ")", endOfLineOnly: true },
				{ bra: "'", ket: "'", endOfLineOnly: true },
				{ bra: "\"", ket: "\"", endOfLineOnly: true }
			],
			tidy: [
				{ before: ["===", "!==", "==", "++", "--", "&&", "||", "+=", "-=", "*=", "/=", "|=", "//", "&=", "^=", "!=", "=", "+", "-", "*", "/", "|", "&", "^", "{"], after: " $1 " },
				{ before: [",", ";", ":"], after: "$1 " },
				{ before: ["}"], after: " $1" }
			],
			tidyVerbatim: [ // inside these brackets, tidy is not applied, the content is used verbatim
                                { bra: "/*", ket: "*/" },
                                { bra: "//", ket: null },
                                { bra: "'", ket: "'" },
                                { bra: "`", ket: "`" },
                                { bra: "\"", ket: "\"" }
			],
			autoComplete: [
                                { pattern: "wri*teLine (|);", breakPoint: "*", insertPoint: "|" }, //JavaScript.Playground/Calculator-specific
                                { pattern: "do* {|} while ()", breakPoint: "*", insertPoint: "|" },
                                { pattern: "whi*le (|)", breakPoint: "*", insertPoint: "|" },
                                { pattern: "swi*tch (|) {}", breakPoint: "*", insertPoint: "|" },
                                { pattern: "cas*e |: break;", breakPoint: "*", insertPoint: "|" },
                                { pattern: "try* {|} catch(exception) {}", breakPoint: "*", insertPoint: "|" },
                                { pattern: "thr*ow new |;", breakPoint: "*", insertPoint: "|" },
                                { pattern: "if* (|)", breakPoint: "*", insertPoint: "|" },
                                { pattern: "els*e |", breakPoint: "*", insertPoint: "|" },
                                { pattern: "le*t |", breakPoint: "*", insertPoint: "|" },
                                { pattern: "con*st |", breakPoint: "*", insertPoint: "|" },
                                { pattern: "conso*le.|", breakPoint: "*", insertPoint: "|" },
                                { pattern: "console.l*og(|);", breakPoint: "*", insertPoint: "|" },
                                { pattern: "console.e*rror(|);", breakPoint: "*", insertPoint: "|" },
                                { pattern: "console.w*arn(|);", breakPoint: "*", insertPoint: "|" },
                                { pattern: "console.i*nfo(|);", breakPoint: "*", insertPoint: "|" },
                                { pattern: "console.d*ebug(|);", breakPoint: "*", insertPoint: "|" },
                                { pattern: "ret*urn |;", breakPoint: "*", insertPoint: "|" },
                                { pattern: "fun*ction () {|}", breakPoint: "*", insertPoint: "|" },
                                { pattern: "for* (let index |", breakPoint: "*", insertPoint: "|" },
                                { pattern: "for (let index =* 0; index < |; ++index) { console.log(index); }", breakPoint: "*", insertPoint: "|" },
                                { pattern: "for (let index i*n |) { console.log(index); }", breakPoint: "*", insertPoint: "|" },
                                { pattern: "for (let index o*f |) { console.log(index); }", breakPoint: "*", insertPoint: "|" }
			]
		}
	}; //defaultOptions

	const constants = { objectType: typeof {}, stringType: typeof "", keyEnter: 13, keyEscape: 27, tab: "\t", blankSpace: " ", empty: "" };
	populateWithDefaultObject(options, defaultOptions);

    const indentPad = (options.features.useTabs) ? constants.tab : new String(new Array(options.features.tabSize + 1).join(constants.blankSpace));
	let newLine = "\n";

	(function autoDetectNewLineAndSetupTabs() {
		const saveValue = editor.value;
		editor.value = newLine;
		newLine = editor.value; //auto-detected
		editor.value = saveValue;
		if (editor.style.OTabSize !== undefined) editor.style.OTabSize = options.features.tabSize;
		if (editor.style.MozTabSize !== undefined) editor.style.MozTabSize = options.features.tabSize;
		if (editor.style.tabSize !== undefined) editor.style.tabSize = options.features.tabSize;
	})() //autoDetectNewLineAndSetupTabs

	const tidyRegex = (function createRegexTidyRules(rules) {
		const regex = [];
		for (let rule in rules) {
			const newRule = { before: constants.empty, after: rules[rule].after };
			for (let wordIndex = 0; wordIndex < rules[rule].before.length; ++wordIndex) {
				let word = constants.empty;
				for (let charIndex in rules[rule].before[wordIndex])
					word += "\\" + rules[rule].before[wordIndex][charIndex];
				if (newRule.before != constants.empty)
					newRule.before += "|";
				newRule.before += word;
			} //loop word
			newRule.before = "(" + newRule.before + ")";
			newRule.before = new RegExp(newRule.before, "g");
			regex.push(newRule);
		} //loop rule
		return regex;
	})(options.formattingRules.tidy);

	const tidyVerbatimRegex = (function createTidyVerbatimRegex(rules) {
		const escape = value => {
			let word = constants.empty;
			for (let charIndex in value)
				word += "\\" + value[charIndex];
			return word;
		} //escape
		let regex = constants.empty;
		for (let rule in rules) {
			if (regex)
				regex += "|";
			const bra = rules[rule].bra == null ? "^" : escape(rules[rule].bra);
			const ket = rules[rule].ket == null ? "$" : escape(rules[rule].ket);
			regex += `${bra}.*?${ket}`;
		} //loop
		return new RegExp(regex, "g");
	})(options.formattingRules.tidyVerbatim);

	const getCursor = editor => {
		return editor.selectionStart;
	}; //getCursor

	const setCursor = (editor, pos) => {
		editor.selectionStart = pos;
		editor.selectionEnd = pos;
	}; //setCursor

	const endsWith = (src, key) => {
		if (typeof src != constants.stringType) return false;
		if (typeof key != constants.stringType) return false;
		const index = src.lastIndexOf(key)
		return index >= 0 && index == src.length - key.length;
	}; //endsWith

	const startsWith = (src, key) => {
		if (typeof src != constants.stringType) return false;
		if (typeof key != constants.stringType) return false;
		return src.lastIndexOf(key) == 0;
	}; //startsWith

	const findWords = (value, right) => {
		const words = value.split(/[\s\n\r]/);
		const clearWords = [];
		for (let index = 0; index < words.length; ++index)
			if (words[index] != constants.empty)
				clearWords.push(words[index]);
		return (right) ? clearWords[0] : clearWords[clearWords.length - 1];
	}; //findWords

	const parseCursorContext = editor => {
		const pos = getCursor(editor);
		const allText = editor.value;
		let leftChar = allText[pos - 1];
		let rightChar = allText[pos];
		leftChar = allText[pos - 1];
		rightChar = allText[pos];
		if (!leftChar) return;
		let left = allText.substring(0, pos);
		let right = allText.substring(pos);
		const rightmost = right.indexOf(newLine);
		if (rightmost >= 0)
			right = right.substr(0, rightmost);
		const leftmost = left.lastIndexOf(newLine);
		if (leftmost >= 0)
			left = left.substr(leftmost + newLine.length, pos);
		const leftWord = findWords(left, false);
		const rightWord = findWords(right, true);
		return { cursor: pos, left: { char: leftChar, word: leftWord, line: left }, right: { char: rightChar, word: rightWord, line: right } };
	}; //parseCursorContext

	const insert = aValue => {
		if (!aValue) return;
		const startPos = editor.selectionStart;
		const endPos = editor.selectionEnd;
		editor.value = editor.value.substring(0, startPos)
			+ aValue
			+ editor.value.substring(endPos, editor.value.length);
	}; //insert
	const removeBack = (cursorContext, count) => {
		if (!count) return;
		let left = editor.value.substring(0, cursorContext.cursor);
		const right = editor.value.substring(cursorContext.cursor);
		left = left.slice(0, -count);
		editor.value = left + right;
	}; //removeBack

	const countTabs = source => {
		const match = (options.features.useTabs) ? constants.tab : constants.blankSpace;
		let result = 0;
		for (let index = 0; index < source.length; ++index)
			if (source[index] == match)
				++result;
			else
				break;
		return source.substr(0, result);
	}; //countTabs

	const tidy = value => {
		const toTidy = value.split(tidyVerbatimRegex);
		if (toTidy.length > 1) {
			const formatted = [];
			for (let term of toTidy) {
				for (let index in tidyRegex)
					term = term.replace(tidyRegex[index].before, tidyRegex[index].after);
				term = term.replace(/\s+/g, constants.blankSpace);
				formatted.push(term);
			} //loop
			let match;
			const matches = [];
			while ((match = tidyVerbatimRegex.exec(value)) !== null)
				matches.push(match);
			const result = [];
			for (let current = 0; current < formatted.length; ++current) {
				result.push(formatted[current]);
				if (matches[current])
					result.push(matches[current]);
			} //loop
			value = result.join("");
		} else {
			for (let index in tidyRegex)
				value = value.replace(tidyRegex[index].before, tidyRegex[index].after);
			value = value.replace(/\s+/g, constants.blankSpace);
		} //if
		return value.trim();
	}; //tidy

	const handleCharacter = (character, context) => {
		const trimmedRightLine = context.right.line.trim();
		for (let index = 0; index < options.formattingRules.autoBracket.length; ++index) {
			const rule = options.formattingRules.autoBracket[index];
			if (!(rule.bra && rule.ket)) continue;
			if (character != rule.bra) continue;
			if (rule.endOfLineOnly && trimmedRightLine != constants.empty) continue;
			insert(character + rule.ket);
			setCursor(this, context.cursor + 1);
			return true;
		} //loop
	}; //handleCharacter

	const recognizeAutocomplete = context => {
		if (context.right.line) return;
		for (let index = 0; index < options.formattingRules.autoComplete.length; ++index) {
			const rule = options.formattingRules.autoComplete[index];
			if (!rule.breakPoint) continue;
			if (!rule.insertPoint) continue;
			if (rule.breakPoint.length != 1) continue;
			if (rule.insertPoint.length != 1) continue;
			const reg = new RegExp("[" + rule.breakPoint + rule.insertPoint + "]", "g");
			const parts = rule.pattern.split(reg);
			if (parts.length != 3) continue;
			const all = parts.join(constants.empty);
			const min = parts[0].length;
			let match;
			for (length = all.length - 1; length >= min; --length)
				if (endsWith(context.left.line, all.slice(0, length))) {
					match = length; break;
				} //if
			if (!match) continue;
			return { all: all, toInsert: all.slice(length), cursorPosition: context.cursor + all.length - match - parts[2].length }
		} //loop
	}; //recognizeAutocomplete

	const keyPressHandler = function (ev) {
		ev = ev || window.event;
		const character = String.fromCharCode(ev.charCode);
		const context = parseCursorContext(this);
		if (handleCharacter.call(this, character, context)) {
			ev.preventDefault();
			return false;
		} //if
	}; //keyPressHandler

	const keyUpClickHandler = function (ev) {
		ev = ev || window.event;
		if (ev.keyCode && ev.keyCode == constants.keyEscape)
			return;
			const context = parseCursorContext(this);
		this.match = recognizeAutocomplete.call(this, context);
		if (!autoCompleteMatchNotification) return;
		const autoCompleteMatchNotificationArgument = (this.match) ? this.match.all : constants.empty;
		autoCompleteMatchNotification(autoCompleteMatchNotificationArgument);
	}; //keyUpClickHandler

	const keyDownHandler = function (ev) {
		ev = ev || window.event;
		if (ev.shiftKey || ev.ctrlKey || ev.altKey || ev.metaKey) return;
		if (ev.keyCode == constants.keyEscape) {
			this.match = null;
			if (autoCompleteMatchNotification)
				autoCompleteMatchNotification(null);
			return;
		} //if keyEscape
		if (ev.keyCode != constants.keyEnter) return;
		let context = parseCursorContext(this);
		if (this.match && options.features.useCodeCompletion) {
			insert(this.match.toInsert);
			setCursor(this, this.match.cursorPosition);
			ev.preventDefault();
			return false;			
		} // if 			
		const pad = countTabs(context.left.line);
		let indent = false;
		if (options.features.useTidy) {
			const tidyLine = pad + tidy(context.left.line);
			let cursorShift = tidyLine.length - context.left.line.length;
			removeBack(context, context.left.line.length);
			setCursor(this, context.cursor - context.left.line.length)
			cursorShift = tidyLine.length - context.left.line.length;
			insert(tidyLine); setCursor(this, context.cursor + cursorShift);
			context = parseCursorContext(this);
                if (context.cursor + cursorShift >= editor.value.length)
                    setTimeout( () => editor.scrollTop = editor.scrollHeight );
		} //if useTidy
		if (options.features.useSmartIndent) {
			for (let index = 0; index < options.formattingRules.indent.length; ++index) {
				const rule = options.formattingRules.indent[index];
				const ket = rule.ket || constants.empty;
				const leftMatches = (rule.matchLeftWord) ? context.left.word == rule.bra : endsWith(context.left.line, rule.bra);
				if (leftMatches) {
					const rightMatches = (rule.matchRightWord) ? context.right.word && context.right.word == ket : context.right.word && startsWith(context.right.line, ket);
					const lineEndMatches = rule.endOfLineKet && !context.right.word;
					if (rightMatches)
						insert(newLine + pad + indentPad + newLine + pad);
					else if (lineEndMatches)
						insert(newLine + pad + indentPad);
					if (rightMatches || lineEndMatches) {
						setCursor(this, context.cursor + pad.length + indentPad.length + 1);
						indent = true;
						break;
					} //if right/end-of-line matches
				} //if left matches		
			} //loop
			if (!indent) {
				insert(newLine + pad);
				setCursor(this, context.cursor + pad.length + 1);
			} //if
		} else
			return; //if useSmartIndent
		ev.preventDefault();
		return false;			
	}; //keyDownHandler

	const pasteHandler = function (ev) {
		if (!ev.clipboardData) return;
		const data = ev.clipboardData.getData('text/plain');
		if (!data) return;
		this.match = undefined;
		if (!autoCompleteMatchNotification) return;
		autoCompleteMatchNotification(constants.empty);
	}; //pasteHandler	

	editor.removeEventListener("keydown", keyDownHandler);
	editor.removeEventListener("keypress", keyPressHandler);
	editor.removeEventListener("keyup", keyUpClickHandler);
	editor.removeEventListener("click", keyUpClickHandler);
	editor.removeEventListener("paste", pasteHandler);
	if (options.features.useSmartIndent || options.features.useTidy || options.features.useCodeCompletion)
		editor.addEventListener("keydown", keyDownHandler);
	if (options.features.useAutoBracket)
		editor.addEventListener("keypress", keyPressHandler);
	if (options.features.useCodeCompletion) {
		editor.addEventListener("keyup", keyUpClickHandler);
		editor.addEventListener("click", keyUpClickHandler);
		editor.addEventListener("paste", pasteHandler);
	} //if

	function populateWithDefaultObject(value, defaultValue) {
		if (!defaultValue) return;
		if (!value) return;
		if (typeof defaultValue == constants.objectType && typeof value == constants.objectType) {
			for (let index in defaultValue)
				if (!(index in value))
					value[index] = defaultValue[index];
				else
					populateWithDefaultObject(value[index], defaultValue[index]);
		} else
			value = defaultValue;
	} //populateWithDefaultObject

}; //setSmartFormatting