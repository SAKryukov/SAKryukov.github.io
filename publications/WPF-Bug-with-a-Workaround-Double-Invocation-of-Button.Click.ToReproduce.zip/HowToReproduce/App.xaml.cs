﻿namespace HowToReproduce {
    using System.Windows;

    public partial class App : Application {

        static class DefinitionSet {
            internal const string FormatException = "{0}:\n\n{1}";
            internal const string FormatTitle = "{0} Exception";
        } //class DefinitionSet

        internal App() {
            DispatcherUnhandledException += (sender, eventArgs) => {
                eventArgs.Handled = true;
                MessageBox.Show(
                    string.Format(
                        DefinitionSet.FormatException,
                        eventArgs.Exception.GetType().FullName,
                        eventArgs.Exception.Message),
                    string.Format(
                        DefinitionSet.FormatTitle,
                        App.Current.MainWindow.Title),
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }; //DispatcherUnhandledException
        } //App

    } //class App
}
