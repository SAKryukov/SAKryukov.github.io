﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("How To Reproduce Double Invocation of Button.Click problem")]

[assembly: AssemblyDescription(
@"Description for the problem and the demonstration of the steps to reproduce:

A button click event is invoked twice through an access character if an exception is thrown, caught and handled.

CodeProject article ""WPF Bug with a Workaround: Double Invocation of Button.Click""")]

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("How To Reproduce")]
[assembly: AssemblyCopyright("Copyright © 2014 by Sergey A Kryukov, http://www.SAKryukov.org, http://www.codeproject.com/Members/SAKryukov")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
