﻿// Anamorphic Drawing
//
// Copyright (c) Sergey A Kryukov, 2017, 2019
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
//
// Original publication:
// https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

namespace AnamorphicDrawing.Ui {
    using System.Windows;

    partial class LocationGrip {

        static FrameworkPropertyMetadata SelectedPropertyMetadata = new FrameworkPropertyMetadata(false);

        static DependencyProperty SelectedProperty =
            DependencyProperty.Register("IsSelected", typeof(bool), typeof(LocationGrip), SelectedPropertyMetadata);
        
        public bool IsSelected {
            get { return (bool)GetValue(SelectedProperty); }
            set { SetValue(SelectedProperty, value); }
        } //IsSelected

    } //class LocationGrip

} //namespace AnamorphicDrawing.Ui
