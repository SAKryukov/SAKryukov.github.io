﻿// Anamorphic Drawing
//
// Copyright (c) Sergey A Kryukov, 2017, 2019
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
//
// Original publication:
// https://www.codeproject.com/Articles/1278552/Anamorphic-Drawing-for-the-Cheaters

namespace AnamorphicDrawing.Ui {
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;

    internal partial class CropGrip : BaseGrip {

        protected override void OnMouseDown(System.Windows.Input.MouseButtonEventArgs e) {
            Focus();
        } //OnMouseDown

        protected override bool IsGoodMotionKey(KeyEventArgs e) {
            if (this.Direction == GripDirection.Horizontal) {
                if (e.Key == Key.System) {
                    return e.SystemKey == Key.Left || e.SystemKey == Key.Right;
                } else {
                    return e.Key == Key.Down || e.Key == Key.Left || e.Key == Key.Right;
                } // if System
            } else {
                if (e.Key == Key.System) {
                    return e.SystemKey == Key.Up || e.SystemKey == Key.Down;
                } else {
                    return e.Key == Key.Up || e.Key == Key.Down;
                } // if System
            } //if Direction
        } //IsGoodMotionKey

    } //CropGrip

} //namespace AnamorphicDrawing.Ui
