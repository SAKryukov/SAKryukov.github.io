﻿/*
Illusionary XAML: Reinventing Benham's Top

Original publication:
https://www.codeproject.com/Articles/1237396/Illusionary-XAML-Reinventing-Benhams-Top

    Copyright © 2018 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

April 1st, 2018
*/

using System.Windows;

namespace XAML.Ui {
	using System;
	using System.Xml;
	using System.Windows.Markup;
	using System.Windows.Media;
	using System.Windows.Media.Animation;
	using Canvas = System.Windows.Controls.Canvas;
	using Viewbox = System.Windows.Controls.Viewbox;
	using LogicalTreeHelper = System.Windows.LogicalTreeHelper;
	using Path = System.Windows.Shapes.Path;
	// 
	using RenderTargetBitmap = System.Windows.Media.Imaging.RenderTargetBitmap;
	using TiffBitmapEncoder = System.Windows.Media.Imaging.TiffBitmapDecoder;
	using BmpBitmapEncoder = System.Windows.Media.Imaging.BmpBitmapEncoder;
	using BitmapFrame = System.Windows.Media.Imaging.BitmapFrame;

	public partial class MainWindow : Window {

		public MainWindow() {
			InitializeComponent();
		} //MainWindow

		void Animate(Canvas svg, Path star) {
			DoubleAnimation da = new DoubleAnimation();
			da.From = 0;
			da.To = 360;
			da.Duration = new Duration(TimeSpan.FromSeconds(5));
			da.RepeatBehavior = RepeatBehavior.Forever;
			RotateTransform rt = new RotateTransform();
			rt.CenterX = svg.Width / 2;
			rt.CenterY = svg.Height / 2;
			star.RenderTransform = rt;
			rt.BeginAnimation(RotateTransform.AngleProperty, da);
		} //Animate

		protected override void OnContentRendered(System.EventArgs e) {
			base.OnContentRendered(e);
			svg.Background = Brushes.Transparent;
			Animate(this.svg, this.star);
		} //OnContentRendered

	} //class MainWindow

} //namespace XAML.Ui
