﻿/*
Illusionary XAML: Reinventing Benham's Top

Original publication:
https://www.codeproject.com/Articles/1237396/Illusionary-XAML-Reinventing-Benhams-Top

    Copyright © 2018 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

April 1st, 2018
*/

using System.Windows;
namespace ColorTop.Ui {
    using System;
    using System.Xml;
    using XamlReader = System.Windows.Markup.XamlReader;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Input;
    using Canvas = System.Windows.Controls.Canvas;
    using Viewbox = System.Windows.Controls.Viewbox;
    using LogicalTreeHelper = System.Windows.LogicalTreeHelper;
    using OpenFileDialog = Microsoft.Win32.OpenFileDialog;

    public partial class MainWindow : Window {

        class AnimationState {
            const double maxAngle = 360;
            internal AnimationState() { speed = 1; direction = true; }
            internal bool direction { get; set; } // true means right
            internal double angle {
                get { return angleValue % maxAngle; }
                set { angleValue = value % maxAngle; }
            } // angle
            internal double endAngle {
                get {
                    if (direction) return angle + maxAngle;
                    else return angle - maxAngle;
                }
            } // angle
            internal double speed {
                get { return speedValue; }
                set {
                    speedValue = value;
                    durationValue = TimeSpan.FromMinutes(1f / speedValue);
                }
            } //speed
            internal TimeSpan duration {
                get { return durationValue; }
            } //duration
            internal void setTitle(Window window, string name) {
                this.name = name;
                setTitle(window);
            } //setTitle
            internal void setTitle(Window window) {
                window.Title = string.Format((string)window.Tag, ((Main.TheApplication)Main.TheApplication.Current).ProductName, name, speed);
            } //setTitle
            internal void Animate(RotateTransform animatedElement, DoubleAnimation animation, FrameworkElement element) {
                if (animation != null) {
                    animation.From = angle;
                    animation.To = endAngle;
                    animation.Duration = duration;
                    animation.RepeatBehavior = RepeatBehavior.Forever;
                } //if
                if (element != null) {
                    element.RenderTransform = animatedElement;
                    animatedElement.CenterX = element.Width / 2;
                    animatedElement.CenterY = element.Height / 2;
                } //if
                animatedElement.BeginAnimation(RotateTransform.AngleProperty, animation);
            } //Animate
            internal string name;
            double speedValue;
            double angleValue;
            TimeSpan durationValue;
        } //class AnimationState

        static string getTitle(FrameworkElement element) {
            string result = (string)element.DataContext;
            if (result == null)
                result = (string)element.Tag;
            return result;
        } //getTitle

        public MainWindow() {
            InitializeComponent();
            Generator.Client = this;
            setupDialogs();
            PreviewKeyDown += (sender, eventArgs) => {
                if (eventArgs.Key == Key.Up || eventArgs.Key == Key.Down ||
                    eventArgs.SystemKey == Key.Up || eventArgs.SystemKey == Key.Down)
                    sliderSpeed.Focus();
            }; //PreviewKeyDown
            animationState.speed = sliderSpeed.Minimum;
            sliderSpeed.ValueChanged += (sender, eventArgs) => {
                animationState.angle = animatedElement.Angle;
                animation.From = animationState.angle;
                animation.To = animationState.endAngle;
                animationState.speed = sliderSpeed.Value;
                animation.Duration = animationState.duration;
                if (checkBoxAnimation.IsChecked == true)
                    animatedElement.BeginAnimation(RotateTransform.AngleProperty, animation);
                else
                    checkBoxAnimation.IsChecked = true;
                animationState.setTitle(this);
            }; //sliderSpeed.ValueChanged
            checkBoxAnimation.Checked += (sender, eventArgs) => {
                animationState.Animate(animatedElement, animation, null);
            }; //checkBoxAnimation.Checked
            checkBoxAnimation.Unchecked += (sender, eventArgs) => {
                animationState.angle = animatedElement.Angle;
                animatedElement.Angle = animationState.angle;
                animationState.Animate(animatedElement, null, null);
            }; //checkBoxAnimation.Unchecked
            System.Action<bool> changeDirection = (dr) => {
                animationState.direction = dr;
                animationState.angle = animatedElement.Angle;
                animatedElement.Angle = animationState.angle;
                animationState.Animate(animatedElement, animation, null);
                checkBoxAnimation.IsChecked = true;
            }; //changeDirection	
            raduoLeft.Checked += (sender, eventArgs) => { changeDirection(false); };
            raduoRight.Checked += (sender, eventArgs) => { changeDirection(true); };
            Action reload = () => {
                if (openDialog.ShowDialog() != true) return;
                using (XmlReader reader = XmlReader.Create(openDialog.FileName)) {
                    DependencyObject top = XamlReader.Load(reader) as DependencyObject;
                    Canvas canvas = findCanvas(top);
                    if (canvas == null) throw new Main.NoCanvasException();
                    Viewbox vb = top as Viewbox;
                    if (vb == null) {
                        vb = new Viewbox();
                        vb.Child = canvas;
                    } //if
                    this.borderAnimationBackground.Child = vb;
                    animationState.Animate(animatedElement, animation, canvas);
                    string title = getTitle(vb);
                    if (title == null)
                        title = getTitle(canvas);
                    if (title == null)
                        title = System.IO.Path.GetFileName(openDialog.FileName);
                    animationState.setTitle(this, title);
                } //using
            }; //reload
            CommandBindings.Add(new System.Windows.Input.CommandBinding(ApplicationCommands.Open,
                (sender, eventArgs) => { reload(); }));
            CommandBindings.Add(new System.Windows.Input.CommandBinding(ApplicationCommands.Properties,
                (sender, eventArgs) => {
                    Generator.Loaded += (g, ea) => {
                        placeGenerator();
                    }; //Generator.Loaded 
                    Generator.Show();
                }));
            borderAnimationBackground.PreviewMouseDown += (sender, eventArgs) => { reload(); };
            sliderSpeed.IsMoveToPointEnabled = true;
            sliderSpeed.PreviewKeyDown += (sender, eventArgs) => {
                double value = sliderSpeed.Value;
                if (eventArgs.SystemKey == Key.Up)
                    value += sliderSpeed.LargeChange;
                else if (eventArgs.SystemKey == Key.Down)
                    value -= sliderSpeed.LargeChange;
                else
                    return;
                if (value > sliderSpeed.Maximum)
                    value = sliderSpeed.Maximum;
                if (value < sliderSpeed.Minimum)
                    value = sliderSpeed.Minimum;
                sliderSpeed.Value = value;
            }; //sliderSpeed.PreviewKeyDown
        } //MainWindow

        static Canvas findCanvas(System.Windows.DependencyObject parent) {
            if (parent == null) return null;
            Canvas result = parent as Canvas;
            if (result != null) return result;
            DependencyObject current = parent;
            var children = LogicalTreeHelper.GetChildren(parent);
            foreach (var child in children) {
                result = child as Canvas;
                if (result != null)
                    return result;
                else
                    return findCanvas(child as System.Windows.DependencyObject);
            } //loop
            return result;
        } //findCanvas

        protected override void OnContentRendered(System.EventArgs e) {
            base.OnContentRendered(e);
            sliderSpeed.Focus();
            Canvas canvas = findCanvas(this.borderAnimationBackground);
            animationState.setTitle(this, getTitle(canvas));
            animationState.Animate(animatedElement, animation, canvas);
        } //OnContentRendered

        void placeGenerator() {
            Visual content = (Visual)this.Content;
            Point origin = content.PointToScreen(new Point());
            if (Generator.ActualWidth <= this.Left) {
                Generator.Left = this.Left - Generator.ActualWidth;
                Generator.Top = this.Top;
            } else {
                Generator.Left = origin.X;
                Generator.Top = origin.Y;
            } //if
        } //PlaceGenerator

        void setupDialogs() {
            openDialog.Title = strOpenDialogTitle;
            string fileNamePatternXaml = strFileNamePatternXaml;
            string fileNameSubdir = strFileNameSubdir;
            openDialog.Filter = strOpenDialogFilter + fileNamePatternXaml;
            openDialog.FileName = System.IO.Path.Combine(
                System.IO.Path.GetDirectoryName(
                    System.Reflection.Assembly.GetEntryAssembly().Location),
                fileNameSubdir);
            openDialog.FileName = System.IO.Path.Combine(openDialog.FileName, fileNamePatternXaml);
        } //setupDialogs

        OpenFileDialog openDialog = new OpenFileDialog();
        RotateTransform animatedElement = new RotateTransform();
        DoubleAnimation animation = new DoubleAnimation();
        AnimationState animationState = new AnimationState();
        WindowGenerator Generator = new WindowGenerator();

    } //class MainWindow

} //namespace ColorTop.Ui
