﻿/*
Illusionary XAML: Reinventing Benham's Top

Original publication:
https://www.codeproject.com/Articles/1237396/Illusionary-XAML-Reinventing-Benhams-Top

    Copyright © 2018 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

April 1st, 2018
*/

namespace ColorTop.Ui {
	using System;
	using System.Windows;
	using System.Windows.Controls;
	using System.Windows.Input;
	using KeySet = System.Collections.Generic.HashSet<System.Windows.Input.Key>;
	using SaveFileDialog = Microsoft.Win32.SaveFileDialog;

	public partial class WindowGenerator : Window {

		public WindowGenerator() {
			InitializeComponent();
			setupDialogs();
			rememberDefaults();
			var redurectUndoRedo = new Action<System.Windows.Controls.Primitives.TextBoxBase>((element) => {
				CommandManager.AddPreviewCanExecuteHandler(element, new CanExecuteRoutedEventHandler((sender, eventArgs) => {
					if (eventArgs.Command == ApplicationCommands.Undo || eventArgs.Command == ApplicationCommands.Redo) {
						eventArgs.CanExecute = true;
						eventArgs.Handled = true;
					} //if
				}));
				CommandManager.AddPreviewExecutedHandler(element, new ExecutedRoutedEventHandler((sender, eventArgs) => {
					if (eventArgs.Command == ApplicationCommands.Undo || eventArgs.Command == ApplicationCommands.Redo)
						eventArgs.Handled = true;
					if (eventArgs.Command == ApplicationCommands.Undo) {
						if (!Client.Undo())
							element.Undo();
					} else if (eventArgs.Command == ApplicationCommands.Redo) {
						if (!Client.Redo())
							element.Redo();
					} //if
				}));
			}); //redurectUndoRedo
			var validKeys = createValidKeys();
			foreach (TextBox item in new TextBox[] { textBoxFrom, textBoxAngularSize, textBoxRadius, textBoxThickness }) {
				item.PreviewTextInput += (sender, eventArgs) => {
					if (eventArgs.Text.Length < 1) return;
					eventArgs.Handled = (!char.IsDigit(eventArgs.Text, eventArgs.Text.Length - 1) &&
						!(System.Globalization.CultureInfo.CurrentUICulture.NumberFormat.NumberDecimalSeparator == eventArgs.Text.Substring(0)));
				}; //item.PreviewTextInput
				redurectUndoRedo(item);
			} //loop
			buttonNew.Click += (sender, eventArgs) => {
				Client.NewPattern(textBoxTitle.Text);
			}; //buttonAdd.Click
			buttonAdd.Click += (sender, eventArgs) => {
				Client.Add(textBoxTitle.Text, createSectorData());
			}; //butto`nAdd.Click
			buttonReset.Click += (sender, eventArgs) => {
				resetDefaults();
			}; //buttonReset.Click
			CommandBindings.Add(new System.Windows.Input.CommandBinding(ApplicationCommands.Save,
				(sender, eventArgs) => {
					if (SaveXamlDialog.ShowDialog() != true) return;
					Client.SavePattern(textBoxTitle.Text, SaveXamlDialog.FileName);
				}));
			CommandBindings.Add(new System.Windows.Input.CommandBinding(ApplicationCommands.Undo,
				(sender, eventArgs) => {
					Client.Undo();
				},
				(sender, eventArgs) => {
					eventArgs.CanExecute = Client.CanUndo();
				}));
			CommandBindings.Add(new System.Windows.Input.CommandBinding(ApplicationCommands.Redo,
				(sender, eventArgs) => {
					Client.Redo();
				},
				(sender, eventArgs) => {
					eventArgs.CanExecute = false;
				}));
		} //WindowGenerator

		protected override void OnContentRendered(EventArgs e) {
			base.OnContentRendered(e);
			//SA!!! even better way: handling SizeChangeed
			foreach (var textBox in new TextBox[] { textBoxTitle, textBoxFrom, textBoxAngularSize, textBoxRadius, textBoxThickness, })
				textBox.Width = textBox.ActualWidth;
		} //OnContentRendered

		double getNumericValue(TextBox tb) {
			if (random == null)
				random = new Random(DateTime.Now.Millisecond);
			try {
				string[] values = tb.Text.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
				if (values.Length == 1) {
					return double.Parse(values[0]);
				} else if (values.Length == 2) {
					double min = double.Parse(values[0]);
					double max = double.Parse(values[1]);
					return min + (max - min) * random.NextDouble();
				} else
					throw new Main.InputException();
			} catch (Exception) {
				tb.Focus();
				throw;
			} //exception
		} //getNumericValue

		Main.Sector createSectorData() {
			return new Main.Sector(
				getNumericValue(textBoxFrom),
				getNumericValue(textBoxAngularSize),
				getNumericValue(textBoxRadius),
				getNumericValue(textBoxThickness));
		} //createSectorData

		string createValidKeys() {
			return ".";
		} //createValidKeys

		protected override void OnClosing(System.ComponentModel.CancelEventArgs e) {
			Hide();
			e.Cancel = true;
		} //OnClosing

		void rememberDefaults() {
			defaultFrom = textBoxFrom.Text;
			defaultTo = textBoxAngularSize.Text;
			defaultRadius = textBoxRadius.Text;
			defaultThickness = textBoxThickness.Text;
		} //rememberDefaults
		void resetDefaults() {
			textBoxFrom.Text = defaultFrom;
			textBoxAngularSize.Text = defaultTo;
			textBoxRadius.Text = defaultRadius;
			textBoxThickness.Text = defaultThickness;
		} //resetDefaults

		void setupDialogs() {
			SaveXamlDialog.Title = strSaveXamlDialogTitle;
			string fileNamePatternXaml = strFileNamePatternXaml;
			SaveXamlDialog.Filter = strSaveXamlFilter + fileNamePatternXaml;
			SaveXamlDialog.DefaultExt = strFileNamePatternXaml;
			SaveXamlDialog.OverwritePrompt = true; 
			SaveHistoryDialog.Title = strSaveHistoryDialogTitle;
			string fileNamePatternHistory = strFileNamePatternHistory;
			SaveHistoryDialog.Filter = strSaveHistoryFilter + strFileNamePatternHistory;
			SaveHistoryDialog.DefaultExt = strFileNamePatternHistory;
			SaveHistoryDialog.OverwritePrompt = true;
		} //setupDialogs()

		internal IGeneratorClient Client { get; set; }
		Random random;
		SaveFileDialog SaveXamlDialog = new SaveFileDialog();
		SaveFileDialog SaveHistoryDialog = new SaveFileDialog();
		string defaultFrom, defaultTo, defaultRadius, defaultThickness;

	} //class WindowGenerator

} //namespace
