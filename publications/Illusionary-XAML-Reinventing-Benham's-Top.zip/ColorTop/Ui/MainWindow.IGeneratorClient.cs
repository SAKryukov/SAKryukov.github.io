﻿/*
Illusionary XAML: Reinventing Benham's Top

Original publication:
https://www.codeproject.com/Articles/1237396/Illusionary-XAML-Reinventing-Benhams-Top

    Copyright © 2018 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

April 1st, 2018
*/

namespace ColorTop.Ui {
    using System.Windows;
    using System.Windows.Media;
    using System.Windows.Shapes;
    using XamlWriter = System.Windows.Markup.XamlWriter;
    using StreamWriter = System.IO.StreamWriter;
    using Canvas = System.Windows.Controls.Canvas;
    using Viewbox = System.Windows.Controls.Viewbox;
    using Math = System.Math;

    interface IGeneratorClient {
        void NewPattern(string title);
        void SavePattern(string title, string fileName);
        void Add(string title, Main.Sector sector);
        bool CanUndo();
        bool CanRedo();
        bool Undo();
        bool Redo();
    } //interface IGeneratorClient

    public partial class MainWindow : IGeneratorClient {

        void IGeneratorClient.NewPattern(string title) {
            createNewCanvas(title);
        } //IGeneratorClient.NewPattern

        void IGeneratorClient.SavePattern(string title, string fileName) {
            Viewbox viewBox = (Viewbox)borderAnimationBackground.Child;
            viewBox.Tag = title;
            using (StreamWriter writer = new StreamWriter(fileName, false))
                XamlWriter.Save(viewBox, writer);
        } //IGeneratorClient.SavePattern

        bool IGeneratorClient.Undo() {
            if (ClientCanvas == null) return false;
            int count = ClientCanvas.Children.Count;
            if (count <= 1) return false;
            ClientCanvas.Children.RemoveAt(count - 1);
            return true;
        } //IGeneratorClient.Undo
        bool IGeneratorClient.CanUndo() {
            return (ClientCanvas != null && ClientCanvas.Children.Count > 1);
        } //IGeneratorClient.CanUndo

        bool IGeneratorClient.Redo() {
            return false; //SA???
        } //IGeneratorClient.Redo
        bool IGeneratorClient.CanRedo() {
            return false; //SA???
        } //IGeneratorClient.CanRedo

        void IGeneratorClient.Add(string title, Main.Sector sector) {
            if (ClientCanvas == null) createNewCanvas(title);
            Point center = new Point(Main.DefinitionSet.Scale / 2, Main.DefinitionSet.Scale / 2);
            ClientCanvas.Clip = new EllipseGeometry(center, Main.DefinitionSet.Scale / 2, Main.DefinitionSet.Scale / 2);
            if (sector.FullCircle) {
                Ellipse ellipse = new Ellipse();
                ellipse.RenderTransform = new TranslateTransform(Main.DefinitionSet.Scale / 2, Main.DefinitionSet.Scale / 2);
                Canvas.SetLeft(ellipse, -sector.Radius);
                Canvas.SetTop(ellipse, -sector.Radius);
                ellipse.Width = 2 * sector.Radius;
                ellipse.Height = 2 * sector.Radius;
                ellipse.Stroke = Brushes.Black;
                ellipse.StrokeThickness = mod(sector.Thickness, Main.DefinitionSet.Scale / 2);
                ellipse.Fill = Brushes.Transparent;
                ClientCanvas.Children.Add(ellipse);
            } else {
                ArcSegment segment = new ArcSegment();
                Point start = setupArcSegment(center, sector, segment);
                Path path = new Path();
                path.Fill = Brushes.Transparent;
                path.Stroke = Brushes.Black;
                path.StrokeThickness = Math.Min(sector.Thickness, Main.DefinitionSet.Scale / 2);
                PathFigure figure = new PathFigure();
                figure.Segments.Add(new LineSegment(start, false));
                figure.Segments.Add(segment);
                PathGeometry pathGeometry = new PathGeometry();
                pathGeometry.Figures.Add(figure);
                path.Data = pathGeometry;
                path.RenderTransform = new RotateTransform(-mod(sector.AngleFrom, Main.DefinitionSet.MaxDegrees), center.X, center.Y);
                ClientCanvas.Children.Add(path);
            } //if
        } //IGeneratorClient.Add

        static Point setupArcSegment(Point center, Main.Sector sector, ArcSegment arcSegment) {
            double angleTo = (mod(sector.AngularSize, Main.DefinitionSet.MaxDegrees));
            double thickness = Math.Min(sector.Thickness, Main.DefinitionSet.Scale / 2);
            double radius = Math.Min(sector.Radius, Main.DefinitionSet.Scale / 2) + thickness / 2;
            if (radius < 0) radius = 0;
            Point first = new Point(center.X + radius, center.Y);
            Point second = new Point(center.X + radius * cos(angleTo), center.Y - radius * sin(angleTo));
            arcSegment.Size = new Size(radius, radius);
            arcSegment.Point = second;
            arcSegment.SweepDirection = SweepDirection.Counterclockwise;
            arcSegment.IsLargeArc = sector.AngularSize > Main.DefinitionSet.MaxDegrees / 2;
            return first;
        } //setupArcSegment
        static double mod(double input, double modulus) {
            if (input == modulus) return input;
            else return input % modulus;
        } //mod
        static double sin(double degrees) {
            return Math.Sin(degrees * 2d * Math.PI / Main.DefinitionSet.MaxDegrees);
        } //sin
        static double cos(double degrees) {
            return Math.Cos(degrees * 2d * Math.PI / Main.DefinitionSet.MaxDegrees);
        } //cos

        void createNewCanvas(string title) {
            if (title != null)
                animationState.name = title;
            Viewbox viewBox = new Viewbox();
            viewBox.Stretch = Stretch.Uniform;
            ClientCanvas = new Canvas();
            Ellipse outer = new Ellipse();
            outer.Width = Main.DefinitionSet.Scale;
            outer.Height = Main.DefinitionSet.Scale;
            outer.Stroke = Brushes.Black;
            outer.Fill = Brushes.Transparent;
            outer.StrokeThickness = Main.DefinitionSet.OuterCircleThickness;
            ClientCanvas.Children.Add(outer);
            ClientCanvas.Width = Main.DefinitionSet.Scale;
            ClientCanvas.Height = Main.DefinitionSet.Scale;
            viewBox.Child = ClientCanvas;
            this.borderAnimationBackground.Child = viewBox;
            animatedElement.CenterX = ClientCanvas.Width / 2;
            animatedElement.CenterY = ClientCanvas.Height / 2;
            ClientCanvas.RenderTransform = animatedElement;
        } //createNewCanvas

        Canvas ClientCanvas;

    } //class MainWindow

} //namespace ColorTop.Ui
