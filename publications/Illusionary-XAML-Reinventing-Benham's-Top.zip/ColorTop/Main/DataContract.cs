﻿/*
Illusionary XAML: Reinventing Benham's Top

Original publication:
https://www.codeproject.com/Articles/1237396/Illusionary-XAML-Reinventing-Benhams-Top

    Copyright © 2018 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

April 1st, 2018
*/

namespace ColorTop.Main {
	using Math = System.Math;

	class Sector {
		internal Sector(double angleFrom, double angularSize, double radius, double thicknes) {
			this.AngleFrom = Math.Abs(angleFrom);
			this.AngularSize = Math.Abs(angularSize);
			this.Radius = Math.Abs(radius);
			this.Thickness = Math.Abs(thicknes);
		} //Sector
		internal Sector(double angleFrom, double angleTo, double radius) : this(angleFrom, angleTo, radius, 1) { }
		internal double AngleFrom { get; private set; }
		internal double AngularSize { get; private set; }
		internal double Radius { get; private set; }
		internal double Thickness { get; private set; }
		internal bool FullCircle {
			get { return AngularSize >= DefinitionSet.MaxDegrees; }
		} //FullCircle
	} //class Sector

	class DataContract {
	} //class DataContract

} //namespace
