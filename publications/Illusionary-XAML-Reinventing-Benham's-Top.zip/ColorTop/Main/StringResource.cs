﻿/*
Illusionary XAML: Reinventing Benham's Top

Original publication:
https://www.codeproject.com/Articles/1237396/Illusionary-XAML-Reinventing-Benhams-Top

    Copyright © 2018 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

April 1st, 2018
*/

namespace ColorTop.Main {
	using System.Windows;

	class StringResource : FrameworkElement {

		public StringResource() { this.Visibility = Visibility.Collapsed; }

		public string Value {
			get { return (string)GetValue(ValueProperty); }
			set { SetValue(ValueProperty, value); }
		} //Value

		public static implicit operator string(StringResource resource) { return resource.Value; }

		static FrameworkPropertyMetadata ValuePropertyMetadata =
			new FrameworkPropertyMetadata(
				null, //default
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
				}));

		static DependencyProperty ValueProperty =
			DependencyProperty.Register("Value", typeof(string), typeof(StringResource), ValuePropertyMetadata);

	} //class StringResource

} //namespace ColorTop.Main
