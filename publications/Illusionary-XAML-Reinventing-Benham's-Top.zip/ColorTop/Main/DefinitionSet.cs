﻿/*
Illusionary XAML: Reinventing Benham's Top

Original publication:
https://www.codeproject.com/Articles/1237396/Illusionary-XAML-Reinventing-Benhams-Top

    Copyright © 2018 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

April 1st, 2018
*/

namespace ColorTop.Main {

	class DefinitionSet {
		internal const double Scale = 200;
		internal const double OuterCircleThickness = 0.4;
		internal const double MaxDegrees = 360;
	} //class DefinitionSet

} //namespace
