﻿/*
Illusionary XAML: Reinventing Benham's Top

Original publication:
https://www.codeproject.com/Articles/1237396/Illusionary-XAML-Reinventing-Benhams-Top

    Copyright © 2018 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

April 1st, 2018
*/

namespace ColorTop.Main {
using System;

	abstract class XamlException : ApplicationException {
		internal XamlException(string message) : base(message) { }
	} //class XamlException

	class NoCanvasException : XamlException {
		internal NoCanvasException() : base(Resources.Exceptions.NoCanvasException) { }
	} //class NoCanvasException

	class InputException : ApplicationException {
		internal InputException() : base(string.Format(Resources.Exceptions.InputExceptionFormat, Environment.NewLine)) { }
	} //class InputException

} //namespace ColorTop.Main
