﻿/*  
    
	WPF Arc

    Copyright © 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1181872/WPF-Arc

*/

namespace Arc.Ui {
	using System;
	using System.Windows;
	using System.Windows.Media;
	using System.Windows.Media.Animation;
	using System.Windows.Controls;
	using System.Windows.Shapes;
	using EllipseList = System.Collections.Generic.List<System.Windows.Shapes.EllipticalArcShape>;

	public partial class MainWindow : Window {

		const int rows = 9;
		const int columns = 9;
		static readonly Size miniSampleSize = new Size(34, 25);
		const int margin = 4;
		const int minColorComponent = 128;
		static readonly Size nonRectangularWindowSize = new Size(270, 220);
		const int nonRectangularWindowAngularSize = 270 + 40;

		public MainWindow() {
			InitializeComponent();
			PreviewMouseDoubleClick += (sender, eventArgs) => {
				nonRectangularWindowDemo();
			}; //PreviewMouseDoubleClick
			foreach (var el in new FrameworkElement[] { sample, target, radioSector, radioArcSegment, checkBoxCurves, checkBoxStraightLines, })
				el.ToolTip = this.ToolTip; //just advertize Non-Rectangular Window demo
			random = new Random(DateTime.Now.Millisecond);
			list.Add(sample);
			radioSector.Checked += (sender, eventArgs) => {
				foreach(var item in list)
					item.Variant = EllipticalArcGeometryVariant.Sector;
			}; //radioSector.Checked
			radioArcSegment.Checked += (sender, eventArgs) => {
				foreach (var item in list)
					item.Variant = EllipticalArcGeometryVariant.Segment;
			}; //radioArcSegment.Unchecked
			checkBoxCurves.Checked += (sender, eventArgs) => {
				foreach (var item in list)
					item.StrokeOptions |= EllipticalArcGeometryStrokeOptions.Curve;
			}; //checkBoxCurves.Checked
			checkBoxCurves.Unchecked += (sender, eventArgs) => {
				foreach (var item in list)
					item.StrokeOptions &= ~EllipticalArcGeometryStrokeOptions.Curve;
			}; //checkBoxCurves.Unchecked
			checkBoxStraightLines.Checked += (sender, eventArgs) => {
				foreach (var item in list)
					item.StrokeOptions |= EllipticalArcGeometryStrokeOptions.StraightLines;
			}; //checkBoxStraightLines.Checked
			checkBoxStraightLines.Unchecked += (sender, eventArgs) => {
				foreach (var item in list)
					item.StrokeOptions &= ~EllipticalArcGeometryStrokeOptions.StraightLines;
			}; //checkBoxStraightLines.Unchecked
			for (int yIndex = 0; yIndex < rows; ++yIndex) {
				StackPanel panel = new StackPanel();
				panel.Orientation = Orientation.Horizontal;
				target.Children.Add(panel);
				for (int xIndex = 0; xIndex < columns; ++xIndex) {
					EllipticalArcShape shape = new EllipticalArcShape();
					shape.Width = miniSampleSize.Width;
					shape.Height = miniSampleSize.Height;
					shape.Stroke = Brushes.Black;
					shape.Fill = new SolidColorBrush(Color.FromRgb(randomColor(), randomColor(), randomColor()));
					shape.Margin = new Thickness(margin);
					shape.Angle = xIndex * 45;
					shape.AngularSize = 10 + yIndex * 45;
					list.Add(shape);
					panel.Children.Add(shape);
				} //loop x
			} //loop y
		} //MainWindow

		byte randomColor() {
			return (byte)random.Next(minColorComponent, byte.MaxValue);
		} //randomColor

		protected override void OnContentRendered(EventArgs e) {
			base.OnContentRendered(e);
			DoubleAnimation animationAngle = new DoubleAnimation();
			DoubleAnimation animationSize = new DoubleAnimation();
			animationAngle.From = 0;
			animationAngle.To = 360;
			animationSize.From = 0;
			animationSize.To = 360;
			animationAngle.Duration = TimeSpan.FromSeconds(7);
			animationSize.Duration = TimeSpan.FromSeconds(3);
			animationAngle.RepeatBehavior = RepeatBehavior.Forever;
			animationSize.RepeatBehavior = RepeatBehavior.Forever;
			//sample.AngularSize = 300;
			//sample.Angle = 52; return;
			sample.BeginAnimation(EllipticalArcShape.AngleProperty, animationAngle);
			sample.BeginAnimation(EllipticalArcShape.AngularSizeProperty, animationSize);
			// colors:
			ColorAnimation animationColor = new ColorAnimation();
			SolidColorBrush brush = new SolidColorBrush();
			sample.Fill = brush;
			animationColor.From = Color.FromRgb(randomColor(), randomColor(), randomColor()); 
			animationColor.To = Color.FromRgb(randomColor(), randomColor(), randomColor());
			animationColor.Duration = TimeSpan.FromSeconds(1);
			animationColor.Completed += (sender, eventArgs) => {
				animationColor.From = brush.Color;
				animationColor.To = Color.FromRgb(randomColor(), randomColor(), randomColor());
				brush.BeginAnimation(SolidColorBrush.ColorProperty, animationColor);
			}; //animationColor.Completed
			brush.BeginAnimation(SolidColorBrush.ColorProperty, animationColor);
		} //OnContentRendered

		void nonRectangularWindowDemo() {
			NonRectangularDemo wnd = nonRectangularWindow;
			if (nonRectangularWindow != null) {
				nonRectangularWindow.Show();
				return;
			} //if
			wnd = new NonRectangularDemo();
			nonRectangularWindow = wnd;
			wnd.Owner = this;
			wnd.Left = this.Left + this.ActualWidth;
			wnd.Top = this.Top;
			wnd.Show();
		} //nonRectangularWindowDemo

		Random random;
		//Window nonRectangularWindow;
		NonRectangularDemo nonRectangularWindow;
		EllipseList list = new EllipseList();

	} //class MainWindow

} //namespace Arc.Ui
	