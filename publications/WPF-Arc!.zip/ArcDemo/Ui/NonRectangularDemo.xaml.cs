﻿/*  
    
	WPF Arc

    Copyright © 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1181872/WPF-Arc

*/

namespace Arc.Ui {
	using System;
	using System.Windows;
	using System.Windows.Media;
	using System.Windows.Media.Animation;
	using Mouse = System.Windows.Input.Mouse;

	public partial class NonRectangularDemo : Window {

		const double angularSize = 295;
		const double animatedAngularSize = 360;
		const double animationDuration = 0.7;
		
		public NonRectangularDemo() {
			InitializeComponent();
			AllowsTransparency = true;
			WindowStyle = WindowStyle.None;
			this.buttonClose.Click += (sender, eventArgs) => { Hide(); };
			Point moving = new Point();
			MouseDown += (sender, eventArgs) => {
				moving = eventArgs.GetPosition(this);
				CaptureMouse();
			}; //wnd.MouseDown
			MouseUp += (sender, eventArgs) => {
				ReleaseMouseCapture();
			}; //wnd.MouseUp
			MouseMove += (sender, eventArgs) => {
				if (Mouse.Captured != this) return;
				Point pos = PointToScreen(eventArgs.GetPosition(this));
				Left = pos.X - moving.X;
				Top = pos.Y - moving.Y;
			}; //window.MouseMove
			clip.AngularSize = angularSize;
			clip.RadiusX = Width / 2;
			clip.RadiusY = Height / 2;
			clip.Center = new Point(Width / 2, Height / 2);
			this.Clip = clip;
		} //NonRectangularDemo

		protected override void OnClosing(System.ComponentModel.CancelEventArgs e) {
			base.OnClosing(e);
			Hide();
			e.Cancel = true;
			if (Owner != null)
				Owner.Activate();
		} //OnClosing

		protected override void OnContentRendered(System.EventArgs e) {
			base.OnContentRendered(e);
			DoubleAnimation animation = new DoubleAnimation();
			animation.From = angularSize;
			animation.To = animatedAngularSize;
			animation.Duration = TimeSpan.FromSeconds(animationDuration);
			animation.Completed += (sender, eventArgs) => {
				if (Math.Abs(animatedAngularSize - clip.AngularSize) < Math.Abs(clip.AngularSize - angularSize)) {
					animation.To = angularSize;
					animation.From = animatedAngularSize;
				} else {
					animation.From = angularSize;
					animation.To = animatedAngularSize;
				} //if
				clip.BeginAnimation(EllipticalArcGeometry.AngularSizeProperty, animation);
			}; //animation.Completed
			clip.BeginAnimation(EllipticalArcGeometry.AngularSizeProperty, animation);
		} //OnContentRendered

		EllipticalArcGeometry clip = new EllipticalArcGeometry();

	} //NonRectangularDemo

} //namespace
