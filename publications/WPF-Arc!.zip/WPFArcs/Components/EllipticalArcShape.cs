﻿/*  
    
	WPF Arc

    Copyright © 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1181872/WPF-Arc

*/

namespace System.Windows.Shapes {
	using System.Windows.Media;

	public partial class EllipticalArcShape : Shape {

		public EllipticalArcShape() {
			StrokeLineJoin = PenLineJoin.Bevel;
			Rectangle rect = new Rectangle();
			SizeChanged += (sender, eventArgs) => {
				BeginInit();
				geometry.RadiusX = ActualWidth / 2;
				geometry.RadiusY = ActualHeight / 2;
				geometry.Center = new Point(geometry.RadiusX, geometry.RadiusY);
				EndInit();
			}; //SizeChanged
		} //EllipticalArcShape

		protected override Geometry DefiningGeometry {
			get { return geometry; }
		} //DefiningGeometry

		EllipticalArcGeometry geometry = new EllipticalArcGeometry();

	} //class EllipticalArcShape

} //namespace
