﻿/*  
    
	WPF Arc

    Copyright © 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1181872/WPF-Arc

*/

namespace System.Windows.Shapes {
	using System.Windows.Media;
	using System.Windows;

	public partial class EllipticalArcShape {

		static FrameworkPropertyMetadata StrokeOptionsPropertyMetadata =
			new FrameworkPropertyMetadata(
				EllipticalArcGeometryStrokeOptions.Both, //default
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
					((EllipticalArcShape)@object).geometry.StrokeOptions = (EllipticalArcGeometryStrokeOptions)eventArgs.NewValue;
				}));
		public static DependencyProperty StrokeOptionsProperty =
			DependencyProperty.Register("StrokeOptions", typeof(EllipticalArcGeometryStrokeOptions), typeof(EllipticalArcShape), StrokeOptionsPropertyMetadata);
		public EllipticalArcGeometryStrokeOptions StrokeOptions {
			get { return (EllipticalArcGeometryStrokeOptions)GetValue(StrokeOptionsProperty); }
			set {
				SetValue(StrokeOptionsProperty, value);
				geometry.StrokeOptions = value;
			} //set StrokeOptions
		} //StrokeOptions

		static FrameworkPropertyMetadata AnglePropertyMetadata =
			new FrameworkPropertyMetadata(
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
					((EllipticalArcShape)@object).geometry.Angle = (double)eventArgs.NewValue;
				}));
		public static DependencyProperty AngleProperty =
			DependencyProperty.Register("Angle", typeof(double), typeof(EllipticalArcShape), AnglePropertyMetadata);
		public double Angle {
			get { return (double)GetValue(AngleProperty); }
			set {
				SetValue(AngleProperty, value);
				geometry.Angle = value;
			} //set Angle
		} //Angle

		static FrameworkPropertyMetadata AngularSizePropertyMetadata =
			new FrameworkPropertyMetadata(
				Arcs.DefinitionSet.MaxAngle, //default
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
					((EllipticalArcShape)@object).geometry.AngularSize = (double)eventArgs.NewValue;
				}));
		public static DependencyProperty AngularSizeProperty =
			DependencyProperty.Register("AngularSize", typeof(double), typeof(EllipticalArcShape), AngularSizePropertyMetadata);
		public double AngularSize {
			get { return (double)GetValue(AngularSizeProperty); }
			set {
				double normalized = Arcs.DefinitionSet.NormalizeAngle(value);
				SetValue(AngularSizeProperty, normalized);
				geometry.AngularSize = normalized;
			} //set AngularSize
		} //AngularSize

		static FrameworkPropertyMetadata VariantPropertyMetadata =
			new FrameworkPropertyMetadata(
				EllipticalArcGeometryVariant.Sector, //default 
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
					((EllipticalArcShape)@object).geometry.Variant = (EllipticalArcGeometryVariant)eventArgs.NewValue;
				}));
		public static DependencyProperty VariantProperty =
			DependencyProperty.Register("Variant", typeof(EllipticalArcGeometryVariant), typeof(EllipticalArcShape), VariantPropertyMetadata);
		public EllipticalArcGeometryVariant Variant {
			get { return (EllipticalArcGeometryVariant)GetValue(VariantProperty); }
			set {
				SetValue(VariantProperty, value);
				geometry.Variant = value;
			} //set Variant
		} //Variant

	} //class EllipticalArcShape

} //namespace
