﻿/*  
    
	WPF Arc

    Copyright © 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1181872/WPF-Arc

*/

namespace System.Windows.Media {

	public enum EllipticalArcGeometryVariant { Sector, Segment, }
	public enum EllipticalArcGeometryStrokeOptions {
		Curve = 1, StraightLines = 2,
		Both = Curve |StraightLines, None = 0, }

	public partial class EllipticalArcGeometry : Animation.Animatable {

		public EllipticalArcGeometry() {
			geometry = new PathGeometry();
			sectorFigure.StartPoint = Center;
			sectorFigure.IsClosed = true;
			arcSegment.IsStroked = true;
			arcSegment.SweepDirection = SweepDirection.Counterclockwise;
			augmentingArcSegment.IsStroked = true;
			augmentingArcSegment.SweepDirection = SweepDirection.Counterclockwise;
			line.IsStroked = true;
			sectorFigure.Segments.Add(line);
			sectorFigure.Segments.Add(arcSegment);
			segmentFigure.Segments.Add(arcSegment);
			segmentFigure.IsClosed = true;
			ellipseFigure.Segments.Add(arcSegment);
			ellipseFigure.Segments.Add(augmentingArcSegment);
			ellipseFigure.IsClosed = true;
			geometry.Figures.Add(sectorFigure);
			TransformGroup transforms = new TransformGroup();
			transforms.Children.Add(rotateTransform);
			transforms.Children.Add(scaleTransform);
			geometry.Transform = transforms;
		} //EllipticalArcGeometry

		// to implement Animation.Animatable:
		protected override Freezable CreateInstanceCore() {
			return this;
		} //CreateInstanceCore

		public static implicit operator Geometry(EllipticalArcGeometry instance) {
			return instance.geometry;
		} //Geometry

		void setSegments() {
			if (Variant != EllipticalArcGeometryVariant.Sector)
				geometry.Figures[0] = segmentFigure;
			else
				geometry.Figures[0] = sectorFigure;
			double angleTo = AngularSize;
			bool fullEllipse = AngularSize >= Arcs.DefinitionSet.MaxAngle;
			if (fullEllipse)
				angleTo = Arcs.DefinitionSet.MaxAngle / 2;
			Point first = new Point(Center.X + RadiusX, Center.Y);
			Point second = new Point(Center.X + RadiusX * cos(angleTo), Center.Y - RadiusX * sin(angleTo));
			sectorFigure.StartPoint = Center;
			line.Point = first;
			arcSegment.Point = second;
			arcSegment.IsLargeArc = AngularSize > Arcs.DefinitionSet.MaxAngle / 2;
			if (Variant != EllipticalArcGeometryVariant.Sector)
				segmentFigure.StartPoint = first;
			if (fullEllipse) {
				ellipseFigure.StartPoint = first;
				augmentingArcSegment.Size = arcSegment.Size;
				augmentingArcSegment.Point = first;
				geometry.Figures[0] = ellipseFigure;
			} //if
		} //setSegments
		static double sin(double degrees) {
			return Math.Sin(degrees * 2d * Math.PI / Arcs.DefinitionSet.MaxAngle);
		} //sin
		static double cos(double degrees) {
			return Math.Cos(degrees * 2d * Math.PI / Arcs.DefinitionSet.MaxAngle);
		} //cos

		void centerTransform() {
			scaleTransform.CenterX = size.Width / 2;
			scaleTransform.CenterY = size.Height / 2;
			scaleTransform.ScaleY = size.Height / size.Width;
			rotateTransform.CenterX = scaleTransform.CenterX;
			rotateTransform.CenterY = scaleTransform.CenterY;
		} //centerTransform

		void setCenter(Point value) {
			arcSegment.Size = new Size(value.X, value.X);
			sectorFigure.StartPoint = Center;
			centerTransform();
			setSegments();
		} //setCenter

		void setRadiusX(double value) {
			size = new Size(2d * value, size.Height);
			arcSegment.Size = new Size(size.Width, size.Width);
			centerTransform();
			setSegments();
		} //setRadiusX

		void setRadiusY(double value) {
			size = new Size(size.Width, 2d * value);
			arcSegment.Size = new Size(size.Width, size.Width);
			centerTransform();
			setSegments();
		} //setRadiusY

		void setAngle(double value) {
			rotateTransform.Angle = -value;
			setSegments();
		} //setAngle

		void setAngularSize() {
			setSegments();
		} //setAngularSize

		void setVariant() {
			setSegments();
		} //setVariant

		void setStrokeOptions(EllipticalArcGeometryStrokeOptions value) {
			bool curves = (value & EllipticalArcGeometryStrokeOptions.Curve) > 0;
			bool straight = (value & EllipticalArcGeometryStrokeOptions.StraightLines) > 0;
			arcSegment.IsStroked = curves;
			augmentingArcSegment.IsStroked = curves;
			line.IsStroked = straight;
			sectorFigure.IsClosed = straight;
			segmentFigure.IsClosed = straight;
		} //setStrokeOptions

		Size size;
		PathGeometry geometry;
		PathFigure sectorFigure = new PathFigure();
		PathFigure segmentFigure = new PathFigure();
		PathFigure ellipseFigure = new PathFigure();
		ArcSegment arcSegment = new ArcSegment();
		ArcSegment augmentingArcSegment = new ArcSegment();
		LineSegment line = new LineSegment();
		ScaleTransform scaleTransform = new ScaleTransform();
		RotateTransform rotateTransform = new RotateTransform();

	} //class EllipticalArcGeometry

} //namespace
