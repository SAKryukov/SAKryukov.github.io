﻿/*  
    
	WPF Arc

    Copyright © 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1181872/WPF-Arc

*/

namespace Arcs {

	internal static class DefinitionSet {
		
		internal const double MaxAngle = 360;
		
		internal static double NormalizeAngle(double value) {
			if (value < 0) return 0;
			if (value > MaxAngle) return MaxAngle;
			return value;
		} //NormalizeAngle

	} //class DefinitionSet

} //namespace