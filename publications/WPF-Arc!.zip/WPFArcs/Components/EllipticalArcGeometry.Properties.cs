﻿/*  
    
	WPF Arc

    Copyright © 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1181872/WPF-Arc

*/

namespace System.Windows.Media {

	public partial class EllipticalArcGeometry {

		static FrameworkPropertyMetadata StrokeOptionsPropertyMetadata =
			new FrameworkPropertyMetadata(
				EllipticalArcGeometryStrokeOptions.Both, //default
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
					((EllipticalArcGeometry)@object).setStrokeOptions((EllipticalArcGeometryStrokeOptions)eventArgs.NewValue);
				}));
		public static DependencyProperty StrokeOptionsProperty =
			DependencyProperty.Register("StrokeOptions", typeof(EllipticalArcGeometryStrokeOptions), typeof(EllipticalArcGeometry), StrokeOptionsPropertyMetadata);
		public EllipticalArcGeometryStrokeOptions StrokeOptions {
			get { return (EllipticalArcGeometryStrokeOptions)GetValue(StrokeOptionsProperty); }
			set {
				SetValue(StrokeOptionsProperty, value);
				setStrokeOptions(value);
			} //set StrokeOptions
		} //StrokeOptions

		static FrameworkPropertyMetadata CenterPropertyMetadata =
			new FrameworkPropertyMetadata(
				new Point(), //default
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
					((EllipticalArcGeometry)@object).setCenter((Point)eventArgs.NewValue);
				}));
		public static DependencyProperty CenterProperty =
			DependencyProperty.Register("Center", typeof(Point), typeof(EllipticalArcGeometry), CenterPropertyMetadata);
		public Point Center {
			get { return (Point)GetValue(CenterProperty); }
			set {
				SetValue(CenterProperty, value);
				setCenter(value);
			} //set Center
		} //Center

		static FrameworkPropertyMetadata RadiusXPropertyMetadata =
			new FrameworkPropertyMetadata(
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
					((EllipticalArcGeometry)@object).setRadiusX((double)eventArgs.NewValue);
				}));
		public static DependencyProperty RadiusXProperty =
			DependencyProperty.Register("RadiusX", typeof(double), typeof(EllipticalArcGeometry), RadiusXPropertyMetadata);
		public double RadiusX {
			get { return (double)GetValue(RadiusXProperty); }
			set {
				SetValue(RadiusXProperty, value);
				setRadiusX(value);
			} //set RadiusX
		} //RadiusX

		static FrameworkPropertyMetadata RadiusYPropertyMetadata =
			new FrameworkPropertyMetadata(
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
					((EllipticalArcGeometry)@object).setRadiusY((double)eventArgs.NewValue);
				}));
		public static DependencyProperty RadiusYProperty =
			DependencyProperty.Register("RadiusY", typeof(double), typeof(EllipticalArcGeometry), RadiusYPropertyMetadata);
		public double RadiusY {
			get { return (double)GetValue(RadiusYProperty); }
			set {
				SetValue(RadiusYProperty, value);
				setRadiusY(value);
			} //set RadiusY
		} //RadiusY

		static FrameworkPropertyMetadata AnglePropertyMetadata =
			new FrameworkPropertyMetadata(
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
					((EllipticalArcGeometry)@object).setAngle((double)eventArgs.NewValue);
				}));
		public static DependencyProperty AngleProperty =
			DependencyProperty.Register("Angle", typeof(double), typeof(EllipticalArcGeometry), AnglePropertyMetadata);
		public double Angle {
			get { return (double)GetValue(AngleProperty); }
			set {
				SetValue(AngleProperty, value);
				setAngle(value);
			} //set Angle
		} //Angle

		static FrameworkPropertyMetadata AngularSizePropertyMetadata =
			new FrameworkPropertyMetadata(
				Arcs.DefinitionSet.MaxAngle, //default
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
					((EllipticalArcGeometry)@object).setAngularSize();
				}));
		public static DependencyProperty AngularSizeProperty =
			DependencyProperty.Register("AngularSize", typeof(double), typeof(EllipticalArcGeometry), AngularSizePropertyMetadata);
		public double AngularSize {
			get { return (double)GetValue(AngularSizeProperty); }
			set {
				SetValue(AngularSizeProperty, Arcs.DefinitionSet.NormalizeAngle(value));
				setAngularSize();
			} //set AngularSize
		} //AngularSize

		static FrameworkPropertyMetadata VariantPropertyMetadata =
			new FrameworkPropertyMetadata(
				EllipticalArcGeometryVariant.Sector, //default
				new PropertyChangedCallback((@object, eventArgs) => {
					if (eventArgs.OldValue == eventArgs.NewValue) return;
					((EllipticalArcGeometry)@object).setVariant();
				}));
		public static DependencyProperty VariantProperty =
			DependencyProperty.Register("Variant", typeof(EllipticalArcGeometryVariant), typeof(EllipticalArcGeometry), VariantPropertyMetadata);
		public EllipticalArcGeometryVariant Variant {
			get { return (EllipticalArcGeometryVariant)GetValue(VariantProperty); }
			set {
				SetValue(VariantProperty, value);
				setVariant();
			} //set Variant
		} //Variant

	} //class EllipticalArcGeometry

} //namespace
