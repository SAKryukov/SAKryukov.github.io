﻿/*  
    
	WPF Arc

    Copyright © 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1181872/WPF-Arc

*/

namespace Bug.Components {
	using System.Windows;
	using System.Windows.Shapes;
	using System.Windows.Media;

	class SamplePathShape : Shape {

		public SamplePathShape() {
			pathGeometry = new PathGeometry();
			combinedGeometry = new CombinedGeometry(pathGeometry, null);
			lines = new LineSegment[4];
			figure.IsClosed = true;
			for (int index = 0; index < lines.Length; ++index) {
				lines[index] = new LineSegment();
				if (index < lines.Length - 1)
					figure.Segments.Add(lines[index]);
			} //loop
			pathGeometry.Figures.Add(figure);
			SizeChanged += (sender, eventArgs) => {
				lines[0].Point = new Point(ActualWidth - 1, 0);
				lines[1].Point = new Point(ActualWidth - 1, ActualHeight - 1);
				lines[2].Point = new Point(0, ActualHeight - 1);
				lines[3].Point = new Point(0, 0);
			}; //SizeChanged
			geometry = pathGeometry;
		} //SamplePathShape

		internal bool IsCombinedGeometry { // should be called before showing
			set {
				if (value)
					geometry = combinedGeometry;
				else
					geometry = pathGeometry;
			} //set Combined
		} //IsCombinedGeometry
		internal bool IsClosed { // should be called before showing
			set { figure.IsClosed = value; }
		} //IsCombinedGeometry

		internal void SetStroke(int lineNumber, bool value) {
			if (lineNumber >= 0 && lineNumber < lines.Length)
				lines[lineNumber].IsStroked = value;
			if (lineNumber == lines.Length - 1)
				IsClosed = value;
		} //SetStroke

		protected override Geometry DefiningGeometry {
			get { return geometry; }
		} //DefiningGeometry
	
		Geometry geometry;
		PathGeometry pathGeometry;
		CombinedGeometry combinedGeometry;
		LineSegment[] lines;
		PathFigure figure = new PathFigure();

	} //ExceptionStackItemDelimiter

} //namespace
