﻿/*  
    
	WPF Arc

    Copyright © 2017 by Sergey A Kryukov
    http://www.codeproject.com/Members/SAKryukov
    http://www.SAKryukov.org

    Original publication:
	https://www.codeproject.com/Articles/1181872/WPF-Arc

*/

namespace Bug.Ui {
	using System;
	using System.Windows.Controls;
	using System.Windows;
	using Components;

	public partial class MainWindow : Window {

		public MainWindow() {
			InitializeComponent();
			SamplePathShape[] shapes = new SamplePathShape[] { pathPath, pathCombined, };
			pathCombined.IsCombinedGeometry = true;
			pathCombined.IsCombinedGeometry = true;
			CheckBox[] checkBoxes = new CheckBox[panelBoxes.Children.Count];
			var setStroke = new Action<object, bool>((sender, on) => {
				CheckBox cbSender = (CheckBox)sender;
				int index = int.Parse(cbSender.DataContext.ToString());
				foreach (var shape in shapes)
					shape.SetStroke(index, on);
			}); //setStroke
			foreach (var child in panelBoxes.Children) {
				CheckBox cb = (CheckBox)child;
				if (cb.IsEnabled)
					cb.IsChecked = true;
				cb.Checked += (sender, eventArgs) => { setStroke(sender, true); };
				cb.Unchecked += (sender, eventArgs) => { setStroke(sender, false); };
			} // loop
		} //MainWindow

	} //class MainWindow

} //namespace Bug.Ui
