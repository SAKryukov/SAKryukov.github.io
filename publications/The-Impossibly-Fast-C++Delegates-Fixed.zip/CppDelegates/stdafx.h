#pragma once
#include "targetver.h"
#include "stdafx.h"
#include "MultiCastDelegate.h"
#include <iostream>
#include <chrono>

