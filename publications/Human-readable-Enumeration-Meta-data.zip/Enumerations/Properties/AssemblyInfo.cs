﻿/*
    Enumeration classes:
    Generic class Enumeration provides iteration capabilities based on enumeration or any other type with static fields;
    Generic class EnumerationIndexedArray implements enumeration-indexed arrays
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org
*/

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Enumerations")]
[assembly: AssemblyDescription("Introduction of enumeration-based iteration and array indexing")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Sergey A Kryukov")]
[assembly: AssemblyProduct("Enumerations")]
[assembly: AssemblyCopyright("Copyright © 2009, 2010 by Sergey A Kryukov, http://www.SAKryukov.org")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("a51fe648-8476-44b6-b87b-c6681df3863d")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
