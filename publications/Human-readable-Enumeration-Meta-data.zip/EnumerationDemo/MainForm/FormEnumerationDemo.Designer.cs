﻿namespace EnumerationDemo {
    partial class FormEnumerationDemo {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.panelTests = new System.Windows.Forms.Panel();
            this.panelOutput = new System.Windows.Forms.Panel();
            this.panelListPad = new System.Windows.Forms.Panel();
            this.panelOutput.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelTests
            // 
            this.panelTests.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelTests.Location = new System.Drawing.Point(424, 0);
            this.panelTests.Name = "panelTests";
            this.panelTests.Size = new System.Drawing.Size(183, 524);
            this.panelTests.TabIndex = 0;
            // 
            // panelOutput
            // 
            this.panelOutput.Controls.Add(this.panelListPad);
            this.panelOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelOutput.Location = new System.Drawing.Point(0, 0);
            this.panelOutput.Name = "panelOutput";
            this.panelOutput.Size = new System.Drawing.Size(424, 524);
            this.panelOutput.TabIndex = 1;
            // 
            // panelListPad
            // 
            this.panelListPad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelListPad.Location = new System.Drawing.Point(0, 0);
            this.panelListPad.Name = "panelListPad";
            this.panelListPad.Size = new System.Drawing.Size(424, 524);
            this.panelListPad.TabIndex = 0;
            // 
            // FormEnumerationDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 524);
            this.Controls.Add(this.panelOutput);
            this.Controls.Add(this.panelTests);
            this.Name = "FormEnumerationDemo";
            this.panelOutput.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelTests;
        private System.Windows.Forms.Panel panelOutput;
        private System.Windows.Forms.Panel panelListPad;
    }
}

