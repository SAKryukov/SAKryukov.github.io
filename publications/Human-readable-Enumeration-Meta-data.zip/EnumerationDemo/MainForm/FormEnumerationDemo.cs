﻿/*
    Enumeration demo:
    Generic class Enumeration provides iteration capabilities based on enumeration or any other type with static fields;
    Generic class EnumerationIndexedArray implements enumeration-indexed arrays
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org
*/

using System;
using System.Windows.Forms;

namespace EnumerationDemo {

    public partial class FormEnumerationDemo : Form {
        
        public FormEnumerationDemo() {
            InitializeComponent();
            Setup();
        } //FormEnumerationDemo
        
        [STAThread]
        static void Main() {
            Application.EnableVisualStyles();
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormEnumerationDemo());
        } //Main

    } //class FormEnumerationDemo

} //namespace EnumerationDemo
