﻿/*  
    DynamicMethodDispatcher and MuticastDynamicMethodDispatcher classes:
    Generic class DynamicMethodDispatcher dispatches a call to a generic delegate isntance found by a dictionary key
    Generic class MuticastDynamicMethodDispatcher is a multi-case version of DynamicMethodDispatcher.
   
    Test/Demo Application: System.Windows.Forms, Windows
    
    Copyright (C) 2006-2011 by Sergey A Kryukov
    http://www.SAKryukov.org
*/
using System.Windows.Forms;

namespace TestMessageDispatching {
    
    public partial class FormMessageHandler : Form {
        
        public FormMessageHandler() {
            InitializeComponent();
            Setup();
        } //FormMessageHandler

    } //class FormMessageHandler

} //namespace TestMessageDispatching
