﻿/*  
    DynamicMethodDispatcher and MuticastDynamicMethodDispatcher classes:
    Generic class DynamicMethodDispatcher dispatches a call to a generic delegate isntance found by a dictionary key
    Generic class MuticastDynamicMethodDispatcher is a multi-case version of DynamicMethodDispatcher.
   
    Test/Demo Application: System.Windows.Forms, Windows
    
    Copyright (C) 2006-2011 by Sergey A Kryukov
    http://www.SAKryukov.org
*/
using System.Windows.Forms;

namespace TestMessageDispatching.Forms {

    public partial class FormMessageVisualizer : Form {
        
        public FormMessageVisualizer() {
            InitializeComponent();
            Setup();
        } //FormMessageVisualizer

        [System.STAThread]
        static void Main() {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FormMessageVisualizer());
        } //Main

    } //class FormMessageVisualizer

} //namespace TestMessageDispatching.Forms
