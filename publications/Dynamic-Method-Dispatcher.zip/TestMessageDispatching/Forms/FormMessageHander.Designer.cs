﻿/*  
    DynamicMethodDispatcher and MuticastDynamicMethodDispatcher classes:
    Generic class DynamicMethodDispatcher dispatches a call to a generic delegate isntance found by a dictionary key
    Generic class MuticastDynamicMethodDispatcher is a multi-case version of DynamicMethodDispatcher.
   
    Test/Demo Application: System.Windows.Forms, Windows
    
    Copyright (C) 2006-2011 by Sergey A Kryukov
    http://www.SAKryukov.org
*/
namespace TestMessageDispatching {
    partial class FormMessageHandler {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.SuspendLayout();
            // 
            // FormMessageHandler
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(221, 94);
            this.Name = "FormMessageHandler";
            this.ResumeLayout(false);

        }

        #endregion


    }
}

