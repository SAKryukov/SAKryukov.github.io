﻿/*  
    DynamicMethodDispatcher and MuticastDynamicMethodDispatcher classes:
    Generic class DynamicMethodDispatcher dispatches a call to a generic delegate isntance found by a dictionary key
    Generic class MuticastDynamicMethodDispatcher is a multi-case version of DynamicMethodDispatcher.
   
    Test/Demo Application: System.Windows.Forms, Windows
    
    Copyright (C) 2006-2011 by Sergey A Kryukov
    http://www.SAKryukov.org
*/
namespace TestMessageDispatching.Forms {
    using System;
    using System.Windows.Forms;
    using Time = System.DateTime;

    public partial class FormMessageVisualizer : IMessageLogger {

        void Setup() {
            Width = 600; //code project requirement
            this.ShowIcon = false;
            Text = Application.ProductName;
            SetupTextRenderers();
            SetupTabs();
            FormMessageHandler handler = new FormMessageHandler();
            handler.MessageLogger = this;
            handler.Owner = this;
            handler.ShowIcon = false;
            handler.ShowInTaskbar = false;
            this.Shown += delegate(object sender, System.EventArgs evenArgs) {
                handler.Show();
                handler.Top = this.Top + this.Height / 2;
                handler.Left = this.Left + this.Width;
            }; //Shown
            this.SizeChanged += delegate(object sender, System.EventArgs evenArgs) { AutoResize(); };
        } //Setup

        enum LogPage { General = 0, Keyboard, Mouse, Status, }
        enum CommonColumn { Time = 0, Message, ID, WParam, LParam, Comment, }
        enum MouseColumn { X = 0, Y, Status, }
        enum KeyboardColumn { Key = 0, Code, }
        enum StatusColumn { Status = 0, }
        int[] LogPageIndexes = new int[] { (int)LogPage.General, (int)LogPage.Keyboard, (int)LogPage.Mouse, (int)LogPage.Status, };
        ListView[] ListViews = new ListView[(int)LogPage.Status + 1];
        ListView this[LogPage index] { get { return ListViews[(int)index]; } }
        int CustomColumnStart;
        delegate string RenderText(ref Time time, ref MessageInfo info, string customData, bool shortForm);
        RenderText[] TestRenderers;

        static string FormatValue(CommonColumn column, string value, bool shortForm) {
            if (shortForm) return value;
            return string.Format("  {0}: {1}  ", column, value);
        } //FormatValue

        void SetupTextRenderers() {
            TestRenderers = new RenderText[Enum.GetValues(typeof(CommonColumn)).Length];
            TestRenderers[(int)CommonColumn.Time] = delegate(ref Time time, ref MessageInfo info, string customData, bool shortForm) {
                string sTime = string.Format("{0:s}", time);
                sTime = sTime.Replace('T', ' ');
                return FormatValue(CommonColumn.Time, sTime, shortForm);
            };
            TestRenderers[(int)CommonColumn.Message] = delegate(ref Time time, ref MessageInfo info, string customData, bool shortForm) {
                return FormatValue(CommonColumn.Message, info.WindowsMessage.ToString(), shortForm);
            };
            TestRenderers[(int)CommonColumn.ID] = delegate(ref Time time, ref MessageInfo info, string customData, bool shortForm) {
                return FormatValue(CommonColumn.ID, info.Msg.ToString("X"), shortForm);
            };
            TestRenderers[(int)CommonColumn.WParam] = delegate(ref Time time, ref MessageInfo info, string customData, bool shortForm) {
                return FormatValue(CommonColumn.WParam, info.WParam.ToString("X"), shortForm);
            };
            TestRenderers[(int)CommonColumn.LParam] = delegate(ref Time time, ref MessageInfo info, string customData, bool shortForm) {
                return FormatValue(CommonColumn.LParam, info.LParam.ToString("X"), shortForm);
            };
            TestRenderers[(int)CommonColumn.Comment] = delegate(ref Time time, ref MessageInfo info, string customData, bool shortForm) {
                return FormatValue(CommonColumn.Comment, customData, shortForm);
            };
        } //SetupTextRenderers

        void SetupTabs() {
            this.tabControl.TabPages.Clear();
            CustomColumnStart = Enum.GetValues(typeof(CommonColumn)).Length - 1;
            for (LogPage index = (LogPage)0; index <= (LogPage)(Enum.GetValues(typeof(LogPage)).Length - 1); index++) {
                this.tabControl.TabPages.Add(index.ToString());
                ListView lv = new ListView();
                lv.BackColor = System.Drawing.Color.FromArgb(255, 255, 210);
                SetupListView(lv, index);
                ListViews[(int)index] = lv;
                tabControl.TabPages[(int)index].Controls.Add(lv);
            } //if
            SetupStatus();
        } //SetupTabs

        void AutoResize(ListView listView) {
            foreach (ColumnHeader header in listView.Columns) {
                header.AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
                int headerSize = header.Width;
                if (listView.Items.Count < 1) continue;
                header.AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);
                int textSize = header.Width;
                if (textSize < headerSize)
                    header.AutoResize(ColumnHeaderAutoResizeStyle.HeaderSize);
            } //loop
        } //AutoResize
        void AutoResize() {
            foreach (ListView lv in ListViews)
                AutoResize(lv);
        } //AutoResize

        void SetupStatus() {
            for (CommonColumn index = (CommonColumn)0; index < (CommonColumn)(Enum.GetValues(typeof(CommonColumn)).Length - 1); index++) {
                ToolStripStatusLabel label = new ToolStripStatusLabel(index.ToString());
                label.BorderStyle = Border3DStyle.SunkenOuter;
                label.BorderSides = ToolStripStatusLabelBorderSides.All;
                label.AutoSize = true;
                label.Visible = false;
                statusStrip.Items.Add(label);
            } //loop
        } //SetupStatus

        void SetupListView(ListView listView, LogPage kind) {
            listView.Dock = DockStyle.Fill;
            listView.View = View.Details;
            int lastIndex = 0;
            int commentIndex = Enum.GetValues(typeof(CommonColumn)).Length - 1;
            for (CommonColumn index = (CommonColumn)0; index <= (CommonColumn)commentIndex; index++) {
                ColumnHeader header = new ColumnHeader();
                if ((int)index == 0 || (int)index == commentIndex)
                    header.TextAlign = HorizontalAlignment.Left;
                else
                    header.TextAlign = HorizontalAlignment.Right;
                header.Text = index.ToString();
                listView.Columns.Add(header);
                lastIndex = header.Index;
            } //loop
            if (kind == LogPage.Mouse) {
                for (MouseColumn index = (MouseColumn)0; index <= (MouseColumn)(Enum.GetValues(typeof(MouseColumn)).Length - 1); index++) {
                    ColumnHeader header = new ColumnHeader();
                    header.TextAlign = HorizontalAlignment.Right;
                    header.Text = index.ToString();
                    listView.Columns.Insert(lastIndex + (int)index, header);
                } //loop
            } else if (kind == LogPage.Keyboard) {
                for (KeyboardColumn index = (KeyboardColumn)0; index <= (KeyboardColumn)(Enum.GetValues(typeof(KeyboardColumn)).Length - 1); index++) {
                    ColumnHeader header = new ColumnHeader();
                    header.TextAlign = HorizontalAlignment.Right;
                    header.Text = index.ToString();
                    listView.Columns.Insert(lastIndex + (int)index, header);
                } //loop
            } else if (kind == LogPage.Status) {
                for (StatusColumn index = (StatusColumn)0; index <= (StatusColumn)(Enum.GetValues(typeof(StatusColumn)).Length - 1); index++) {
                    ColumnHeader header = new ColumnHeader();
                    header.TextAlign = HorizontalAlignment.Right;
                    header.Text = index.ToString();
                    listView.Columns.Insert(lastIndex, header);
                } //loop
            } //if
            AutoResize(listView);
        } //SetupListView

        ListViewItem ShowCommon(Time time, ListView listView, MessageInfo info, string customData, bool autoResize) {
            ListViewItem item = new ListViewItem(TestRenderers[(int)CommonColumn.Time](ref time, ref info, customData, true));
            for (int index = 0; index < listView.Columns.Count - 1; index++)
                item.SubItems.Add(new ListViewItem.ListViewSubItem());
            for (CommonColumn index = (CommonColumn)1; index < (CommonColumn)(Enum.GetValues(typeof(CommonColumn)).Length - 1); index++) {
                item.SubItems[(int)index].Text = TestRenderers[(int)index](ref time, ref info, customData, true);
            } //loop
            item.SubItems[listView.Columns.Count - 1].Text = customData;
            listView.Items.Add(item);
            if (autoResize)
                AutoResize(listView);
            listView.EnsureVisible(item.Index);
            ShowStatus(ref time, ref info, customData);
            return item;
        } //ShowCommon

        void ShowStatus(ref Time time, ref MessageInfo info, string customData) {
            for (CommonColumn index = (CommonColumn)0; index < (CommonColumn)(Enum.GetValues(typeof(CommonColumn)).Length - 1); index++) {
                statusStrip.Items[(int)index].Visible = true;
                statusStrip.Items[(int)index].Text = TestRenderers[(int)index](ref time, ref info, customData, false);
            } //loop
        } //ShowStatus

        #region IMessageLogger

        void IMessageLogger.ShowMessage(Time time, MessageInfo info, string customData) {
            ShowCommon(time, this[LogPage.General], info, customData, true);
        } //IMessageLogger.ShowMessage

        void IMessageLogger.ShowKeyboardMessage(Time time, MessageInfo info, string customData) {
            ListViewItem listItem = ShowCommon(time, this[LogPage.Keyboard], info, customData, false);
            string key;
            if (info.WindowsMessage == WindowsMessage.SYSCHAR || info.WindowsMessage == WindowsMessage.CHAR)
                key = string.Empty + info.Character;
            else
                key = info.VirtualKey.ToString();
            listItem.SubItems[CustomColumnStart + 0].Text = key;
            listItem.SubItems[CustomColumnStart + 1].Text = info.VirtualKey.ToString("X");
            AutoResize(listItem.ListView);
        } //IMessageLogger.ShowKeyboardMessage

        void IMessageLogger.ShowMouseMessage(Time time, MessageInfo info, string customData) {
            ListViewItem listItem = ShowCommon(time, this[LogPage.Mouse], info, customData, false);
            listItem.SubItems[CustomColumnStart + 0].Text = info.X.ToString();
            listItem.SubItems[CustomColumnStart + 1].Text = info.Y.ToString();
            listItem.SubItems[CustomColumnStart + 2].Text = info.MouseVirtualKey.ToString();
            AutoResize(listItem.ListView);
        } //IMessageLogger.ShowMouseMessage

        void IMessageLogger.ShowStatusMessage(Time time, MessageInfo info, string statusInfo, string customData) {
            ListViewItem listItem = ShowCommon(time, this[LogPage.Status], info, customData, false);
            listItem.SubItems[CustomColumnStart].Text = statusInfo;
            AutoResize(listItem.ListView);
        } //IMessageLogger.ShowStatusMessage
        
        #endregion IMessageLogger

    } //class FormMessageVisualizer

} //namespace TestMessageDispatching.Forms