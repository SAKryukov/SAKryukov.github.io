﻿/*  
    DynamicMethodDispatcher and MuticastDynamicMethodDispatcher classes:
    Generic class DynamicMethodDispatcher dispatches a call to a generic delegate isntance found by a dictionary key
    Generic class MuticastDynamicMethodDispatcher is a multi-case version of DynamicMethodDispatcher.
   
    Test/Demo Application: System.Windows.Forms, Windows
    
    Copyright (C) 2006-2011 by Sergey A Kryukov
    http://www.SAKryukov.org
*/
namespace TestMessageDispatching {
    using System;
    using System.Windows.Forms;
    using System.Drawing;
    using MessageDispatcher = SA.Universal.Technology.DynamicMethodDispatcher<WindowsMessage, MessageInfo, bool>;
    using Time = System.DateTime;

    public partial class FormMessageHandler {

        #region messageLogger

        internal IMessageLogger MessageLogger { get { return FIMessageLogger; } set { FIMessageLogger = value; } } //bodies added for compatibility with v.2.0
        //internal IMessageLogger MessageLogger { get; set; } //this form is good for C# version 3.5 or above
        IMessageLogger FIMessageLogger; //added for compatibility with v.2.0
        void ShowMessage(Time time, MessageInfo info, string customData) { if (MessageLogger != null) MessageLogger.ShowMessage(time, info, customData); }
        void ShowKeyboardMessage(Time time, MessageInfo info, string customData) { if (MessageLogger != null) MessageLogger.ShowKeyboardMessage(time, info, customData); }
        void ShowMouseMessage(Time time, MessageInfo info, string customData) { if (MessageLogger != null) MessageLogger.ShowMouseMessage(time, info, customData); }
        void ShowStatusMessage(Time time, MessageInfo info, string statusInfo, string customData) { if (MessageLogger != null) MessageLogger.ShowStatusMessage(time, info, statusInfo, customData); }
        #endregion messageLogger

        static string GetActivationMessage(MessageInfo msg, ref int count) {
            string activationMessage;
            if (msg.ActivationStatus != 0) {
                count++;
                activationMessage = string.Format("Activated: {0}", count);
            } else
                activationMessage = "Inactive";
            return activationMessage;
        } //GetActivationMessage

        protected override void OnPaint(PaintEventArgs e) {
            float height = this.Font.GetHeight(e.Graphics);
            e.Graphics.DrawString("Click/move mousе\nPress any key or key combination\nClick non-client area\nActivate System menu",
                this.Font, Brushes.Black, new RectangleF(10, 10, ClientRectangle.Width-10, ClientRectangle.Height-10));
        } //OnPaint

        void Setup() {
            this.BackColor = Color.Wheat;
            Text = " Test Messages";
            this.KeyPreview = true;
            MessageDispatcher.Add(WindowsMessage.NCCREATE, delegate(WindowsMessage key, MessageInfo msg) {
                ShowMessage(Time.Now, msg, "Non-client: Created");
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.NCCALCSIZE, delegate(WindowsMessage key, MessageInfo msg) {
                ShowMessage(Time.Now, msg, "Non-client: Size calculated");
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.CREATE, delegate(WindowsMessage key, MessageInfo msg) {
                ShowMessage(Time.Now, msg, "Created");
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.DESTROY, delegate(WindowsMessage key, MessageInfo msg) {
                ShowMessage(Time.Now, msg, "Destroyed");
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.NCDESTROY, delegate(WindowsMessage key, MessageInfo msg) {
                ShowMessage(Time.Now, msg, "Non-client: Destroyed");
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.NCPAINT, delegate(WindowsMessage key, MessageInfo msg) {
                ShowMessage(Time.Now, msg, "Non-client paint");
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.SYSCOMMAND, delegate(WindowsMessage key, MessageInfo msg) {
                SystemCommand cmd = (SystemCommand)((int)msg.SystemCommand & 0xFFF0);
                ShowMessage(Time.Now, msg, string.Format("System command: {0}", cmd));
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.NCACTIVATE, delegate(WindowsMessage key, MessageInfo msg) {
                ShowStatusMessage(Time.Now, msg, GetActivationMessage(msg, ref nonClientActivateCount), "Non-client activation");
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.ACTIVATEAPP, delegate(WindowsMessage key, MessageInfo msg) {
                ShowStatusMessage(Time.Now, msg, GetActivationMessage(msg, ref activateCount), "Application activation");
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.SETFOCUS, delegate(WindowsMessage key, MessageInfo msg) {
                focusCount++;
                ShowStatusMessage(Time.Now, msg, string.Empty, string.Format("Focused: {0}", focusCount));
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.KILLFOCUS, delegate(WindowsMessage key, MessageInfo msg) {
                ShowStatusMessage(Time.Now, msg, string.Empty, "Focus lost");
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.KEYUP, delegate(WindowsMessage key, MessageInfo msg) {
                ShowKeyboardMessage(Time.Now, msg, "Key up");
                Console.Beep(360, 30);
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.KEYDOWN, delegate(WindowsMessage key, MessageInfo msg) {
                //ShowKeyboardMessage(Time.Now, msg, "Key down");
                Console.Beep(400, 30);
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.CHAR, delegate(WindowsMessage key, MessageInfo msg) {
                ShowKeyboardMessage(Time.Now, msg, "Character");
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.SYSKEYUP, delegate(WindowsMessage key, MessageInfo msg) {
                ShowKeyboardMessage(Time.Now, msg, "System key up");
                Console.Beep(200, 20);
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.SYSKEYDOWN, delegate(WindowsMessage key, MessageInfo msg) {
                //ShowKeyboardMessage(Time.Now, msg, "System key down");
                Console.Beep(220, 20);
                return false;
            });
            MessageDispatcher.Add(WindowsMessage.SYSCHAR, delegate(WindowsMessage key, MessageInfo msg) {
                ShowKeyboardMessage(Time.Now, msg, "System character");
                return false;
            });
            WindowsMessage[] mouseMessages = new WindowsMessage[] {
                WindowsMessage.LBUTTONDBLCLK,
                WindowsMessage.LBUTTONDOWN,
                WindowsMessage.LBUTTONUP,
                WindowsMessage.MBUTTONDBLCLK,
                WindowsMessage.MBUTTONDOWN,
                WindowsMessage.MBUTTONUP,
                WindowsMessage.RBUTTONDBLCLK,
                WindowsMessage.RBUTTONDOWN,
                WindowsMessage.RBUTTONUP,
                WindowsMessage.MOUSEHWHEEL,
                WindowsMessage.MOUSELEAVE,
                WindowsMessage.MOUSEHOVER,
                WindowsMessage.NCLBUTTONDBLCLK,
                WindowsMessage.NCLBUTTONDOWN,
                WindowsMessage.NCLBUTTONUP,
                WindowsMessage.NCMOUSELEAVE,
                WindowsMessage.NCMBUTTONDBLCLK,
                WindowsMessage.NCMBUTTONDOWN,
                WindowsMessage.NCMBUTTONUP,
                WindowsMessage.NCRBUTTONDBLCLK,
                WindowsMessage.NCRBUTTONDOWN,
                WindowsMessage.NCRBUTTONUP,
            };
            foreach (WindowsMessage wm in mouseMessages)
                MessageDispatcher.Add(wm, delegate(WindowsMessage key, MessageInfo msg) {
                    ShowMouseMessage(Time.Now, msg, string.Empty);
                    return false;
                });
        } //Setup

        protected override void DefWndProc(ref Message m) {
            bool ignore;
            if (MessageDispatcher.TryInvoke((WindowsMessage)m.Msg, MessageInfo.FromMessage(m), out ignore)) {
                if (!ignore)
                    base.DefWndProc(ref m);
            } else
                base.DefWndProc(ref m);
        } //DefWndProc

        static int activateCount = 0;
        static int focusCount = 0;
        static int nonClientActivateCount = 0;
        MessageDispatcher MessageDispatcher = new MessageDispatcher();

    } //class FormMessageHandler

} //namespace TestMessageDispatching
