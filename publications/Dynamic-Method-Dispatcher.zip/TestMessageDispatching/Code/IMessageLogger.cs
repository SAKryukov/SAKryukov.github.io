﻿/*  
    DynamicMethodDispatcher and MuticastDynamicMethodDispatcher classes:
    Generic class DynamicMethodDispatcher dispatches a call to a generic delegate isntance found by a dictionary key
    Generic class MuticastDynamicMethodDispatcher is a multi-case version of DynamicMethodDispatcher.
   
    Test/Demo Application: System.Windows.Forms, Windows
    
    Copyright (C) 2006-2011 by Sergey A Kryukov
    http://www.SAKryukov.org
*/
namespace TestMessageDispatching {
    using Time = System.DateTime;

    interface IMessageLogger {
        void ShowMessage(Time time, MessageInfo info, string customData);
        void ShowKeyboardMessage(Time time, MessageInfo info, string customData);
        void ShowMouseMessage(Time time, MessageInfo info, string customData);
        void ShowStatusMessage(Time time, MessageInfo info, string statusInfo, string customData);
    } //IMessageLogger

} //namespace TestMessageDispatching
