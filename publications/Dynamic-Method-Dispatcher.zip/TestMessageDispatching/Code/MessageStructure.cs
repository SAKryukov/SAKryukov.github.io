﻿/*  
    DynamicMethodDispatcher and MuticastDynamicMethodDispatcher classes:
    Generic class DynamicMethodDispatcher dispatches a call to a generic delegate isntance found by a dictionary key
    Generic class MuticastDynamicMethodDispatcher is a multi-case version of DynamicMethodDispatcher.
   
    Test/Demo Application: System.Windows.Forms, Windows
    
    Copyright (C) 2006-2011 by Sergey A Kryukov
    http://www.SAKryukov.org
*/
namespace TestMessageDispatching {
    using System;
    using System.Windows.Forms;
    using System.Runtime.InteropServices;

    internal enum ActivationStatus : int { Inactive = 0, Active = 1, ClickActive = 2, }
    [Flags]
    internal enum MouseVirtualKey : int { None = 0, Control = 8, LeftButton = 1, MiddleButton = 0x10, RightButton = 2, Shift = 4, XButton1 = 0x20, XButton2 = 0x40, }
    [Flags]
    internal enum SystemCommand : int {
        Close = 0xF060, ContextHelp = 0xF180, Default = 0xF160, HotKey = 0xF150,
        HScroll = 0xF080, IsSecure = 1, KeyMenu = 0xF100, Maximize = 0xF030, Minimize = 0xF020,
        MonitorPower = 0xF170, MouseMenu = 0xF090, Move = 0xF010, NextWindow = 0xF040, PreviousWindow = 0xF050,
        Restore = 0xF120, ScreenSave = 0xF140, Size = 0xF000, TaskList = 0xF130, VScroll = 0xF070,
    } //enum SystemCommand
    
    [StructLayout(LayoutKind.Sequential | LayoutKind.Explicit)]
    class MessageInfo{
        internal static MessageInfo FromMessage(Message message) {
            MessageInfo result = new MessageInfo();
            result.HWnd = message.HWnd;
            result.LParam = message.LParam;
            result.Msg = message.Msg;
            result.Result = message.Result;
            result.WParam = message.WParam;
            return result;
        } //MessageInfo
        //common: message ID:
        [FieldOffset(IntSize * 0)]
        internal IntPtr HWnd;
        //LParam group:
        [FieldOffset(IntSize * 1)]
        internal IntPtr LParam;
        [FieldOffset(IntSize * 1)]
        internal UInt16 X;
        [FieldOffset(IntSize * 1 + 2)]
        internal UInt16 Y;
        //Msg:
        [FieldOffset(IntSize * 2)]
        internal int Msg;
        [FieldOffset(IntSize * 2)]
        internal WindowsMessage WindowsMessage;
        //Result group"
        [FieldOffset(IntSize * 3)]
        internal IntPtr Result;
        //WParamGroup:
        [FieldOffset(IntSize * 4)]
        internal IntPtr WParam;
        [FieldOffset(IntSize * 4)]
        internal ActivationStatus ActivationStatus;
        [FieldOffset(IntSize * 4)]
        internal MouseVirtualKey MouseVirtualKey;
        [FieldOffset(IntSize * 4)]
        internal Keys VirtualKey;
        [FieldOffset(IntSize * 4)]
        internal SystemCommand SystemCommand;
        [FieldOffset(IntSize * 4)]
        internal char Character;
        const int IntSize = 8;
    } //MessageInfo

} //namespace TestMessageDispatchingnamespace TestMessageDispatching {
