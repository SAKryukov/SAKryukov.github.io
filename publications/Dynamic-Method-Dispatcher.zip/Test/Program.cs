﻿using System;
using SA.Universal.Technology;
namespace Test {
    using IntStringToIntDispatcher = MuticastDynamicMethodDispatcher<int, string, int>;

    class Program {

        class Queue<ELEMENT> {
            internal void Enqueue(ELEMENT element) {
                lock(SyncObject)
                    Implementation.Enqueue(element);
            }
            internal ELEMENT Dequeue() {
                lock (SyncObject)
                    return Implementation.Dequeue();
            }
            System.Collections.Generic.Queue<ELEMENT> Implementation =
                new System.Collections.Generic.Queue<ELEMENT>();
            object SyncObject = new object();
        }

        delegate int TestDelegate(string name);
        delegate string FormatEqual(bool value);

        static void ReportDelegateEquivalence(Delegate left, Delegate right) {
            FormatEqual formatEqual = delegate(bool value) { if (value) return string.Empty; else return "NOT"; };
            System.Console.WriteLine(
                "Delegates are {0} equal, they are referentually {1} equal",
                formatEqual(left == right),
                formatEqual(object.ReferenceEquals(left, right)));
        } //ReportDelegateEquivalence

        static void TestDelegateEquivalence() {
            TestDelegate delegate1 = delegate(string name) { return 1; };
            TestDelegate delegate2 = delegate(string name) { return 1; };
            //output: "Delegates are NOT equal, they are referentually NOT equal":
           ReportDelegateEquivalence(delegate1, delegate2);
            
            delegate1 = delegate2;
            //output: "Delegates are equal, they are referentually equal":
            ReportDelegateEquivalence(delegate1, delegate2);
          
            delegate2 += delegate(string name) { return 2; };
            //output: "Delegates are NOT equal, they are referentually NOT equal":            
            ReportDelegateEquivalence(delegate1, delegate2);
        } //TestDelegateEquivalence

        static void ExamineType() {
            TestDelegate someDelegate = delegate(string name) { return 1; };
            System.Type type = someDelegate.GetType();
            bool aclass = type.IsClass;
        } //ExamineType

        void AccumulatedInvoke() {
            var dispatcher = new MuticastDynamicMethodDispatcher<int, string, double>();
            dispatcher.Add(3, (key, value) => { return key; });
            dispatcher.Add(3, (key, value) => { return System.Math.Pow(key, System.Math.PI); });
            dispatcher.Add(3, (key, value) => { return double.Parse(value); });
            dispatcher.Add(5, (key, value) => { return 1d; });
            dispatcher.Add(5, (key, value) => { System.Console.WriteLine(key); return key; });
            dispatcher.Invoke(
                3, "11.2",
                delegate(
                    int index,
                    int key, string message,
                    bool lastResultAvailable, double lastResult, double currentResult) {
                        if (lastResultAvailable) return currentResult;
                        else return lastResult * currentResult;
                });
        } //AccumulatedInvoke
        void AccumulatedInvokeV2() {
            MuticastDynamicMethodDispatcher<int, string, double> dispatcher =
                new MuticastDynamicMethodDispatcher<int, string, double>();
            dispatcher.Add(3, delegate (int key, string value) { return key; });
            dispatcher.Add(3, delegate(int key, string value) { return System.Math.Pow(key, System.Math.PI); });
            //...
            dispatcher.Invoke(
                3, "11.2",
                delegate(
                    int index,
                    int key, string message,
                    bool lastResultAvailable, double lastResult, double currentResult) {
                    if (lastResultAvailable) return currentResult;
                    else return lastResult * currentResult;
                });
        } //AccumulatedInvoke

        #region CAD models:
        public class AcadPrimitive { /* ... */ }
        public class AcadPolyLine2D : AcadPrimitive { /* ... */ }
        public class AcadPolyLine3D : AcadPrimitive { /* ... */ }
        public class AcadCircle : AcadPrimitive { /* ... */ }
        public class AcadArc : AcadPrimitive { /* ... */ }
        public class AcadText : AcadPrimitive { /* ... */ }
        public class AcadMultilineText : AcadPrimitive { /* ... */ }

        public abstract class Shape { /* ... */ }
        public class PolyLine2D : Shape { /* ... */ }
        public class PolyLine3D : Shape { /* ... */ }
        public class Ellipse : Shape { /* ... */ }
        public class EllipticArc : Shape { /* ... */ }
        public class Text : Shape { /* ... */ }

        //...
        #endregion CAD models:

        public interface IModelTranslator { /* ... */ }

        public class DwgModelTranslator :
            DynamicMethodDispatcher<System.Type, AcadPrimitive, Shape>,
            IModelTranslator {

            public DwgModelTranslator() {
                Add(typeof(AcadPolyLine2D), PolyLine2D);
                Add(typeof(AcadPolyLine3D), PolyLine3D);
                Add(typeof(AcadCircle), PolyLine3D);
                Add(typeof(AcadArc), PolyLine3D);
                Add(typeof(AcadText), Text);
                Add(typeof(AcadMultilineText), Text);
                //...
            } //DwgModelTranslator

            Shape PolyLine2D(System.Type acadType, AcadPrimitive acadPrimitive) {
                return new PolyLine2D(/* ... */);
            } //PolyLine2D
            PolyLine3D PolyLine3D(System.Type acadType, AcadPrimitive acadPrimitive) {
                return new PolyLine3D(/* ... */);
            } //PolyLine3D
            Shape Circle(System.Type acadType, AcadPrimitive acadPrimitive) {
                return new Ellipse(/* ... */);
            } //Circle
            EllipticArc Arc(System.Type acadType, AcadPrimitive acadPrimitive) {
                return new EllipticArc(/* ... */);
            } //Arc
            Shape Text(System.Type acadType, AcadPrimitive acadPrimitive) {
                return new Text(/* ... */);
            } //Text

            //...

            //to be used to implement IModelTranslator.Translate (not shown)
            Shape TranslatePrimitive(AcadPrimitive primitive) {
                return this.Invoke(primitive.GetType(), primitive);
            } //TranslatePrimitive

            //...

        } //class DwgModelTranslator

        static void Main(string[] args) {
            TestDelegateEquivalence();
            ExamineType();
            var disp = new MuticastDynamicMethodDispatcher<int, string, int>();
            disp.Add(3, (key, value) => { return key; });
            disp.Add(3, (key, value) => { return key + 1; });
            disp.Add(4, (key, value) => { return key + 10; });
            disp.Add(4, delegate(int key, string value) { return 9; });
            disp.Add(4, (key, value) => { return key + 10; });
            disp.Add(5, HandlerOf4_and_6);
            disp.Add(6, HandlerOf4_and_6);
            var result1 = disp.Invoke(3, "lala");
            var result2 = disp.Invoke(114, "accumulate",
                delegate(
                     int index,
                     int key, string message,
                     bool lastResultAvailable, int lastResult, int currentResult) {
                         if (lastResultAvailable) return currentResult;
                         else return lastResult + currentResult;
                });
        } //Main

        static int HandlerOf4_and_6(int key, string value) { return key * value.Length; }

    } //class Program

} //namespace Test
