﻿/*  
    Power Over IP: Testing of the First Experimental Facility ;-)
 
    Copyright (C) 2013, April 1, by Sergey A Kryukov
    http://www.SAKryukov.org
*/

namespace PoIPClient.Application {
    using System;
    using System.Windows;
    using System.Reflection;
    using StringList = System.Collections.Generic.List<string>;
    using IStringList = System.Collections.Generic.IList<string>;
    using StringBuilder = System.Text.StringBuilder;

    class PoIPApplication : Application {

        protected override void OnStartup(StartupEventArgs e) {
            MainWindow = new MainWindow();
            MainWindow.Show();
            startupComplete = true;
        } //OnStartup

        [STAThread]
        static void Main() {
            Application app = new PoIPApplication();
            app.Run();
        } //Main

        internal PoIPApplication() {
            DispatcherUnhandledException += (sender, eventArgs) => {
                eventArgs.Handled = true;
                HandleException(eventArgs.Exception);
            }; //Application.PoIPApplication.Current.DispatcherUnhandledException
        } //PoIPApplication

        void HandleException(Exception e) {
            Func<Exception, string> exceptionTextFinder = (ex) => {
                Action<Exception, IStringList> exceptionTextCollector = null; // for recursiveness
                exceptionTextCollector = (exc, aList) => {
                    aList.Add(string.Format("{0}:\n{1}", exc.GetType().Name, exc.Message));
                    if (exc.InnerException != null)
                        exceptionTextCollector(exc.InnerException, aList);
                }; //exceptionTextCollector
                IStringList list = new StringList();
                exceptionTextCollector(ex, list);
                StringBuilder sb = new StringBuilder();
                bool first = true;
                foreach (string item in list)
                    if (first) {
                        sb.Append(item);
                        first = false;
                    } else
                        sb.Append("\n\n" + item);
                return sb.ToString();
            };
            MessageBox.Show(
                exceptionTextFinder(e),
                PoIPApplication.Current.ProductName,
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            if (!startupComplete)
                Shutdown();
        } //HandleException
        bool startupComplete;

        internal static new PoIPApplication Current { get { return (PoIPApplication)Application.Current; } }

        internal string ProductName {
            get {
                if (productName == null) {
                    object[] attributes = TheAssembly.GetCustomAttributes(typeof(AssemblyProductAttribute), false);
                    if (attributes == null) return null;
                    if (attributes.Length < 1) return null;
                    productName = ((AssemblyProductAttribute)attributes[0]).Product;
                } //if
                return productName;
            } //get ProductName
        } //ProductName

        Assembly TheAssembly {
            get {
                if (assembly == null)
                    assembly = Assembly.GetEntryAssembly();
                return assembly;
            }
        } //TheAssembly

        Assembly assembly;
        string productName;

    } //class PoIPApplication

} //namespace PoIPClient.Application
