﻿/*  
    Power Over IP: Testing of the First Experimental Facility ;-)
 
    Copyright (C) 2013, April 1, by Sergey A Kryukov
    http://www.SAKryukov.org
*/

namespace PoIPClient {
    using System;
    using System.ServiceModel;

    public class PowerConsumptionSpecification {
        public PowerConsumptionSpecification(float averageLevel, float rf) {
            this.AverageLevel = averageLevel;
            this.DoubleAverageLevel = double.NaN;
            this.RadioFrequency = rf;
            this.DoubleAverageLevel = double.PositiveInfinity;
        } //PowerConsumptionSpecification
        public PowerConsumptionSpecification(double averageLevel, double rf) {
            this.DoubleAverageLevel = averageLevel;
            this.AverageLevel = float.NegativeInfinity;
            this.DoubleRadioFrequency = rf;
            this.AverageLevel = float.NaN;
        } //PowerConsumptionSpecification
        public PowerConsumptionSpecification(float averageLevel) {
            this.AverageLevel = averageLevel;
            this.DoubleAverageLevel = double.NaN;
            this.RadioFrequency = float.NegativeInfinity;
            this.DoubleAverageLevel = double.PositiveInfinity;
        } //PowerConsumptionSpecification
        public PowerConsumptionSpecification(double averageLevel) {
            this.DoubleAverageLevel = averageLevel;
            this.AverageLevel = float.NegativeInfinity;
            this.DoubleRadioFrequency = double.NaN;
            this.AverageLevel = float.NaN;
        } //PowerConsumptionSpecification
        public float AverageLevel { get; private set; }
        public double DoubleAverageLevel { get; private set; }
        public float RadioFrequency { get; private set; }
        public double DoubleRadioFrequency { get; private set; }
    } //PowerConsumptionSpecification

    public class PowerSlice : PowerConsumptionSpecification {
        public PowerSlice(float averageLevel, TimeSpan duration, float rf) : base(averageLevel, rf) { this.Duration = duration; }
        public PowerSlice(double averageLevel, TimeSpan duration, double rf) : base(averageLevel, rf) { this.Duration = duration; }
        public PowerSlice(float averageLevel, TimeSpan duration) : base(averageLevel) { this.Duration = duration; }
        public PowerSlice(double averageLevel, TimeSpan duration) : base(averageLevel) { this.Duration = duration; }
        public TimeSpan Duration { get; private set; }
    } //class PowerSlice

    public enum PowerStatus {
        Listening, Powered, TerminationWarned, Expired,
        PowerPlantMulfunction, PowerPlantDestruction, GovernmentShutdown,
        Disconnected, }

    public interface IPowerRecipient {
        DateTime? MostRecentRequest { get; }
        TimeSpan? MostRecentRequestDuration { get; }
    } //interface IPowerRecipent

    [ServiceContract(
        Name = "Power Pull",
        Namespace = "http://microsoft.WTF.PoIP",
        CallbackContract = typeof(IPowerDonor),
        SessionMode = SessionMode.NotAllowed)]
    public interface IPowerPullRecepient : IPowerRecipient {
        PowerSlice Request(PowerSlice request); // returns actually provided slice
    } //interface IPowerPullRecepient

    [ServiceContract(
        Name = "Power Push",
        Namespace = "http://microsoft.WTF.PoIP",
        CallbackContract = typeof(IPowerDonor),
        SessionMode = SessionMode.Required)]
    public interface IPowerPushRecepient : IPowerRecipient {
        // duration is not specified; power is supplied when it is possible; 
        // the user gets event notifications throw the callback interface IPowerDonor
        PowerConsumptionSpecification Request(PowerConsumptionSpecification request); // returns actually provided power spec
    } //interface IPowerPushRecepient

    public interface IPowerDonor {
        void PowerSupplyEnded(PowerStatus reason, IPowerRecipient recepient);
        void PowerSupplyTerminationWarning(PowerStatus reason, IPowerRecipient recepient);
    } //interface IPowerDonor

    internal abstract class PowerDonorHandler : IPowerDonor {
        internal PowerDonorHandler() { }
        void IPowerDonor.PowerSupplyTerminationWarning(PowerStatus reason, IPowerRecipient recepient) {
            if (reason == PowerStatus.Expired) {
                RequestMorePower();
                System.Windows.MessageBox.Show("No way! I want more power!");
            } //if
            System.Windows.MessageBox.Show("Save your work or find another energy source");
        } //IPowerDonor.PowerSupplyTerminationWarning
        void IPowerDonor.PowerSupplyEnded(PowerStatus reason, IPowerRecipient recepient) {
            System.Windows.MessageBox.Show("Too late...");
        } //IPowerDonor.PowerSupplyEnded
        protected abstract void RequestMorePower();
    } //class PowerDonorHandler

    internal class PullPowerDonorHandler : PowerDonorHandler, IPowerDonor {
        internal PullPowerDonorHandler(IPowerPullRecepient puller) { this.puller = puller; }
        protected override void RequestMorePower() {
            puller.Request(new PowerSlice(3.14d, new TimeSpan(3, 0, 0))); // just for example: power for 3 hours
        } //RequestMorePower
        IPowerPullRecepient puller;
    } //class PullPowerDonorHandler

    class PullPowerFactory : IPowerPullRecepient { // factory pattern
        PowerSlice IPowerPullRecepient.Request(PowerSlice request) { return request; } // fake implementation, instead of stub
        DateTime? IPowerRecipient.MostRecentRequest { get { return null; } }
        TimeSpan? IPowerRecipient.MostRecentRequestDuration { get { return null; } }
        internal static IPowerPullRecepient GetProxy() { return new PullPowerFactory(); }
    } //class PullPowerFactory

    class Test {
        internal void TestIt() {
            // "PowerFactory" refers to the Factory Method Pattern,
            // not factory producing power, which we call "power plant":
            IPowerPullRecepient recepient = PullPowerFactory.GetProxy();
            PullPowerDonorHandler donorHandler = new PullPowerDonorHandler(recepient);
            // this is a blocking method; if the request cannot be satisfied at all, we get response immediately:
            PowerSlice deliveredPower = recepient.Request(new PowerSlice(2.71d, new TimeSpan(2, 0, 0), 300.13)); //for example
            // now we can assert that we are getting what we requested:
            if (deliveredPower.Duration <= new TimeSpan(0))
                System.Windows.MessageBox.Show("What kind of service is that?");
                // we can also check actual power level and other parameters
            // otherwise we have started to consume power
        }
    } //Test

} //namespace PoIPClient