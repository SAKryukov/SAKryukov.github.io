﻿/*  
    Power Over IP: Testing of the First Experimental Facility ;-)
 
    Copyright (C) 2013, April 1, by Sergey A Kryukov
    http://www.SAKryukov.org
*/

namespace PoIPClient {
    using System.Windows;
    using RequestNavigateEventArgs = System.Windows.Navigation.RequestNavigateEventArgs;
    using Process = System.Diagnostics.Process;

    public partial class MainWindow : Window {
        
        public MainWindow() {
            InitializeComponent();
            this.buttonStart.Click += (sender, eventArgs) => {
                this.buttonStart.Visibility = Visibility.Collapsed;
                this.text.Visibility = Visibility.Visible;
                this.SizeToContent = SizeToContent.WidthAndHeight;
                this.Left = 0;
            }; //buttonStart.Click
        } //MainWindow

        void RequestNavigateHandler(object sender, RequestNavigateEventArgs e) {
            Process.Start(e.Uri.AbsoluteUri);
        } //RequestNavigateHandler

    } //class MainWindow

} //namespace PoIPClient
