﻿namespace SingleInstanceDemoWPF.Ui {
    using System.Windows;
    using System.Windows.Controls;
    using SA.Universal.SingleInstance;
    using System.IO;

    public partial class MainWindow : Window {

        public MainWindow() {
            InitializeComponent();
            textBlock.Text = "Now start the second instance of the same application "
                + "with some command line parameters.\n\n"
                + "In standard interpretation, the parameters should be file names passed "
                + "to the first instance of the application, "
                + "but actually they can be any strings.";
            SingleInstanceManager.FilesLoading += (sender, eventArgs) => {
                Dispatcher.Invoke(new System.Action(() => LoadFilesFromSecondInstance(eventArgs.CommandLine) ));
            }; //SingleInstanceManager.FilesLoading
            SingleInstanceManager.FirstInstanceShowing += (sender, eventArgs) => {
                Dispatcher.Invoke(new System.Action(() => Activate()));
            }; //SingleInstanceManager.FirstInstanceShowing
        } //MainWindow

        void LoadFilesFromSecondInstance(string[] files) {
            textBlock.Visibility = Visibility.Collapsed;
            tabControl.Visibility = Visibility.Visible;
            foreach (string file in files) {
                int index = tabControl.Items.Count;
                if (!File.Exists(file)) continue;
                TabItem page = new TabItem();
                page.Header = index + 1;
                TextBox textBox = new TextBox();
                textBox.TextWrapping = TextWrapping.Wrap;
                textBox.Text = File.ReadAllText(file);
                textBox.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
                page.Content = textBox;
                tabControl.Items.Add(page);
            } //loop
            if (tabControl.Items.Count > 0)
                tabControl.SelectedIndex = tabControl.Items.Count - 1;
        } //LoadFilesFromSecondInstance

    } //class MainWindow

} //namespace SingleInstanceDemoWPF.Ui
