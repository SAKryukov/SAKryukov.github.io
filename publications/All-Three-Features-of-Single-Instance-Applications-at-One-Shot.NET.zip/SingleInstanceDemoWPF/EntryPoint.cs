﻿namespace SingleInstanceDemoWPF {
    using SA.Universal.SingleInstance;

    class Program {

        [System.STAThread]
        static void Main(string[] commandLine) {
            if (SingleInstanceManager.IsSecondInstance) {
                SingleInstanceManager.HandleRemoteCommandLine(commandLine);
                SingleInstanceManager.ActivateFirstInstance();
                return;
            } //if
            new Main.TheApplication().Run();
        } //Main

    } //class Program

} //namespace SingleInstanceDemoWPF
