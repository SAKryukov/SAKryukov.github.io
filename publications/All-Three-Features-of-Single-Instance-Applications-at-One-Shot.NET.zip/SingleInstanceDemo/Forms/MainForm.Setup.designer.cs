﻿namespace SingleInstanceDemo {
    using SA.Universal.SingleInstance;
    using System.Windows.Forms;
    using System.IO;

    public partial class MainForm {

        void Setup() {
            Text = Application.ProductName;
            SingleInstanceManager.FilesLoading += (sender, eventArgs) => {
                Invoke(new System.Action(() => LoadFilesFromSecondInstance(eventArgs.CommandLine) ));
            }; //SingleInstanceManager.FilesLoading
            SingleInstanceManager.FirstInstanceShowing += (sender, eventArgs) => {
                Invoke(new System.Action(() => Activate() ));
            }; //SingleInstanceManager.FirstInstanceShowing
            ShowIntroduction();
        } //Setup

        void ShowIntroduction() {
            tabControl.Visible = false;
            Label label = new Label();
            this.Padding = new Padding(16);
            label.Dock = DockStyle.Fill;
            label.AutoSize = false;
            label.Text = "Now start the second instance of the same application "
                + "with some command line parameters.\n\n"
                + "In standard interpretation, the parameters should be file names passed "
                + "to the first instance of the application, "
                + "but actually they can be any strings.";
            label.Parent = this;
        } //ShowIntroduction

        void LoadFilesFromSecondInstance(string[] files) {
            tabControl.Visible = true;
            this.Padding = new Padding(0);
            foreach (string file in files) {
                int index = tabControl.TabPages.Count;
                if (!File.Exists(file)) continue;
                tabControl.TabPages.Add((index + 1).ToString());
                TextBox tb = new TextBox();
                tb.Dock = DockStyle.Fill;
                tb.WordWrap = true;
                tb.ScrollBars = ScrollBars.Vertical;
                tb.Multiline = true;
                tb.Parent = tabControl.TabPages[index];
                tb.Text = File.ReadAllText(file);
                tb.SelectionStart = 0; tb.SelectionLength = 0;
                tb.Focus();
            } //loop
            tabControl.SelectedIndex = tabControl.TabPages.Count - 1;
        } //LoadFilesFromSecondInstance

    } //class MainForm

} //namespace SingleInstanceDemo
