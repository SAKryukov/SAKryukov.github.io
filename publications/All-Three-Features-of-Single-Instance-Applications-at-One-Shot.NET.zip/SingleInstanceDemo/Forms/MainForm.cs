﻿namespace SingleInstanceDemo {
    using System;
    using System.Windows.Forms;
    using StringList = System.Collections.Generic.List<string>;
    using IStringList = System.Collections.Generic.IList<string>;
    using StringBuilder = System.Text.StringBuilder;

    public partial class MainForm : Form {

        public MainForm() {
            InitializeComponent();
            Text = Application.ProductName;
            Setup();
        } //MainForm

        internal static void ShowException(Exception e) {
            Func<Exception, string> exceptionTextFinder = (ex) => {
                Action<Exception, IStringList> exceptionTextCollector = null; // for recursiveness
                exceptionTextCollector = (exc, aList) => {
                    aList.Add(string.Format(SingleInstanceDemo.Resources.Exceptions.ExceptionFormat, exc.GetType().FullName, exc.Message));
                    if (exc.InnerException != null)
                        exceptionTextCollector(exc.InnerException, aList);
                }; //exceptionTextCollector
                IStringList list = new StringList();
                exceptionTextCollector(ex, list);
                StringBuilder sb = new StringBuilder();
                bool first = true;
                foreach (string item in list)
                    if (first) {
                        sb.Append(item);
                        first = false;
                    } else
                        sb.Append(SingleInstanceDemo.Resources.Exceptions.ExceptionStackItemDemiliter + item);
                return sb.ToString();
            };
            MessageBox.Show(
                exceptionTextFinder(e),
                Application.ProductName,
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        } //ShowException

    } //class MainForm

} //namespace SingleInstanceDemo
