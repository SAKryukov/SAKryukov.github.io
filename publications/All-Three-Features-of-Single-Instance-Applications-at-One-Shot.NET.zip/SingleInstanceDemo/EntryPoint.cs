﻿namespace SingleInstanceDemo {
    using SA.Universal.SingleInstance;
    using System.Windows.Forms;

    static class Program {

        static void Main(string[] commandLine) {
            if (SingleInstanceManager.IsSecondInstance) {
                SingleInstanceManager.HandleRemoteCommandLine(commandLine);
                SingleInstanceManager.ActivateFirstInstance();
                return;
            } //if
            Application.SetCompatibleTextRenderingDefault(false);
            Application.EnableVisualStyles();
            Application.ThreadException += (sender, eventArgs) => { MainForm.ShowException(eventArgs.Exception); };
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.Run(new MainForm());
        } //Main

    } //class Program

} //namespace SingleInstanceDemo
