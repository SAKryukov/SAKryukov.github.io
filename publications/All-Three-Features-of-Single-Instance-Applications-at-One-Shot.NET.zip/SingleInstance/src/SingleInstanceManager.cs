﻿//
// Single-instance application facility
//
// Copyright (c) 2016, Sergey A Kryukov
// http://www.SAKryukov.org
//

namespace SA.Universal.SingleInstance {
    using System;
    using System.Runtime.Remoting;
    using System.Runtime.Remoting.Channels;
    using System.Runtime.Remoting.Channels.Ipc;

    public class CommandLineEventArgs : EventArgs {
        internal CommandLineEventArgs(string[] commandLine) { this.CommandLine = commandLine; }
        public string[] CommandLine { get; private set; }
    } //class CommandLineEventArgs

    public static class SingleInstanceManager {
        
        // customization part:
        public static event System.EventHandler<CommandLineEventArgs> FilesLoading;
        public static event System.EventHandler FirstInstanceShowing;

        // needed by both instances:
        public static bool IsSecondInstance {
            get {
                bool secondInstance = DetectSingleInstance();
                if (!secondInstance)
                    RegisterServerObject();
                return secondInstance;
            } //get IsSecondInstance
        } //IsSecondInstance

        // to be called by second instance, handled by first instance:
        public static void HandleRemoteCommandLine(string[] files) {
            if (RemoteFileLoader != null)
                RemoteFileLoader.HandleCommandLine(files);
        } //HandleRemoteCommandLine
        public static void ActivateFirstInstance() {
            if (RemoteFileLoader != null)
                RemoteFileLoader.ActivateFirstInstance();
        } //ActivateFirstInstance

        #region implementation

        static bool DetectSingleInstance() {
            try {
                var channel = new IpcClientChannel();
                ChannelServices.RegisterChannel(channel, false);
                RemoteFileLoader = (IRemoteFileLoader)Activator.GetObject(
                        typeof(Server),
                        RemoteObjectUrl);
                RemoteFileLoader.TestInterface();
            } catch { RemoteFileLoader = null; return false; }
            return RemoteFileLoader != null;
        } //DetectSingleInstance

        static void RegisterServerObject() {
            var channel = new IpcServerChannel(ChannelName);
            ChannelServices.RegisterChannel(channel, false);
            Server proxy = new Server();
            proxy.CommandLineHandling += (sender, eventArgs) => {
                if (FilesLoading != null)
                    FilesLoading.Invoke(proxy, eventArgs);
            }; //proxy.FilesLoading
            proxy.FirstInstanceActivating += (sender, eventArgs) => {
                if (FirstInstanceShowing != null)
                    FirstInstanceShowing.Invoke(proxy, eventArgs);
            }; //proxy.FirstIndexShowing
            RemotingServices.Marshal(proxy, ProxyObjectName);
        } //RegisterServerObject

        static string ChannelName {
            get {
                return System.Reflection.Assembly.GetEntryAssembly()
                    .Location;//.Replace(
                    //    System.IO.Path.DirectorySeparatorChar,
                    //    System.IO.Path.PathSeparator);
            } //ChannelName
        } //ChannelName
        static string ProxyObjectName {
            get {
                if (proxyObjectName == null)
                    proxyObjectName = typeof(Server).Name;
                return proxyObjectName; // can really be any name
            } //get ProxyObjectName
        } //ProxiObjectName
        static string proxyObjectName;
        static string RemoteObjectUrl {
            get {
                Func<string> getUriPathDelimiter = () => {
                    Uri uri = new Uri(Uri.UriSchemeFile + Uri.SchemeDelimiter + ProxyObjectName);
                    return uri.AbsolutePath;
                }; //getUriPathDelimiter
                string scheme = new IpcChannel().ChannelName;
                System.Text.StringBuilder sb = new System.Text.StringBuilder(scheme);
                sb.Append(Uri.SchemeDelimiter);
                sb.Append(ChannelName);
                sb.Append(getUriPathDelimiter());
                sb.Append(ProxyObjectName);
                return sb.ToString();
            } //get RemoteObjectUrl
        } //RemoteObjectUrl

        static IRemoteFileLoader RemoteFileLoader;

        #endregion implementation

    } //class SingleInstanceManager

} //namespace SA.Universal.SingleInstance
