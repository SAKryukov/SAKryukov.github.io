﻿//
// Single-instance application facility
//
// Copyright (c) 2016, Sergey A Kryukov
// http://www.SAKryukov.org
//

namespace SA.Universal.SingleInstance {

    interface IRemoteFileLoader {
        void HandleCommandLine(string[] commandLine);
        void ActivateFirstInstance();
        void TestInterface();
    } //interface IRemoteFileLoader

} //namespace SA.Universal.SingleInstance
