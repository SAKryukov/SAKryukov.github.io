﻿//
// Single-instance application facility
//
// Copyright (c) 2016, Sergey A Kryukov
// http://www.SAKryukov.org
//

namespace SA.Universal.SingleInstance {
    using System;

    internal class Server : System.MarshalByRefObject, IRemoteFileLoader {

        internal event System.EventHandler<CommandLineEventArgs> CommandLineHandling;
        internal event System.EventHandler FirstInstanceActivating;

        #region IRemoteFileLoader implementation

        void IRemoteFileLoader.TestInterface() { }

        void IRemoteFileLoader.HandleCommandLine(string[] commandLine) {
            if (CommandLineHandling != null)
                CommandLineHandling.Invoke(this, new CommandLineEventArgs(commandLine));
        } //IRemoteFileLoader.HandleCommandLine

        void IRemoteFileLoader.ActivateFirstInstance() {
            if (FirstInstanceActivating != null)
                FirstInstanceActivating.Invoke(this, new EventArgs());
        } //IRemoteFileLoader.ActivateFirstInstance

        #endregion IRemoteFileLoader implementation

        public override object InitializeLifetimeService() { return null; } //to keep it alive by ignoring life time lease policy

    } //class Server

} //namespace SA.Universal.SingleInstance
