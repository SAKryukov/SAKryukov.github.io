/* 
    Enumeration classes:
    Generic class Enumeration provides iteration capabilities based on enumeration or any other type with static fields;
    Generic class EnumerationIndexedArray implements enumeration-indexed arrays
    Generic class CartesianSquareIndexedArray implements indexed arrays indexed by a Cartesian Square based on an enumeration
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org
*/

namespace SA.Universal.Enumerations {
    using Cardinal = System.UInt32;
    using AbbreviationLength = System.Byte;
    using Debug = System.Diagnostics.Debug;
    /// <summary>
    /// EnumerationItem play the same role in <seealso cref="Enumeration">Enumeration</seealso> class as enum members do in their parent enum types.
    /// EnumerationItem provides more comprehensive information and resolves the situation when different enum members have same integer values.
    /// </summary>
    /// <typeparam name="ENUM">Any type; however, only the set of the public static fields of the type are essential</typeparam>
    public sealed class EnumerationItem<ENUM> {
        
        private EnumerationItem() { }

        internal EnumerationItem(string name, AbbreviationLength abbreviationLength, string displayName, string description, Cardinal index, object value, ENUM enumValue) {
            this.FName = name;
            this.FDescription = description;
            this.FDisplayName = displayName;
            if (string.IsNullOrEmpty(this.FDisplayName))
                this.FDisplayName = name;
            this.FIndex = index;
            this.FValue = value;
            this.FEnumValue = enumValue;
            this.AbbreviationLength = abbreviationLength;
            Debug.Assert(AbbreviationLength > 0, "Abbreviation Length must be greater than zero");
            if (this.AbbreviationLength < 1)
                this.AbbreviationLength = 1;
        } //EnumerationItem

        /// <summary>
        /// Name of the static field representing enumeration item.
        /// </summary>
        public string Name { get { return FName; } }

        /// <summary>
        /// Abbreviated name of the static field representing enumeration item; abbreviation is defined by the AbbreviationAttribute
        /// </summary>
        public string AbbreviatedName {
            get {
                if (FAbbreviatedName == null) //lazy
                    FAbbreviatedName = GetAbbreviatedName();
                return FAbbreviatedName;
            } //get AbbreviatedName
        } //AbbreviatedName

        /// <summary>
        /// Name of the item based on DisplayNameAttribute;
        /// the purpose of this member is to provide human-readable name for an item;
        /// it the attribute is not available or does not resolve the name, default value is used: DisplayName = Name 
        /// </summary>
        public string DisplayName { get { return FDisplayName; } }

        /// <summary>
        /// Description of the item based on DescriptionAttribute;
        /// it the attribute is not available or does not resolve the name, default value is used: Description = null
        /// </summary>
        public string Description { get { return FDescription; } }

        /// <summary>
        /// Index of a static field corresponding to present instance of EnumerationItem in the order it appears in the declaration
        /// </summary>
        public Cardinal Index { get { return FIndex; } }
        
        /// <summary>
        /// Value of the static field representing enumeration member.
        /// If ENUM is not an enumeration type, the type of a static field corresponding to present instance of EnumerationItem may be of the type other then ENUN;
        /// in this case EnumValue is assigned to default(ENUM).
        /// </summary>
        public ENUM EnumValue { get { return FEnumValue; } }

        /// <summary>
        /// Value of a static field corresponding to present instance of EnumerationItem.
        /// The type of Value is always ENUM if ENUM is enumeration type, otherwise it can be of any type.
        /// </summary>
        public object Value { get { return FValue; } }

        #region implementation

        string GetAbbreviatedName() {
            int len = FName.Length;
            if (AbbreviationLength >= len)
                return FName;
            else
                return FName.Substring(0, AbbreviationLength);
        } //GetAbbreviatedName
        Cardinal FIndex;
        string FName, FAbbreviatedName, FDisplayName, FDescription;
        AbbreviationLength AbbreviationLength;
        ENUM FEnumValue;
        object FValue;
        #endregion implementation

    } //struct EnumerationItem

} //namespace SA.Universal.Enumerations