﻿/* 
    Command Line Utility:
    
    CommandLine is based on Enumeration and EnumerationIndexedArray
    To define command line options, define enumerations for switches and values and instantiate CommandLine.
    These enumeration types are typically enum, but any other type with static constant fields of the same type will work, such as int, double, etc.,
    because the role of enum members will be played by MinValue, MaxValue, etc.
    
    Command line options take the form:
    
    Switches:
    -key -key+ -key- /key /key+ /key-
    a switch can have CommandLineSwitchStatus obtained from GetSwitch: Absent, Present (no plus or minus at the end), Plus or Minus.
    Simplified API this[<SWITCH ENUM>] returns boolean (true if Present or Plus).
  
    Values:
    -key:value /key:value
    a value is a string obtained from this[<VALUE ENUM>]; no requirements are imposed on the values; they can be empty of contain prefixes/delimiters.
    if a -key:value option is missing, the value is null, if it is present in form -key: or /key: the value is empty string.
 
    All other command line options are called "files"; no requirements are imposed on their values except being unique.
  
    All the keys and "files" must be unique, taking into account case sensitivity separate for keys, files and abbreviated keys (see CommandLineParsingOptions).
    Keys of switches, keys of values and "files" are separate sets of options; the unuqiueness is only required withing the set.
    For example, the command line "-file -file:input.txt input.txt file" is completely valid; no options are ignored.
    If a key (of a switch or value type regardless of its status or value) or a "file" is repeated, the first occurence takes precedence
    with all other occurences dubbed "repeated".
    Keys can be abbreviated in their enumeration types using AbbreviationAttribute or ignored using NonEnumerableAttribute.
    A full key always takes precedence over abbreviated: if both full and abbreviated keys present, the abbreviated one is dubbed "repeated".
  
    All user's command line errors are collected in UnrecognizedOptions, RepeatedFiles, RepeatedSwitches and RepeatedValues; no exceptions are thrown.
    
    Copyright (C) 2004-2010 by Sergey A Kryukov
    http://www.SAKryukov.org
*/

namespace SA.Universal.Utilities {
    using System;
    using System.Globalization;
    using System.Collections.Generic;
    using StringList = System.Collections.Generic.List<string>;
    using StringDictionary = System.Collections.Generic.Dictionary<string, string>;
    using DefinitionSet = Universal.Utilities.CommandLineParserDefinitionSet;
    using SA.Universal.Enumerations;
#if DEBUG
    using Debug = System.Diagnostics.Debug;
#endif

    /// <summary>
    /// Command Line Parser controlled by enumeration declarations
    /// </summary>
    /// <typeparam name="SWITCHES">Enumeration type defining switch options using syntax -|/option[-|+]</typeparam>
    /// <typeparam name="VALUES">Enumeration type defining value options using syntax -|/option:[value]</typeparam>
    public sealed class CommandLine<SWITCHES, VALUES> {

        /// <summary>
        /// There is no need to use to use this structure directly, whatsoever;
        /// instead, assign <seealso cref="CommandLine"/> index property indexed by SWITCHES to boolean or <seealso cref="CommandLineSwitchStatus"/> variable;
        /// CommandLineSwitchStatusWrapper uses implicit type conversion operator to convert to any of those types;
        /// converted boolean value retuns True if status is <seealso cref="CommandLineSwitchStatus.Plus"/> or <seealso cref="CommandLineSwitchStatus.Present"/>.
        /// </summary>
        public struct CommandLineSwitchStatusWrapper {
            public static implicit operator CommandLineSwitchStatus(CommandLineSwitchStatusWrapper wrapper) { return wrapper.FStatus; }
            public static implicit operator bool(CommandLineSwitchStatusWrapper wrapper) { return wrapper.FStatus == CommandLineSwitchStatus.Plus || wrapper.FStatus == CommandLineSwitchStatus.Present; }
            internal CommandLineSwitchStatusWrapper(CommandLineSwitchStatus status) { this.FStatus = status; }
            CommandLineSwitchStatus FStatus;
        } //struct CommandLineSwitchStatusWrapper
        
        /// <summary>
        /// This constructor without parameters extracts command line strings from System.Environment using default options
        /// (default depends on run-time platform, see <seealso cref="CommandLineParsingOptions"/>)
        /// </summary>
        public CommandLine() { Construct(ExtractCommandLine()); }
        
        /// <summary>
        /// This constructor extracts command line strings from System.Environment
        /// </summary>
        /// <param name="options">Command line options</param>
        public CommandLine(CommandLineParsingOptions options) { Construct(ExtractCommandLine(), options); }

        /// <summary>
        /// This constructor gets command line strings from parameter and uses default options
        /// (default depends on run-time platform, see <seealso cref="CommandLineParsingOptions"/>)
        /// </summary>
        /// <param name="commandLine">Command line</param>
        public CommandLine(string[] commandLine) { Construct(commandLine); }

        /// <summary>
        /// This constructor gets command line strings and options from parameters
        /// </summary>
        /// <param name="commandLine">Command line</param>
        /// <param name="options">Command line options</param>
        public CommandLine(string[] commandLine, CommandLineParsingOptions options) { Construct(commandLine, options); }

        /// <summary>
        /// Property indexed by VALUES key returns a value associated with the option
        /// </summary>
        /// <param name="key">Index of the type VALUES</param>
        /// <returns>Value associated with the generic-parameter option</returns>
        public string this[VALUES key] { get { return Values[key]; } }

        /// <summary>
        /// Property indexed by SWITCHES key returns either switch status or boolean value,
        /// using <seealso cref="CommandLineSwitchStatusWrapper"/> and its implicit convertions to <seealso cref="CommandLineSwitchStatus"/> or boolean;
        /// converted boolean value retuns True if status is <seealso cref="CommandLineSwitchStatus.Plus"/> or <seealso cref="CommandLineSwitchStatus.Present"/>.
        /// </summary>
        /// <param name="index">Index of the generic-parameter type SWITCHES</param>
        /// <returns>either switch status or boolean value</returns>
        public CommandLineSwitchStatusWrapper this[SWITCHES index] { get { return new CommandLineSwitchStatusWrapper(Switches[index]); } }
        
        /// <summary>
        /// Array of string property returns all the command line parameters without "-" or "/" key;
        /// they are called files because most typical application for this feature is a set of file names.
        /// </summary>
        public string[] Files { get { return FFiles; } }

        /// <summary>
        /// Enumeration property returns Enumeration indexed generic-parameter type SWITCHES
        /// </summary>
        public Enumeration<SWITCHES> SwitchEnumeration { get { return FSwitchEnumeration; } }

        /// <summary>
        /// Enumeration property returns Enumeration indexed generic-parameter type VALUES
        /// </summary>
        public Enumeration<VALUES> ValueEnumeration { get { return FValueEnumeration; } }
        
        /// <summary>
        /// Array of string property returns the set of all ill-formatted command line options
        /// </summary>
        public string[] UnrecognizedOptions { get { return FUnrecognizedOptions; } }

        /// <summary>
        /// Array of string property returns the set of all duplicate command line options without "-" or "/" key
        /// </summary>
        public string[] RepeatedFiles { get { return FRepeatedFiles; } }

        /// <summary>
        /// Array of string property returns the set of all duplicate switch-like options (formatted as -|/option[-|+])
        /// </summary>
        public string[] RepeatedSwitches { get { return FRepeatedSwitches; } }

        /// <summary>
        /// Array of string property returns the set of all duplicate value-like options (formatted as -|/option:[value])
        /// </summary>
        public string[] RepeatedValues { get { return FRepeatedValues; } }

        /// <summary>
        /// Current Command Line Parsing Options
        /// </summary>
        public CommandLineParsingOptions CommandLineParsingOptions { get { return Options; } }

        /// <summary>
        /// Default Command Line Parsing Options for current platform
        /// </summary>
        public static CommandLineParsingOptions DefaultCommandLineParsingOptions { get { return GetDefaultCommandLineParsingOptions(); } }

        #region implementation

        void Construct(string[] commandLine, CommandLineParsingOptions options)  {
            this.Options = options;
#if DEBUG
            ValidateEnumerations();
#endif
            ParseCommandLine(commandLine);
        } //Construct
        void Construct(string[] commandLine) {
            CommandLineParsingOptions defaultCase = GetDefaultCommandLineParsingOptions();
            Construct(commandLine, defaultCase);
        } //Construct

        static CommandLineParsingOptions GetDefaultCommandLineParsingOptions() {
            switch (System.Environment.OSVersion.Platform) {
                case PlatformID.Win32NT:
                case PlatformID.Win32S:
                case PlatformID.Win32Windows:
#if ABOVE_2_0
                case PlatformID.WinCE:
#endif
                case PlatformID.Xbox:
                    return CommandLineParsingOptions.DefaultMicrosoft;
                default: //in this way, if Microsoft later recognized yet another platform and adds it to this enumeration type, it will still compile and fall into Unix category:
                    return CommandLineParsingOptions.DefaulUnix;
            } //switch
        } //GetDefaultCommandLineParsingOptions

        string[] ExtractCommandLine() {
            string[] commandLine = System.Environment.GetCommandLineArgs();
            int len = commandLine.Length;
            if (len < 2) return new string[0];
            string[] destination = new string[len - 1];
            Array.Copy(commandLine, 1, destination, 0, len - 1);
            return destination;
        } //ExtractCommandLine

        bool ParseTerm(string term, out bool isFile, out string key, out CommandLineSwitchStatus status, out string value) {
            value = null;
            key = null;
            status = CommandLineSwitchStatus.Present;
            string keyedValue = ExtractPrefix(term);            
            isFile = keyedValue == null;
            if (keyedValue == null) {
                isFile = true;
                value = term;
                return true;
            } else if (keyedValue.Length < 1)
                return false;
            string[] keyValuePair = keyedValue.Split(new char[] { DefinitionSet.KeyValueDelimiter }, 2);
            if (keyValuePair.Length == 1) {
                key = keyValuePair[0];
                int len = key.Length;
                if (key.Length > 1) {
                    char last = key[len - 1];
                    if (last == DefinitionSet.OptionOff) status = CommandLineSwitchStatus.Minus;
                    else if (last == DefinitionSet.OptionOn) status = CommandLineSwitchStatus.Plus;
                    else status = CommandLineSwitchStatus.Present;
                    if (status != CommandLineSwitchStatus.Present) {
                        key = key.Substring(0, len - 1);
                        if (key.Contains(string.Empty + DefinitionSet.OptionOff) || key.Contains(string.Empty + DefinitionSet.OptionOn))
                            return false;
                    } //if
                } else {
                    if (key[0] == DefinitionSet.OptionOff || key[0] == DefinitionSet.OptionOn) return false;
                } //if
            } else if (keyValuePair.Length == 2) {
                key = keyValuePair[0];
                value = keyValuePair[1];
            } else
                return false;
            if (key != null && ((Options & CommandLineParsingOptions.CaseSensitiveKeys) == 0))
                key = key.ToLower();
            return true;
        } //ParseTerm

        static string ExtractPrefix(string value) {
            if (string.IsNullOrEmpty(value)) return null; // this is pathological case if command line contains ""
            bool found = false;
            foreach (char prefix in DefinitionSet.Prefixes) {
                found = value[0] == prefix;
                if (found) break;
            } //loop
            if (!found) return null;
            return value.Substring(1, value.Length - 1);
        } //ExtractPrefix

        void ParseCommandLine(string[] terms) {
            StringDictionary fileDictionary = new StringDictionary();
            StringList fileList = new StringList();
            StringList unrecognizedList = new StringList();
            StringList repeatedFileList = new StringList();
            StringList repeatedSwitches = new StringList();
            StringList repeatedValues = new StringList();
            Dictionary<string, SwitchDictionaryValue> switchDictionary = new Dictionary<string, SwitchDictionaryValue>();
            Dictionary<string, ValueDictionaryValue> valueDictionary = new Dictionary<string, ValueDictionaryValue>();
            foreach (string term in terms) {
                bool isFile;
                string value;
                CommandLineSwitchStatus status;
                string key;
                if (ParseTerm(term, out isFile, out key, out status, out value)) {
                    if (isFile) { //file
                        if (value != null && ((Options & CommandLineParsingOptions.CaseSensitiveFiles) == 0))
                            value = value.ToLower();
                        if (!fileDictionary.ContainsKey(value)) {
                            fileDictionary.Add(value, term);
                            fileList.Add(term);
                        } else
                            repeatedFileList.Add(term);
                    } else if (value == null) { //switch
                        if (!switchDictionary.ContainsKey(key))
                            switchDictionary.Add(key, new SwitchDictionaryValue(status, term));
                        else
                            repeatedSwitches.Add(term);
                    } else { //value
                        if (!valueDictionary.ContainsKey(key))
                            valueDictionary.Add(key, new ValueDictionaryValue(value, term));
                        else
                            repeatedValues.Add(term);
                    } //end if switch
                } else
                    unrecognizedList.Add(term);
            } //loop
            List<EnumerationItem<SWITCHES>> switchKeyList = new List<EnumerationItem<SWITCHES>>();
            List<EnumerationItem<VALUES>> valueKeyList = new List<EnumerationItem<VALUES>>();
            foreach (EnumerationItem<SWITCHES> enumerationItem in FSwitchEnumeration) {
                switchKeyList.Add(enumerationItem);
                string key, abbreviatedKey;
                PrepareKeys(enumerationItem, out key, out abbreviatedKey);
                ProcessDictionary(switchDictionary, enumerationItem, key, abbreviatedKey);
            } //loop switches
            foreach (EnumerationItem<VALUES> enumerationItem in FValueEnumeration) {
                valueKeyList.Add(enumerationItem);
                string key, abbreviatedKey;
                PrepareKeys(enumerationItem, out key, out abbreviatedKey);
                ProcessDictionary(valueDictionary, enumerationItem, key, abbreviatedKey);
            } //loop values
            foreach (SwitchDictionaryValue dictionaryValue in switchDictionary.Values)
                if (dictionaryValue.Repeated)
                    repeatedValues.Add(dictionaryValue.OriginalTerm);
                else
                    unrecognizedList.Add(dictionaryValue.OriginalTerm);
            foreach (ValueDictionaryValue dictionaryValue in valueDictionary.Values)
                if (dictionaryValue.Repeated)
                    repeatedValues.Add(dictionaryValue.OriginalTerm);
                else
                    unrecognizedList.Add(dictionaryValue.OriginalTerm);
            FUnrecognizedOptions = unrecognizedList.ToArray();
            FFiles = fileList.ToArray();
            FRepeatedFiles = repeatedFileList.ToArray();
            FRepeatedSwitches = repeatedSwitches.ToArray();
            FRepeatedValues = repeatedValues.ToArray();
        } //ParseCommandLine

        void PrepareKeys(EnumerationItem<SWITCHES> item, out string key, out string abbreviatedKey) {
            key = item.Name;
            if (key != null && ((Options & CommandLineParsingOptions.CaseSensitiveKeys) == 0))
                key = key.ToLower();
            abbreviatedKey = item.AbbreviatedName;
            if (abbreviatedKey != null && ((Options & CommandLineParsingOptions.CaseSensitiveAbbreviations) == 0))
                abbreviatedKey = abbreviatedKey.ToLower();
        } //PrepareKeys
        void PrepareKeys(EnumerationItem<VALUES> item, out string key, out string abbreviatedKey) {
            key = item.Name;
            if (key != null && ((Options & CommandLineParsingOptions.CaseSensitiveKeys) == 0))
                key = key.ToLower();
            abbreviatedKey = item.AbbreviatedName;
            if (abbreviatedKey != null && ((Options & CommandLineParsingOptions.CaseSensitiveAbbreviations) == 0))
                abbreviatedKey = abbreviatedKey.ToLower();
        } //PrepareKeys
        void ProcessDictionary(Dictionary<string, SwitchDictionaryValue> dictionary, EnumerationItem<SWITCHES> item, string key, string abbreviatedKey) {
            bool foundAsFull = false;
            SwitchDictionaryValue dictionaryValue;
            if (dictionary.TryGetValue(key, out dictionaryValue)) {
                Switches[item.EnumValue] = dictionaryValue.Status;
                dictionary.Remove(key);
                foundAsFull = true;
            } //if
            if (key == abbreviatedKey) return;
            if (dictionary.TryGetValue(abbreviatedKey, out dictionaryValue)) {
                if (!foundAsFull) {
                    Switches[item.EnumValue] = dictionaryValue.Status;
                    dictionary.Remove(abbreviatedKey);
                } else
                    dictionaryValue.Repeated = true;
            } //if
        } //ProcessDictionary
        void ProcessDictionary(Dictionary<string, ValueDictionaryValue> dictionary, EnumerationItem<VALUES> item, string key, string abbreviatedKey) {
            bool foundAsFull = false;
            ValueDictionaryValue dictionaryValue;
            if (dictionary.TryGetValue(key, out dictionaryValue)) {
                Values[item.EnumValue] = dictionaryValue.Value;
                dictionary.Remove(key);
                foundAsFull = true;
            } //if
            if (key == abbreviatedKey) return;
            if (dictionary.TryGetValue(abbreviatedKey, out dictionaryValue)) {
                if (!foundAsFull) {
                    Values[item.EnumValue] = dictionaryValue.Value;
                    dictionary.Remove(abbreviatedKey);
                } else
                    dictionaryValue.Repeated = true;
            } //if
        } //ProcessDictionary

#if DEBUG
        void ValidateEnumerations() {
            StringDictionary dictionary = new StringDictionary();
            StringDictionary abbreviatedDictionary = new StringDictionary();
            foreach (EnumerationItem<SWITCHES> enumerationItem in FSwitchEnumeration) {
                string key, abbreviatedKey;
                PrepareKeys(enumerationItem, out key, out abbreviatedKey);
                ValidateBothKeys(dictionary, key, abbreviatedDictionary, abbreviatedKey);
            } //loop
            dictionary.Clear(); abbreviatedDictionary.Clear(); //important: switched and values are separate sets of options, uniqueness not required
            foreach (EnumerationItem<VALUES> enumerationItem in FValueEnumeration) {
                string key, abbreviatedKey;
                PrepareKeys(enumerationItem, out key, out abbreviatedKey);
                ValidateBothKeys(dictionary, key, abbreviatedDictionary, abbreviatedKey);
            } //loop
        } //ValidateEnumerations
        void ValidateKey(StringDictionary dictionary, string key) {
            Debug.Assert(!dictionary.ContainsKey(key), string.Format("Ambiguous command line: key {0} already found", key));
            dictionary.Add(key, key);
        } //ValidateKey
        void ValidateBothKeys(StringDictionary dictionary, string key, StringDictionary abbreviatedDictionary, string abbreviatedKey) {
            ValidateKey(dictionary, key);
            ValidateKey(abbreviatedDictionary, abbreviatedKey);
        } //ValidateBothKeys
#endif 

        abstract class DictionaryValue {
            internal DictionaryValue(string originalTerm) { this.OriginalTerm = originalTerm; }
            internal string OriginalTerm;
            internal bool Repeated;
        } //class DictionaryValue
        class SwitchDictionaryValue : DictionaryValue {
            internal SwitchDictionaryValue(CommandLineSwitchStatus status, string originalTerm) : base(originalTerm) { this.Status = status; }
            internal CommandLineSwitchStatus Status;
        } //class SwitchDictionaryValue
        class ValueDictionaryValue : DictionaryValue {
            internal ValueDictionaryValue(string value, string originalTerm) : base(originalTerm) { this.Value = value; }
            internal string Value;
        } //class SwitchDictionaryValue

        string[] FFiles;
        string[] FUnrecognizedOptions;
        string[] FRepeatedFiles;
        string[] FRepeatedSwitches;
        string[] FRepeatedValues;

        Enumeration<SWITCHES> FSwitchEnumeration = new Enumeration<SWITCHES>();
        Enumeration<VALUES> FValueEnumeration = new Enumeration<VALUES>();

        EnumerationIndexedArray<SWITCHES, CommandLineSwitchStatus> Switches = new EnumerationIndexedArray<SWITCHES, CommandLineSwitchStatus>();
        EnumerationIndexedArray<VALUES, string> Values = new EnumerationIndexedArray<VALUES, string>();

        CommandLineParsingOptions Options;

        #endregion implementation

    } //class CommandLine

} //namespace SA.Universal.Utilities
