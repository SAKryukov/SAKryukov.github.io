﻿/* 
    Command Line Utility:
    
    CommandLine is based on Enumeration and EnumerationIndexedArray
    To define command line options, define enumerations for switches and values and instantiate CommandLine parser class
    See CommandLine
    
    Copyright (C) 2004-2010 by Sergey A Kryukov
    http://www.SAKryukov.org
*/

namespace SA.Universal.Utilities {

    /// <summary>
    /// Status of the switch-like command line option (formatted as [-|/]option[-|+])
    /// returned by indexed property of <seealso cref="CommandLine"/>
    /// </summary>
    public enum CommandLineSwitchStatus : byte {
        
        /// <summary>
        /// Requested command line switch not found in command line
        /// </summary>
        Absent,
        /// <summary>
        /// Requested command line switch if found in command line in the form [-|/]option
        /// </summary>
        
        Present,
        /// <summary>
        /// Requested command line switch if found in command line in the form [-|/]option- ("switched off")
        /// </summary>
        Minus,

        /// <summary>
        /// Requested command line switch if found in command line in the form [-|/]option+
        /// </summary>
        Plus,

    } //enum CommandLineSwitchStatus

    [System.Flags]
    public enum CommandLineParsingOptions {
        CaseSensitiveKeys = 1,
        CaseSensitiveAbbreviations = 2,
        CaseSensitiveFiles = 4,
        DefaultMicrosoft = CaseSensitiveKeys | CaseSensitiveAbbreviations,
        DefaulUnix = CaseSensitiveKeys | CaseSensitiveAbbreviations | CommandLineParsingOptions.CaseSensitiveFiles,
        CaseInsensitive = 0,
    } //enum CommandLineParsingOptions

    #region implementation

    internal static class CommandLineParserDefinitionSet { //do not globalize! 
        internal static char[] Prefixes = new char[] { '-', '/', };
        internal const char KeyValueDelimiter = ':';
        internal const char OptionOn = '+';
        internal const char OptionOff = '-';
        internal const string FmtInvalidEnumType = "{0} must be enumeration type"; //type name
        internal const string FmtUnrecognizedSwitch = "{0}{1}"; //prefix, key
        internal const string FmtUnrecognizedValue = "{0}{1}{2}{3}"; //prefix, key, delimiter, value
    } //class CommandLineParserDefinitionSe

    internal static class CommandLineSimulationUtilityDefinitionSet { //do not globalize! 
        internal const char TokenDelimiter = ' ';
        internal const char TokenQuotation = '"';
        internal const char ReplacementDelimiter = '\0';
        internal static readonly string PreliminaryTermDelimiter = string.Empty + TokenQuotation + TokenDelimiter + TokenQuotation;
        internal static readonly string ReplacementPreliminaryTermDelimiter = string.Empty + TokenQuotation + ReplacementDelimiter + TokenQuotation;
        internal static readonly string TermDelimiter1 = string.Empty + TokenQuotation + TokenDelimiter;
        internal static readonly string ReplacementTermDelimiter1 = string.Empty + TokenQuotation + ReplacementDelimiter;
        internal static readonly string TermDelimiter2 = string.Empty + TokenDelimiter + TokenQuotation;
        internal static readonly string ReplacementTermDelimiter2 = string.Empty + ReplacementDelimiter + TokenQuotation;
        internal const string FmtQuotedCommandLineLocation = @"""{0}""";
        internal static readonly char[] TokenUnwanted = new char[] { '\n', '\r', };
    } //CommandLineSimulationUtilityDefinitionSet

    #endregion implementation

} //namespace SA.Universal.Utilities
