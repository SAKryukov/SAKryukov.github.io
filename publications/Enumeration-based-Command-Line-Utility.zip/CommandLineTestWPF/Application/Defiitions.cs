﻿namespace CommandLineTest {
    using System.Windows;
    
    internal class DefinitionSet {

        internal const string FmtTitle = " {0}";
        internal const string FmtErrorTitle = " {0} Error";
        internal const string FmtException = "{0}:\n\n{1}";
        internal const string FmtParsedItem = "\t{0}";
        
        internal static readonly Thickness HeaderMargin = new Thickness(0, 12, 2, 2);
        internal static readonly Thickness HeaderPadding = new Thickness(4);
        internal static readonly int HeaderFontWeightFactor = 2;
        internal static readonly double HeaderFontSizeFactor = 1.2d;
        
        internal const char TokenDelimiter = ' ';
        internal const char TokenQuotation = '"';
        internal static readonly char[] TokenUnwanted = new char[] { '\n', '\r', };

    } //class DefinitionSet

} //namespace CommandLineTest
