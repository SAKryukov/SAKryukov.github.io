﻿namespace CommandLineTest {
    using System;
    using System.Windows;
    using System.Globalization;
    using System.Reflection;

    internal class TestApplication {

        [STAThread]
        static void Main(string[] commandLine) {
            Application application = new Application();
            Window mainWindow = new MainWindow();
            application.MainWindow = mainWindow;
            application.MainWindow.Title = string.Format(DefinitionSet.FmtTitle, ProductName);
            application.MainWindow.Show();
            application.DispatcherUnhandledException += (sender, args) => {
                MessageBox.Show(
                    string.Format(DefinitionSet.FmtException, args.Exception.GetType().Name, args.Exception.Message),
                    string.Format(DefinitionSet.FmtErrorTitle, ProductName),
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }; //application.DispatcherUnhandledException
            application.Run();
        } //Main

        internal static string ProductName {
            get {
                if (FProductName == null)
                    FProductName = GetProductName();
                return FProductName;
            } //get ProductName
        } //ProductName

        static string GetProductName() {
            Assembly assembly = Assembly.GetEntryAssembly();
            AssemblyProductAttribute attr = GetAssemblyAttribute<AssemblyProductAttribute>(assembly);
            if (attr == null) return string.Empty; else return attr.Product;
        } //GetProductName

        static TYPE GetAssemblyAttribute<TYPE>(Assembly assembly) where TYPE : System.Attribute {
            object[] attributes = assembly.GetCustomAttributes(typeof(TYPE), false);
            if (attributes.Length < 1) return null;
            return ((TYPE)attributes[0]);
        } //GetAssemblyAttribute

        static string FProductName;

    } //class TestApplication

} //namespace CommandLineTest