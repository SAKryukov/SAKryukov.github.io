﻿namespace CommandLineTest {
    using System.Windows;

    public partial class MainWindow : Window {
        
        public MainWindow() {
            InitializeComponent();
            Setup();
        } //MainWindow

    } //class MainWindow

} //namespace CommandLineTest
