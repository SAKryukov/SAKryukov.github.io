﻿namespace CommandLineTest {
    using System;
    using System.Windows;
    using System.Windows.Controls;
    using SA.Universal.Enumerations;
    using SA.Universal.Utilities;
    using CommandLine = SA.Universal.Utilities.CommandLine<CommandLineTest.EnumerationDeclarations.BitsetOption, CommandLineTest.EnumerationDeclarations.StringOption>;

    public partial class MainWindow {
        
        void Setup() {
            this.buttonParse.Click += (sender, arg) => { Parse(); };
        } //Setup

        protected override void OnContentRendered(EventArgs e) {
            base.OnContentRendered(e);
            CommandLineParsingOptionsToControls(CommandLine.DefaultCommandLineParsingOptions);
            this.textBoxCommandLine.Text = CommandLineSimulationUtility.UnparsedCommandLine;
            Parse();
        } //OnContentRendered

        struct ItemInfo {
            internal ItemInfo(string name /* something else ... */) { Name = name; }
            public override string ToString() {
                return Name.ToString();
            } //ToString            
            string Name;
            //whatever else
            //...
        } //struct ItemInfo

        void PopulateTabItem(TabItem item) {
            DockPanel panel = new DockPanel();
            item.Content = panel;
            TextBox myTextBox = new TextBox();
            ListBox myListBox = new ListBox();
            ComboBox myComboBox = new ComboBox();
            panel.Children.Add(myTextBox);
            panel.Children.Add(myComboBox);
            panel.Children.Add(myListBox);
            //adjust layout...
            //...
        } //PopulateTabItem

        void Report(ListBox place, string value, bool header) {
            if (header) {
                TextBlock text = new TextBlock();
                text.Text = value;
                text.Padding = DefinitionSet.HeaderPadding;
                text.Margin = DefinitionSet.HeaderMargin;
                text.FontSize = text.FontSize * DefinitionSet.HeaderFontSizeFactor;
                text.FontWeight = FontWeight.FromOpenTypeWeight(text.FontWeight.ToOpenTypeWeight() * DefinitionSet.HeaderFontWeightFactor);
                place.Items.Add(text);
            } else
                place.Items.Add(string.Format(DefinitionSet.FmtParsedItem, value));
        } //Report
        void Report(ListBox place, string value) { Report(place, value, false); }

        void Parse() {
            this.listBoxErrors.Items.Clear();
            this.listBoxRecognized.Items.Clear();
            CommandLineParsingOptions options = this.ControlsToCommandLineParsingOptions();
            string[] commandLineOptions = SA.Universal.Utilities.CommandLineSimulationUtility.SimulateCommandLineParsingIntoArray(this.textBoxCommandLine.Text);
            CommandLine commandLine = new CommandLine(commandLineOptions, options);
            Report(listBoxRecognized, "Switches:", true);
            foreach (EnumerationItem<EnumerationDeclarations.BitsetOption> value in commandLine.SwitchEnumeration) {
                CommandLineSwitchStatus status = commandLine[value.EnumValue];
                Report(listBoxRecognized, string.Format("-{0}: {1}", GenerateDoubleName(value), status));
            } //bool
            Report(listBoxRecognized, "Values:", true);
            foreach (EnumerationItem<EnumerationDeclarations.StringOption> value in commandLine.ValueEnumeration) {
                string stringValue = commandLine[value.EnumValue];
                string stringDisambiguation = string.Empty;
                if (stringValue == null)
                    stringDisambiguation = "(not found)";
                else if (stringValue.Length < 1)
                    stringDisambiguation = "(empty string)";
                Report(listBoxRecognized, string.Format(@"-{0}: ""{1}"" {2}", GenerateDoubleName(value), stringValue, stringDisambiguation));
            } //loop
            Report(listBoxRecognized, "Files:", true);
            foreach (string value in commandLine.Files)
                Report(listBoxRecognized, value);
            Report(listBoxErrors, "Unrecognized:", true);
            foreach (string value in commandLine.UnrecognizedOptions)
                Report(listBoxErrors, value);
            Report(listBoxErrors, "Repeated switches:", true);
            foreach (string value in commandLine.RepeatedSwitches)
                Report(listBoxErrors, value);
            Report(listBoxErrors, "Repeated values:", true);
            foreach (string value in commandLine.RepeatedValues)
                Report(listBoxErrors, value);
            Report(listBoxErrors, "Repeated files:", true);
            foreach (string value in commandLine.RepeatedFiles)
                Report(listBoxErrors, value);
        } //Parse

        CommandLineParsingOptions ControlsToCommandLineParsingOptions() {
            CommandLineParsingOptions options = 0;
            if (this.checkBoxCaseSensitiveKeys.IsChecked == true)
                options |= CommandLineParsingOptions.CaseSensitiveKeys;
            if (this.checkBoxCaseSensitiveAbbreviations.IsChecked == true)
                options |= CommandLineParsingOptions.CaseSensitiveAbbreviations;
            if (this.checkBoxCaseSensitiveFiles.IsChecked == true)
                options |= CommandLineParsingOptions.CaseSensitiveFiles;
            return options;
        } //ControlsToCommandLineParsingOptions

        void CommandLineParsingOptionsToControls(CommandLineParsingOptions options) {
            this.checkBoxCaseSensitiveKeys.IsChecked = (options & CommandLineParsingOptions.CaseSensitiveKeys) > 0;
            this.checkBoxCaseSensitiveAbbreviations.IsChecked = (options & CommandLineParsingOptions.CaseSensitiveAbbreviations) > 0;
            this.checkBoxCaseSensitiveFiles.IsChecked = (options & CommandLineParsingOptions.CaseSensitiveFiles) > 0;
        } //CommandLineParsingOptionsToControls

        static string GenerateDoubleName<ENUM>(EnumerationItem<ENUM> item) {
            string name = item.Name;
            string abbreviation = item.AbbreviatedName;
            if (name == abbreviation)
                return name;
            else
                return string.Format("{0} (-{1})", name, abbreviation);
        } //GenerateDoubleName

    } //class MainWindow

} //namespace CommandLineTest