﻿namespace CommandLineTest.EnumerationDeclarations {
    using AbbreviationAttribute = SA.Universal.Enumerations.AbbreviationAttribute;

    enum StringOption {
        [Abbreviation(1)]
        InputDirectory,
        InputFileMask,
        [Abbreviation(1)]
        OutputDirectory,
        [Abbreviation(1)]
        ForceOutputFormat,
        [Abbreviation(1)]
        ConfigurationFile,
        [Abbreviation(3)]
        LogFile,
    } //enum StringOption

    enum BitsetOption {
        Default,
        [Abbreviation(1)]
        Recursive,
        [Abbreviation(1)]
        CreateOutputDirectory,
        [Abbreviation(1)]
        Quite,
    } //BitsetOption

} //namespace CommandLineTest.EnumerationDeclarations
