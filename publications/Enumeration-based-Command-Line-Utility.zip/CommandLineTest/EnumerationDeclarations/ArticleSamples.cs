﻿namespace ArticleSample {
    using System.IO;
    using SA.Universal.Utilities;
    using CommandLine = SA.Universal.Utilities.CommandLine<BitsetOption, StringOption>;
    using AbbreviationAttribute = SA.Universal.Enumerations.AbbreviationAttribute;
    using DescriptionAttribute = SA.Universal.Enumerations.DescriptionAttribute;

    enum CommandLineSwitches { A, B, C, }
    enum CommandLineStringValues { A, B, D, E, }

    enum StringOption {
        [Abbreviation(1)]
        InputDirectory,
        InputFileMask,
        [Abbreviation(1)]
        OutputDirectory,
        [Abbreviation(1)]
        ForceOutputFormat,
        [Abbreviation(1)]
        ConfigurationFile,
        [Abbreviation(3)]
        LogFile,
    } //enum StringOption

    enum BitsetOption {
        [Abbreviation(1)]
        Default,
        [Abbreviation(1)]
        Recursive,
        [Abbreviation(1)]
        CreateOutputDirectory,
        [Abbreviation(1)]
        Quite,
    } //BitsetOption

    public class AgeLimitException : System.ApplicationException {
        internal AgeLimitException(int actualAge, string comment) : base(comment) { this.fActualAge = actualAge; }
        internal AgeLimitException(int actualAge) { this.fActualAge = actualAge; }
        public int ActualAge { get { return fActualAge; } }
        int fActualAge;
    } //class AgeLimitException

} //namespace ArticleSample