﻿namespace CommandLineTest {

    //TODO: globalize (just a test application; who cares?)
    internal static class DefinitionSet {

        internal const string FmtTitle = " {0}"; //ProductName
        internal const string FmtException = "{0}:\n\n{1}"; //exception type, Message
        internal const string FmtErrorMessageTitle = " {0}: Exception"; //ProductName

        internal const string Minus = "-";
        internal const string Plus = "+";
        internal const string FmtSwitch = "      -{0}: <{1}>"; //name, status
        internal const string FmtValue = @"      -{0}: ""{1}""{2}"; //name, value, disambiguation value (null (not found) or empty)
        internal const string FmtStringProperty = "      {0}"; //value
        internal const string FmtDoubleName = "{0} (-{1})"; //name, abbreviated name

        internal const string DisambiguationNull = " (not found)";
        internal const string DisambiguationEmpty = " (empty string)";

        internal const string SectionSwitches = " SWITCHES:";
        internal const string SectionValues = " VALUES:";
        internal const string SectionFiles = " FILES:";
        internal const string SectionUnrecognized = " UNRECOGNIZED:";
        internal const string SectionRepeatedSwitches = " REPEATED SWITCHES:";
        internal const string SectionRepeatedValues = " REPEATED VALUES:";
        internal const string SectionRepeatedFiles = " REPEATED FILES:";

        internal const int PanelPad = 8; 

    } //class DefinitionSet

} //namespace CommandLineTest
