﻿namespace CommandLineTest {
    using System.Windows.Forms;
    using SA.Universal.Enumerations;
    using SA.Universal.Utilities;
    using StringBuilder = System.Text.StringBuilder;

    internal class CommandLineReport {

        internal CommandLineReport(ListBox options, ListBox errors) {
            this.Options = options; this.Errors = errors;
        } //CommandLineReport

        internal void Show<SWITCHES, VALUES>(SA.Universal.Utilities.CommandLine<SWITCHES, VALUES> commandLine) {
            Options.Items.Clear();
            Errors.Items.Clear();
            Options.Items.Add(string.Empty);
            Options.Items.Add(DefinitionSet.SectionSwitches);
            foreach (EnumerationItem<SWITCHES> item in commandLine.SwitchEnumeration) {
                CommandLineSwitchStatus status = commandLine[item.EnumValue];
                Options.Items.Add(string.Format(DefinitionSet.FmtSwitch, GenerateDoubleName<SWITCHES>(item), status));
            } //loop
            Options.Items.Add(string.Empty);
            Options.Items.Add(DefinitionSet.SectionValues);
            foreach (EnumerationItem<VALUES> item in commandLine.ValueEnumeration) {
                string value = commandLine[item.EnumValue];
                string valueDisambiguation = string.Empty;
                if (value == null)
                    valueDisambiguation = DefinitionSet.DisambiguationNull;
                else if (value.Length < 1)
                    valueDisambiguation = DefinitionSet.DisambiguationEmpty;
                Options.Items.Add(string.Format(DefinitionSet.FmtValue, GenerateDoubleName<VALUES>(item), value, valueDisambiguation));
            } //loop
            Options.Items.Add(string.Empty);
            Options.Items.Add(DefinitionSet.SectionFiles);
            foreach(string value in commandLine.Files)
                Options.Items.Add(string.Format(DefinitionSet.FmtStringProperty, value));
            Errors.Items.Add(string.Empty);
            Errors.Items.Add(DefinitionSet.SectionUnrecognized);
            foreach (string value in commandLine.UnrecognizedOptions)
                Errors.Items.Add(string.Format(DefinitionSet.FmtStringProperty, value));
            Errors.Items.Add(string.Empty);
            Errors.Items.Add(DefinitionSet.SectionRepeatedSwitches);
            foreach (string value in commandLine.RepeatedSwitches)
                Errors.Items.Add(string.Format(DefinitionSet.FmtStringProperty, value));
            Errors.Items.Add(string.Empty);
            Errors.Items.Add(DefinitionSet.SectionRepeatedValues);
            foreach (string value in commandLine.RepeatedValues)
                Errors.Items.Add(string.Format(DefinitionSet.FmtStringProperty, value));
            Errors.Items.Add(string.Empty);
            Errors.Items.Add(DefinitionSet .SectionRepeatedFiles);
            foreach (string value in commandLine.RepeatedFiles)
                Errors.Items.Add(string.Format(DefinitionSet.FmtStringProperty, value));
        } //Show

        static string GenerateDoubleName<ENUM>(EnumerationItem<ENUM> item) {
            string name = item.Name;
            string abbreviation = item.AbbreviatedName;
            if (name == abbreviation)
                return name;
            else
                return string.Format(DefinitionSet.FmtDoubleName, name, abbreviation);
        } //GenerateDoubleName

        ListBox Options, Errors;

    } //CommandLineReport

} //namespace CommandLineTest
