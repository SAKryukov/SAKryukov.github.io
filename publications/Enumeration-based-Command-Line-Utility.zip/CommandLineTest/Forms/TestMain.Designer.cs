﻿namespace CommandLineTest.Forms {
    partial class TestMain {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.panelCommandLine = new System.Windows.Forms.Panel();
            this.panelCommandLinePad = new System.Windows.Forms.Panel();
            this.labelCommnadLine = new System.Windows.Forms.Label();
            this.panelCommandLineOptions = new System.Windows.Forms.Panel();
            this.panelButtonPad = new System.Windows.Forms.Panel();
            this.buttonParse = new System.Windows.Forms.Button();
            this.groupBoxCommandLineOptions = new System.Windows.Forms.GroupBox();
            this.checkBoxFiles = new System.Windows.Forms.CheckBox();
            this.checkBoxAbbreviations = new System.Windows.Forms.CheckBox();
            this.checkBoxKeys = new System.Windows.Forms.CheckBox();
            this.splitterCommandLine = new System.Windows.Forms.Splitter();
            this.panelOptions = new System.Windows.Forms.Panel();
            this.panelOptionsPad = new System.Windows.Forms.Panel();
            this.labelOptions = new System.Windows.Forms.Label();
            this.splitterOptions = new System.Windows.Forms.Splitter();
            this.panelOutput = new System.Windows.Forms.Panel();
            this.panelErrors = new System.Windows.Forms.Panel();
            this.panelErrorsPad = new System.Windows.Forms.Panel();
            this.labelErrors = new System.Windows.Forms.Label();
            this.panelCommandLine.SuspendLayout();
            this.panelCommandLineOptions.SuspendLayout();
            this.panelButtonPad.SuspendLayout();
            this.groupBoxCommandLineOptions.SuspendLayout();
            this.panelOptions.SuspendLayout();
            this.panelOutput.SuspendLayout();
            this.panelErrors.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelCommandLine
            // 
            this.panelCommandLine.Controls.Add(this.panelCommandLinePad);
            this.panelCommandLine.Controls.Add(this.labelCommnadLine);
            this.panelCommandLine.Controls.Add(this.panelCommandLineOptions);
            this.panelCommandLine.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelCommandLine.Location = new System.Drawing.Point(0, 0);
            this.panelCommandLine.Margin = new System.Windows.Forms.Padding(4);
            this.panelCommandLine.Name = "panelCommandLine";
            this.panelCommandLine.Size = new System.Drawing.Size(836, 161);
            this.panelCommandLine.TabIndex = 0;
            // 
            // panelCommandLinePad
            // 
            this.panelCommandLinePad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelCommandLinePad.Location = new System.Drawing.Point(0, 16);
            this.panelCommandLinePad.Margin = new System.Windows.Forms.Padding(4);
            this.panelCommandLinePad.Name = "panelCommandLinePad";
            this.panelCommandLinePad.Size = new System.Drawing.Size(634, 145);
            this.panelCommandLinePad.TabIndex = 2;
            // 
            // labelCommnadLine
            // 
            this.labelCommnadLine.AutoSize = true;
            this.labelCommnadLine.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelCommnadLine.Location = new System.Drawing.Point(0, 0);
            this.labelCommnadLine.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelCommnadLine.Name = "labelCommnadLine";
            this.labelCommnadLine.Size = new System.Drawing.Size(108, 16);
            this.labelCommnadLine.TabIndex = 1;
            this.labelCommnadLine.Text = "&Command Line:";
            // 
            // panelCommandLineOptions
            // 
            this.panelCommandLineOptions.Controls.Add(this.panelButtonPad);
            this.panelCommandLineOptions.Controls.Add(this.groupBoxCommandLineOptions);
            this.panelCommandLineOptions.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelCommandLineOptions.Location = new System.Drawing.Point(634, 0);
            this.panelCommandLineOptions.Margin = new System.Windows.Forms.Padding(4);
            this.panelCommandLineOptions.Name = "panelCommandLineOptions";
            this.panelCommandLineOptions.Size = new System.Drawing.Size(202, 161);
            this.panelCommandLineOptions.TabIndex = 0;
            // 
            // panelButtonPad
            // 
            this.panelButtonPad.Controls.Add(this.buttonParse);
            this.panelButtonPad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelButtonPad.Location = new System.Drawing.Point(0, 103);
            this.panelButtonPad.Margin = new System.Windows.Forms.Padding(4);
            this.panelButtonPad.Name = "panelButtonPad";
            this.panelButtonPad.Size = new System.Drawing.Size(202, 58);
            this.panelButtonPad.TabIndex = 1;
            // 
            // buttonParse
            // 
            this.buttonParse.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonParse.Location = new System.Drawing.Point(0, 0);
            this.buttonParse.Margin = new System.Windows.Forms.Padding(4);
            this.buttonParse.Name = "buttonParse";
            this.buttonParse.Size = new System.Drawing.Size(202, 58);
            this.buttonParse.TabIndex = 0;
            this.buttonParse.Text = "&Parse";
            this.buttonParse.UseVisualStyleBackColor = true;
            // 
            // groupBoxCommandLineOptions
            // 
            this.groupBoxCommandLineOptions.Controls.Add(this.checkBoxFiles);
            this.groupBoxCommandLineOptions.Controls.Add(this.checkBoxAbbreviations);
            this.groupBoxCommandLineOptions.Controls.Add(this.checkBoxKeys);
            this.groupBoxCommandLineOptions.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBoxCommandLineOptions.Location = new System.Drawing.Point(0, 0);
            this.groupBoxCommandLineOptions.Margin = new System.Windows.Forms.Padding(4);
            this.groupBoxCommandLineOptions.Name = "groupBoxCommandLineOptions";
            this.groupBoxCommandLineOptions.Padding = new System.Windows.Forms.Padding(4);
            this.groupBoxCommandLineOptions.Size = new System.Drawing.Size(202, 103);
            this.groupBoxCommandLineOptions.TabIndex = 0;
            this.groupBoxCommandLineOptions.TabStop = false;
            this.groupBoxCommandLineOptions.Text = " Case &Sensitive: ";
            // 
            // checkBoxFiles
            // 
            this.checkBoxFiles.AutoSize = true;
            this.checkBoxFiles.Location = new System.Drawing.Point(35, 68);
            this.checkBoxFiles.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxFiles.Name = "checkBoxFiles";
            this.checkBoxFiles.Size = new System.Drawing.Size(56, 20);
            this.checkBoxFiles.TabIndex = 2;
            this.checkBoxFiles.Text = "&Files";
            this.checkBoxFiles.UseVisualStyleBackColor = true;
            // 
            // checkBoxAbbreviations
            // 
            this.checkBoxAbbreviations.AutoSize = true;
            this.checkBoxAbbreviations.Location = new System.Drawing.Point(35, 50);
            this.checkBoxAbbreviations.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxAbbreviations.Name = "checkBoxAbbreviations";
            this.checkBoxAbbreviations.Size = new System.Drawing.Size(142, 20);
            this.checkBoxAbbreviations.TabIndex = 1;
            this.checkBoxAbbreviations.Text = "&Abbreviated Keys";
            this.checkBoxAbbreviations.UseVisualStyleBackColor = true;
            // 
            // checkBoxKeys
            // 
            this.checkBoxKeys.AutoSize = true;
            this.checkBoxKeys.Location = new System.Drawing.Point(35, 31);
            this.checkBoxKeys.Margin = new System.Windows.Forms.Padding(4);
            this.checkBoxKeys.Name = "checkBoxKeys";
            this.checkBoxKeys.Size = new System.Drawing.Size(58, 20);
            this.checkBoxKeys.TabIndex = 0;
            this.checkBoxKeys.Text = "&Keys";
            this.checkBoxKeys.UseVisualStyleBackColor = true;
            // 
            // splitterCommandLine
            // 
            this.splitterCommandLine.BackColor = System.Drawing.Color.Wheat;
            this.splitterCommandLine.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitterCommandLine.Location = new System.Drawing.Point(0, 161);
            this.splitterCommandLine.Margin = new System.Windows.Forms.Padding(4);
            this.splitterCommandLine.Name = "splitterCommandLine";
            this.splitterCommandLine.Size = new System.Drawing.Size(836, 13);
            this.splitterCommandLine.TabIndex = 1;
            this.splitterCommandLine.TabStop = false;
            // 
            // panelOptions
            // 
            this.panelOptions.Controls.Add(this.panelOptionsPad);
            this.panelOptions.Controls.Add(this.labelOptions);
            this.panelOptions.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelOptions.Location = new System.Drawing.Point(0, 0);
            this.panelOptions.Margin = new System.Windows.Forms.Padding(4);
            this.panelOptions.Name = "panelOptions";
            this.panelOptions.Size = new System.Drawing.Size(388, 626);
            this.panelOptions.TabIndex = 0;
            // 
            // panelOptionsPad
            // 
            this.panelOptionsPad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelOptionsPad.Location = new System.Drawing.Point(0, 16);
            this.panelOptionsPad.Margin = new System.Windows.Forms.Padding(4);
            this.panelOptionsPad.Name = "panelOptionsPad";
            this.panelOptionsPad.Size = new System.Drawing.Size(388, 610);
            this.panelOptionsPad.TabIndex = 4;
            // 
            // labelOptions
            // 
            this.labelOptions.AutoSize = true;
            this.labelOptions.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelOptions.Location = new System.Drawing.Point(0, 0);
            this.labelOptions.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelOptions.Name = "labelOptions";
            this.labelOptions.Size = new System.Drawing.Size(64, 16);
            this.labelOptions.TabIndex = 3;
            this.labelOptions.Text = "&Options:";
            // 
            // splitterOptions
            // 
            this.splitterOptions.BackColor = System.Drawing.Color.Wheat;
            this.splitterOptions.Location = new System.Drawing.Point(388, 0);
            this.splitterOptions.Margin = new System.Windows.Forms.Padding(4);
            this.splitterOptions.Name = "splitterOptions";
            this.splitterOptions.Size = new System.Drawing.Size(18, 626);
            this.splitterOptions.TabIndex = 1;
            this.splitterOptions.TabStop = false;
            // 
            // panelOutput
            // 
            this.panelOutput.Controls.Add(this.panelErrors);
            this.panelOutput.Controls.Add(this.splitterOptions);
            this.panelOutput.Controls.Add(this.panelOptions);
            this.panelOutput.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelOutput.Location = new System.Drawing.Point(0, 174);
            this.panelOutput.Margin = new System.Windows.Forms.Padding(4);
            this.panelOutput.Name = "panelOutput";
            this.panelOutput.Size = new System.Drawing.Size(836, 626);
            this.panelOutput.TabIndex = 2;
            // 
            // panelErrors
            // 
            this.panelErrors.Controls.Add(this.panelErrorsPad);
            this.panelErrors.Controls.Add(this.labelErrors);
            this.panelErrors.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelErrors.Location = new System.Drawing.Point(406, 0);
            this.panelErrors.Name = "panelErrors";
            this.panelErrors.Size = new System.Drawing.Size(430, 626);
            this.panelErrors.TabIndex = 2;
            // 
            // panelErrorsPad
            // 
            this.panelErrorsPad.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelErrorsPad.Location = new System.Drawing.Point(0, 16);
            this.panelErrorsPad.Margin = new System.Windows.Forms.Padding(4);
            this.panelErrorsPad.Name = "panelErrorsPad";
            this.panelErrorsPad.Size = new System.Drawing.Size(430, 610);
            this.panelErrorsPad.TabIndex = 6;
            // 
            // labelErrors
            // 
            this.labelErrors.AutoSize = true;
            this.labelErrors.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelErrors.Location = new System.Drawing.Point(0, 0);
            this.labelErrors.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelErrors.Name = "labelErrors";
            this.labelErrors.Size = new System.Drawing.Size(52, 16);
            this.labelErrors.TabIndex = 5;
            this.labelErrors.Text = "&Errors:";
            // 
            // TestMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(836, 800);
            this.Controls.Add(this.panelOutput);
            this.Controls.Add(this.splitterCommandLine);
            this.Controls.Add(this.panelCommandLine);
            this.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "TestMain";
            this.Text = "TestMain";
            this.panelCommandLine.ResumeLayout(false);
            this.panelCommandLine.PerformLayout();
            this.panelCommandLineOptions.ResumeLayout(false);
            this.panelButtonPad.ResumeLayout(false);
            this.groupBoxCommandLineOptions.ResumeLayout(false);
            this.groupBoxCommandLineOptions.PerformLayout();
            this.panelOptions.ResumeLayout(false);
            this.panelOptions.PerformLayout();
            this.panelOutput.ResumeLayout(false);
            this.panelErrors.ResumeLayout(false);
            this.panelErrors.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelCommandLine;
        private System.Windows.Forms.Panel panelCommandLineOptions;
        private System.Windows.Forms.Splitter splitterCommandLine;
        private System.Windows.Forms.Label labelCommnadLine;
        private System.Windows.Forms.GroupBox groupBoxCommandLineOptions;
        private System.Windows.Forms.CheckBox checkBoxFiles;
        private System.Windows.Forms.CheckBox checkBoxAbbreviations;
        private System.Windows.Forms.CheckBox checkBoxKeys;
        private System.Windows.Forms.Panel panelButtonPad;
        private System.Windows.Forms.Panel panelCommandLinePad;
        private System.Windows.Forms.Button buttonParse;
        private System.Windows.Forms.Panel panelOptions;
        private System.Windows.Forms.Panel panelOptionsPad;
        private System.Windows.Forms.Label labelOptions;
        private System.Windows.Forms.Splitter splitterOptions;
        private System.Windows.Forms.Panel panelOutput;
        private System.Windows.Forms.Panel panelErrors;
        private System.Windows.Forms.Panel panelErrorsPad;
        private System.Windows.Forms.Label labelErrors;
    }
}