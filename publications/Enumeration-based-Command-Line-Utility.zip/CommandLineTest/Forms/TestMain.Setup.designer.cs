﻿namespace CommandLineTest.Forms {
    using System.Windows.Forms;
    using System.Drawing;
    using CommandLineSimulationUtility = SA.Universal.Utilities.CommandLineSimulationUtility;
    using CommandLine = SA.Universal.Utilities.CommandLine<CommandLineTest.EnumerationDeclarations.BitsetOption, CommandLineTest.EnumerationDeclarations.StringOption>;
    using CommandLineParsingOptions = SA.Universal.Utilities.CommandLineParsingOptions;

    public partial class TestMain {

        void Setup() {
            Text = string.Format(DefinitionSet.FmtTitle, ProductName);
            Application.ThreadException += delegate(object sender, System.Threading.ThreadExceptionEventArgs args) {
                MessageBox.Show(string.Format(DefinitionSet.FmtException, args.Exception.GetType().Name, args.Exception.Message), string.Format(DefinitionSet.FmtErrorMessageTitle, ProductName), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }; //ThreadException
            SetupControls();
            SetupPadding();
            CommandLineText.Text = CommandLineSimulationUtility.UnparsedCommandLine;
            CommandLineReport = new CommandLineReport(this.Options, this.Errors);
            CommandLineParsingOptionsToControls(SA.Universal.Utilities.CommandLine<CommandLineTest.EnumerationDeclarations.BitsetOption, CommandLineTest.EnumerationDeclarations.StringOption>.DefaultCommandLineParsingOptions);
            CommandLineParsingOptionsToControls(CommandLine.DefaultCommandLineParsingOptions);
            Parse();
        } //Setup

        void SetupControls() {
            Control[] runTimeControls = new Control[] {CommandLineText, Options, Errors};
            foreach (ListBox list in new ListBox[] { Options, Errors }) list.IntegralHeight = false;
            foreach (Control control in runTimeControls)
                control.Dock = DockStyle.Fill;
            foreach (Control splitter in new Control[] { this.splitterCommandLine, this.splitterOptions })
                splitter.BackColor = Color.WhiteSmoke; //SA???
            CommandLineText.Multiline = true;
            CommandLineText.WordWrap = true;
            CommandLineText.AcceptsReturn = true;
            CommandLineText.AcceptsTab = false;
            CommandLineText.ScrollBars = ScrollBars.Vertical;
            this.panelCommandLinePad.Controls.Add(CommandLineText);
            this.panelOptionsPad.Controls.Add(Options);
            this.panelErrorsPad.Controls.Add(Errors);
            this.buttonParse.Click += delegate(object sender, System.EventArgs args) { Parse(); };
        } //SetupControls

        void SetupPadding() {
            int pad = DefinitionSet.PanelPad;
            this.Padding = new Padding(pad);
            this.panelCommandLinePad.Padding = new Padding(0, pad, 0, 0);
            this.panelOptionsPad.Padding = new Padding(0, pad, 0, 0);
            this.panelErrorsPad.Padding = new Padding(0, pad, 0, 0);
            this.panelButtonPad.Padding = new Padding(0, pad, 0, 0);
            this.panelCommandLineOptions.Padding = new Padding(pad, pad, 0, 0);
            this.panelCommandLine.Padding = new Padding(0, 0, 0, pad);
            this.panelOptions.Padding = new Padding(0, pad, pad, 0);
            this.panelErrors.Padding = new Padding(pad, pad, 0, 0);
            this.splitterCommandLine.Height = pad;
            this.splitterOptions.Width = pad;
        } //SetupPadding

        CommandLineParsingOptions ControlsToCommandLineParsingOptions() {
            CommandLineParsingOptions value = 0;
            if (this.checkBoxFiles.Checked)
                value |= CommandLineParsingOptions.CaseSensitiveFiles;
            if (this.checkBoxKeys.Checked)
                value |= CommandLineParsingOptions.CaseSensitiveKeys;
            if (this.checkBoxAbbreviations.Checked)
                value |= CommandLineParsingOptions.CaseSensitiveAbbreviations;
            return value;
        } //ControlsToCommandLineParsingOptions

        void CommandLineParsingOptionsToControls(CommandLineParsingOptions options) {
            this.checkBoxFiles.Checked = (options & CommandLineParsingOptions.CaseSensitiveFiles) > 0;
            this.checkBoxKeys.Checked = (options & CommandLineParsingOptions.CaseSensitiveKeys) > 0;
            this.checkBoxAbbreviations.Checked = (options & CommandLineParsingOptions.CaseSensitiveAbbreviations) > 0;            
        } //CommandLineParsingOptionsToControls

        void Parse() {
            string[] simulatedCommandLine = CommandLineSimulationUtility.SimulateCommandLineParsingIntoArray(this.CommandLineText.Text);
            CommandLineParsingOptions options = ControlsToCommandLineParsingOptions();
            CommandLine commandLine = new CommandLine(simulatedCommandLine, options);
            CommandLineReport.Show<EnumerationDeclarations.BitsetOption, EnumerationDeclarations.StringOption>(commandLine);
        } //Parse

        TextBox CommandLineText = new TextBox();
        ListBox Options = new ListBox();
        ListBox Errors = new ListBox();

        CommandLineReport CommandLineReport;

    } //class TestMain

} //namespace CommandLineTest.Forms