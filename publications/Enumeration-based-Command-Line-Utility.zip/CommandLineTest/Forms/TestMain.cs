﻿using System.Windows.Forms;

namespace CommandLineTest.Forms {

    public partial class TestMain : Form {
    
        public TestMain() {
            InitializeComponent();
            Setup();
        } //TestMain

        [System.STAThread]
        static void Main() {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.Run(new Forms.TestMain());
        } //Main

    } //class TestMain

} //namespace CommandLineTest.Forms
