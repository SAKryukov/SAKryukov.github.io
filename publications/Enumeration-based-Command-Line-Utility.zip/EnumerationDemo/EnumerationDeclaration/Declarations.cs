﻿namespace EnumerationDemo {
    using DisplayNameAttribute = SA.Universal.Enumerations.DisplayNameAttribute;
    using DescriptionAttribute = SA.Universal.Enumerations.DescriptionAttribute;

    enum NamingTest { One, Two, Three, Four, Count = One, }

    enum Status {
        Created = 0,
        Started = 1,
        Running = 2,
        Paused = 3,
        Terminated = 4,
        Invalid = 5,
        Deleted = 6,
        [SA.Universal.Enumerations.NonEnumerable]
        Redundant = 100,
        [SA.Universal.Enumerations.NonEnumerable]
        NonUnique = Paused,
        NonUniqueUsable = Running,
    } //enum Status

    enum CardSuit { Clubs, Diamonds, Spades, Hearts, }

    [DisplayName(typeof(EnumerationDeclaration.DisplayNames))]
    [Description(typeof(EnumerationDeclaration.Descriptions))]
    enum StringOption {
        InputDirectory,
        InputFileMask,
        OutputDirectory,
        ForceOutputFormat,
        ConfigurationFile,
        LogFile,
    } //enum StringOption

    [System.Flags]
    [DisplayName(typeof(EnumerationDeclaration.DisplayNames))]
    [Description(typeof(EnumerationDeclaration.Descriptions))]
    enum BitsetOptions {
        Default = 0,
        Recursive = 1 << 0,
        CreateOutputDirectory = 1 << 1,
        Quite = 1 << 2,
    } //BitsetOptions

} //namespace EnumerationDemo