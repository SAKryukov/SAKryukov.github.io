﻿/*
    Samples code snippets for article
    "Working around Language Limitations: Making Enumerations Enumerate
     Generic classes for enumeration-based iteration and array indexing"
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org    
*/
namespace JustTests {

    internal class EnumerationExtension {

        enum CommandSet { New, Open, Save, SaveAs, }
        //will not compile:
        //enum ExtendedCommandSet : CommandSet { Import, Export, }

        enum ExtendedCommandSet {
            //"inherited" members:
            New = CommandSet.New,
            Open = CommandSet.Open,
            Save = CommandSet.Save,
            SaveAs = CommandSet.SaveAs,
            //"new" members:
            //Import, Export,
        } //enum ExtendedCommandSet

    } //class EnumerationExtension

} //namespace JustTests