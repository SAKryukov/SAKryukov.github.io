﻿/*
    Samples code snippets for article
    "Working around Language Limitations: Making Enumerations Enumerate
     Generic classes for enumeration-based iteration and array indexing"
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org    
*/
namespace JustTests {

    internal class LengthDescriptorUse {

        enum CardSuit { Clubs, Diamonds, Spades, Hearts, Length, }

        internal void IterationSample() {

            for (CardSuit loopVariable = 0; loopVariable <= CardSuit.Length; loopVariable++) {
                //use loopVarible
            } //loop CardSuit
            CardSuit length = CardSuit.Length;
            for (CardSuit loopVarible = length--; loopVarible <= 0; loopVarible--) {
                //use loopVarible
            } //loop

        } //LengthDescriptorUse

    } //class SimplestIteration

} //namespace JustTests