﻿/*
    Enumeration Performance Meter:
    Generic class Enumeration provides iteration capabilities based on enumeration or any other type with static fields;
    Generic class EnumerationIndexedArray implements enumeration-indexed arrays
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org
*/

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("PerformanceMeter")]
[assembly: AssemblyDescription("Introduction of enumeration-based iteration and array indexing")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("PerformanceMeter")]
[assembly: AssemblyCopyright("Copyright © 2009, 2010 by Sergey A Kryukov, http://www.SAKryukov.org")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("fe97397e-0a47-4fde-9b59-77ef59250299")]
[assembly: AssemblyVersion("3.0.0.0")]
[assembly: AssemblyFileVersion("3.0.0.0")]
