// Measurements of Earth's Flatness
//
// Copyright (c) Sergey A Kryukov, 2023
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
//
// Original publication:
// https://www.codeproject.com/Articles/5358102/Measurements-of-Earth-Flatness
//
namespace SA.View {
    using System.Windows.Shapes;
    using Brush = System.Windows.Media.Brush;
    using Canvas = System.Windows.Controls.Canvas;
    using Image = System.Windows.Controls.Image;
    using IndexList = System.Collections.Generic.List<int>;
    using Math = System.Math;

    class Mystification {

        internal Mystification(Canvas canvas, Image image) { this.canvas = canvas; this.image = image; }

        internal class ShapeDescriptor {
            internal double Thickness { get; set; }
            internal Brush Brush { get; set; }
            private protected Mystification owner;
        } //ShapeDescriptor

        internal class LineDescriptor : ShapeDescriptor {
            internal LineDescriptor(Mystification owner) { this.owner = owner; }
            internal double X1 { get; set; }
            internal double X2 { get; set; }
            internal double Y1 { get; set; }
            internal double Y2 { get; set; }
            internal void Add() {
                line = new();
                owner.ArrangeLine(line, this);
                owner.canvas.Children.Add(line);
            } //Add
            internal void Move() {
                owner.ArrangeLine(line, this);
            } //Move
            internal void Remove() {
                if (line != null)
                    owner.canvas.Children.Remove(line);
            } //Remove
            Line line;
        } //class LineDescriptor

        internal class CircleDescriptor : ShapeDescriptor {
            internal CircleDescriptor(Mystification owner) { this.owner = owner; }
            internal double CenterX { get; set; }
            internal double CenterY { get; set; }
            internal double Radius { get; set; }
            internal void Add() {
                ellipse = new();
                owner.canvas.Children.Add(ellipse);
                owner.ArrangeCircle(ellipse, this);
            } //Add
            internal void Move() {
                owner.ArrangeCircle(ellipse, this);
            } //Move
            internal void Remove() {
                if (ellipse != null)
                    owner.canvas.Children.Remove(ellipse);
            } //Remove
            Ellipse ellipse;
        } //class LineDescriptor2

        internal LineDescriptor Add(double x1, double x2, double y1, double y2, Brush brush) {
            Line line = new();
            LineDescriptor descriptor = new(this) { X1 = x1, X2 = x2, Y1 = y1, Y2 = y2, Brush = brush };
            line.Tag = descriptor;
            ArrangeLine(line, descriptor);
            return descriptor;
        } //Add

        internal void Clear() {
            IndexList list = new();
            for (int index = 0; index < canvas.Children.Count; ++index)
                if (canvas.Children[index] is Shape)
                    list.Add(index);
            for (int index = list.Count - 1; index >= 0; --index)
                canvas.Children.RemoveAt(list[index]);
        } //Clear

        internal void Arrange() {
            foreach (var child in canvas.Children)
                if (child is Line line)
                    if (line.Tag != null && line.Tag is LineDescriptor descriptor)
                        ArrangeLine(line, descriptor);
        } //Arrange 

        void ArrangeCircle(Ellipse circle, CircleDescriptor descriptor) {
            double size;
            if (image != null && image.Source != null) {
                var imageLeft = Canvas.GetLeft(image);
                var imageTop = Canvas.GetTop(image);
                size = Math.Min(image.ActualWidth, image.ActualHeight);
                double dx = image.ActualWidth / 2;
                double dy = image.ActualHeight / 2;
                Canvas.SetLeft(circle, imageLeft + dx - size * descriptor.Radius);
                Canvas.SetTop(circle, imageTop + dy - size * descriptor.Radius);
            } else {
                size = Math.Min(canvas.ActualWidth, canvas.ActualHeight);
                double dx = canvas.ActualWidth / 2;
                double dy = canvas.ActualHeight / 2;
                Canvas.SetLeft(circle, dx - size * descriptor.Radius);
                Canvas.SetTop(circle, dy - size * descriptor.Radius);
            } //if
            circle.Width = size * descriptor.Radius * 2;
            circle.Height = size * descriptor.Radius * 2;
            if (descriptor.Thickness > 0)
                circle.StrokeThickness = descriptor.Thickness;
            circle.Stroke = descriptor.Brush;
        } //ArrangeCircle

        void ArrangeLine(Line line, LineDescriptor descriptor) {
            if (image != null && image.Source != null) {
                var imageLeft = Canvas.GetLeft(image);
                var imageTop = Canvas.GetTop(image);
                line.X1 = imageLeft + descriptor.X1 * image.ActualWidth;
                line.X2 = imageLeft + descriptor.X2 * image.ActualWidth;
                line.Y1 = imageTop + descriptor.Y1 * image.ActualHeight;
                line.Y2 = imageTop + descriptor.Y2 * image.ActualHeight;
            } else {
                line.X1 = descriptor.X1 * canvas.ActualWidth;
                line.X2 = descriptor.X2 * canvas.ActualWidth;
                line.Y1 = descriptor.Y1 * canvas.ActualHeight;
                line.Y2 = descriptor.Y2 * canvas.ActualHeight;
            } //if
            if (descriptor.Thickness > 0)
                line.StrokeThickness = descriptor.Thickness;
            line.Stroke = descriptor.Brush;
        } //ArrangeLine

        readonly Canvas canvas;
        readonly Image image;

    } //class Mystification

}
