﻿// Measurements of Earth's Flatness
//
// Copyright (c) Sergey A Kryukov, 2023
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
//
// Original publication:
// https://www.codeproject.com/Articles/5358102/Measurements-of-Earth-Flatness
//
namespace SA.View {
    using System.Windows.Input;
    using System.Windows.Media.Imaging;
    using Path = System.IO.Path;

    public partial class WindowMain {

        internal static void AddKeyGestures() {
            ApplicationCommands.Close.InputGestures.Add(new KeyGesture(Key.F4, ModifierKeys.Alt));
            MediaCommands.Play.InputGestures.Add(new KeyGesture(Key.F5));
            MediaCommands.Stop.InputGestures.Add(new KeyGesture(Key.F5, ModifierKeys.Shift));
        } //AddKeyGestures

        void AddCommandBindings() {

            openDialog.Title = Main.DefinitionSet.Dialog.openDialogTitle;
            openDialog.Filter = Main.DefinitionSet.Dialog.openDialogFilter;
            openDialog.Multiselect = true;

            CommandBindings.Add(new CommandBinding(ApplicationCommands.Open, new ExecutedRoutedEventHandler((sender, eventArgs) => {
                if (openDialog.ShowDialog() != true) return;
                image.Opacity = Main.DefinitionSet.Image.loadOpacity;
                filename = openDialog.FileName;
                bitmapSource = new BitmapImage(new System.Uri(filename, System.UriKind.RelativeOrAbsolute));
                image.Source = bitmapSource;
                string displayFileName = openDialog.FileNames.Length > 1 ? Path.GetDirectoryName(filename) : Path.GetFileName(filename);
                controller.Status = Main.DefinitionSet.Status.Loaded(displayFileName);
                processor.DisplayFilename = displayFileName;
                controller.Result = null;
                ArrangeImage();
            }), new CanExecuteRoutedEventHandler((sender, eventArgs) => {
                eventArgs.CanExecute = processor.ProcessPhase == Main.Processor.Phase.Stopped || processor.ProcessPhase == Main.Processor.Phase.Aborted;
            }))); //Open
            
            CommandBindings.Add(new CommandBinding(ApplicationCommands.Close, new ExecutedRoutedEventHandler((sender, eventArgs) => {
                Close();
            }), new CanExecuteRoutedEventHandler((sender, eventArgs) => {
                eventArgs.CanExecute = true;
            }))); //Close (Quit)

            CommandBindings.Add(new CommandBinding(MediaCommands.Play, new ExecutedRoutedEventHandler((sender, eventArgs) => {
                processor.Start();
            }), new CanExecuteRoutedEventHandler((sender, eventArgs) => {
                eventArgs.CanExecute = processor.ProcessPhase == Main.Processor.Phase.Aborted
                    || (processor.ProcessPhase == Main.Processor.Phase.Stopped && processor.DisplayFilename != null);
            }))); //Play

            CommandBindings.Add(new CommandBinding(MediaCommands.Stop, new ExecutedRoutedEventHandler((sender, eventArgs) => {
                processor.Stop(quit: false);
            }), new CanExecuteRoutedEventHandler((sender, eventArgs) => {
                eventArgs.CanExecute = processor.ProcessPhase == Main.Processor.Phase.Running;
            }))); //Stop

            CommandBindings.Add(new CommandBinding(ApplicationCommands.Help, new ExecutedRoutedEventHandler((sender, eventArgs) => {
                about.ShowOwned(this);
            }), new CanExecuteRoutedEventHandler((sender, eventArgs) => {
                eventArgs.CanExecute = true;
            }))); //Help/About

        } //AddCommandBindings
        readonly Microsoft.Win32.OpenFileDialog openDialog = new();

    } //class WindowMain

}
