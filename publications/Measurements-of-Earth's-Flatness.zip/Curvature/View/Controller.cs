// Measurements of Earth's Flatness
//
// Copyright (c) Sergey A Kryukov, 2023
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
//
// Original publication:
// https://www.codeproject.com/Articles/5358102/Measurements-of-Earth-Flatness
//
namespace SA.View {
    using System.Windows.Controls;
    using System.Windows.Controls.Primitives;
    using DispatcherObject = System.Windows.Threading.DispatcherObject;

    class Controller {

        internal Controller(Canvas canvas, Image image, TextBlock result, StatusBarItem status) {
            this.canvas = canvas;
            this.image = image;
            this.result = result;
            this.status = status;
            mystification = new(canvas, image);
        } //Controller

        internal void ArrangeMystification() { // UI thread only
            mystification.Arrange();
        } //ArrangeMystification
        internal void ClearMystification() {
            Invoke(canvas, new System.Action(() => {
                mystification.Clear();
            }));
        } //ClearMystification

        internal double ImageOpacity {
            set {
                Invoke(image, new System.Action(() => {
                    image.Opacity = value;
                }));
            } //set ImageOpacity
        } //ImageOpacity

        internal void WorkOnMystification(System.Action<Mystification> mystificationHandler) {
            Invoke(canvas, new System.Action(() => {
                mystificationHandler(mystification);
            }));
        } //WorkOnMystification

        internal string Result {
            set {
                Invoke(result, new System.Action(() => {
                    result.Text = value;
                }));
            } //set Result
        } //string Result

        internal string Status {
            set {
                Invoke(status, new System.Action(() => {
                    status.Content = value;
                }));
            } //set Status
        } //string Status

        void Invoke(DispatcherObject @object, System.Action action) {
            if (QuitRequested) return;
            if (@object.Dispatcher.HasShutdownStarted) return;
            @object.Dispatcher.Invoke(action);
        } //Invoke

        internal bool QuitRequested {
            get { lock (lockObject) return quitRequested; }
            set {
                if (value)
                    lock (lockObject) {
                        quitRequested = value;
                    }
            } //set QuitRequested
        } //QuitRequested

        internal void ShowException(System.Exception exception) {
            Result = exception.ToString();
        } //ShowException

        readonly object lockObject = new();
        bool quitRequested;

        readonly Canvas canvas;
        readonly Image image;
        readonly TextBlock result;
        readonly StatusBarItem status;
        readonly Mystification mystification;

    } //class Controller

}
