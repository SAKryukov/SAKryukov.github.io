﻿// Measurements of Earth's Flatness
//
// Copyright (c) Sergey A Kryukov, 2023
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
//
// Original publication:
// https://www.codeproject.com/Articles/5358102/Measurements-of-Earth-Flatness
//
namespace SA.View {
    using System.ComponentModel;
    using System.Windows;
    using System.Windows.Controls;

    public partial class WindowAbout : Window {

        public WindowAbout() {
            InitializeComponent();
            textBlockCongratulations.Text = Main.DefinitionSet.Result.congratulation;
        } //WindowAbout

        internal void ShowOwned(Window owner) {
            Owner = owner;
            ShowDialog();
        } //ShowOwned

        protected override void OnClosing(CancelEventArgs e) {
            base.OnClosing(e);
            e.Cancel = true;
            Hide();
        } //OnClosing

    }
}
