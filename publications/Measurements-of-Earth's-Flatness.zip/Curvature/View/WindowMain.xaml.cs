﻿// Measurements of Earth's Flatness
//
// Copyright (c) Sergey A Kryukov, 2023
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
//
// Original publication:
// https://www.codeproject.com/Articles/5358102/Measurements-of-Earth-Flatness
//
namespace SA.View {
    using System.ComponentModel;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Media.Imaging;

    public partial class WindowMain : Window {

        public WindowMain() {
            InitializeComponent();
            controller = new(canvas, image, textBlockResult, status);
            processor = new(controller);
            AddCommandBindings();
            canvas.SizeChanged += (sender, eventArgs) => {
                scrollViewerResult.Width = canvas.ActualWidth;
                scrollViewerResult.Height = canvas.ActualHeight;
                ArrangeImage();
                controller.ArrangeMystification();
            }; //canvas.SizeChanged
        } //WindowMain

        void ArrangeImage() {
            static void ArrangeImage(BitmapSource bitmap, Image image, Canvas canvas) {
                if (bitmap == null) return;
                double imageAspect = (double)bitmap.Width / (double)bitmap.Height;
                double parentAspect = (double)canvas.ActualWidth / (double)canvas.ActualHeight;
                if (imageAspect > parentAspect) {
                    image.Width = canvas.ActualWidth;
                    image.Height = image.Width / imageAspect;
                    Canvas.SetLeft(image, 0);
                    Canvas.SetTop(image, (canvas.ActualHeight - image.Height) / 2);
                } else {
                    image.Height = canvas.ActualHeight;
                    image.Width = image.Height * imageAspect;
                    Canvas.SetTop(image, 0);
                    Canvas.SetLeft(image, (canvas.ActualWidth - image.Width) / 2);
                } //if
            } //ArrangeImage
            if (image.Source == null) return;
            ArrangeImage(bitmapSource, image, canvas);
        } //ArrangeImage

        protected override void OnClosing(CancelEventArgs e) {
            base.OnClosing(e);
            processor.Stop(quit: true);
        } //OnClosing

        BitmapSource bitmapSource;
        string filename;
        readonly Controller controller;
        readonly Main.Processor processor;
        readonly WindowAbout about = new();

    } //class WindowMain

}
