﻿// Measurements of Earth's Flatness
//
// Copyright (c) Sergey A Kryukov, 2023
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
//
// Original publication:
// https://www.codeproject.com/Articles/5358102/Measurements-of-Earth-Flatness
//
namespace SA.Main {
    using Brush = System.Windows.Media.Brush;
    using Brushes = System.Windows.Media.Brushes;

    static class DefinitionSet {

        internal static class Dialog {
            internal const string openDialogFilter = "Image files|*.webp;*.dng;*.raf;*.tif;*.tiff;*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            internal const string openDialogTitle = " Load Source Image or Set of Time-lapse Images";
        } //class Dialog

        internal static class Status {
            internal static string Loaded(string filename) => $"�{filename}� loaded";
            internal static string Processing(string filename) => $"Processing �{filename}�... Please wait or cancel processing (Shift+F5)...";
            internal static string Processed(string filename) => $"�{filename}� processed";
            internal static string Aborted(string filename) => $"�{filename}� processing aborted";
            internal const string abortedResult = "To find out if your Earth is flat or not, you need more patience!"
                + "\n\nPlease try again (F5) or load new images (Ctrl+O) and then try again";
        } //class Status

        internal static class RandomInput {
            internal const int flatnessDescriptor = 100;
            internal const int flatnessDescriptorCat = 30; // or less
            internal const int flatnessDescriptorFlat = 60; // or more
            internal const double curvatureRadiusFlat = 26.8; // kps
            internal const double curvatureRadiusNormal = 6378; // km
            internal const double curvatureRadiusCat = 35; // sm
            internal const double curvatureRadiusAccuracy = 0.4; // fraction added
        } //class RandomInput

        internal static class Image {
            internal const double loadOpacity = 1;
            internal const double processOpacity = 0.7;
            internal const double processedOpacity = 0.25;
        } //class Image

        internal static class Scenario {
            internal static readonly Brush brushLineDown = Brushes.DarkBlue;
            internal static readonly Brush brushLineUp = Brushes.Red;
            internal static readonly Brush brushPerspective = Brushes.DarkMagenta;
            internal static readonly Brush brushCircleInner = Brushes.Cyan;
            internal static readonly Brush brushCircleOuter = Brushes.Yellow;
            internal const double thicknessLineDown = 1.9;
            internal const double thicknessLineUp = 2.3;
            internal const double thicknessPerspective = 3;
            internal const double thicknessCircle = 3;
            internal const double shapeCenter = 0.5;
            internal const double horizonFinish = 0.7;
            internal const double perspectiveOuterStart = 0;
            internal const double perspectiveCenterStart = 0.5;
            internal const double perspectiveFinish = 1.0/3;
            internal const int stepCount = 900;
            internal const int stepDurationMs = 10;
            internal const int stepOpacityChangePeriod = 90;
            internal const double opacityChangeDepth = 0.3;
            internal const double doubleLineGap = 0.012;
            internal const int circleExpantionAcceleration = 30;
            internal const double circleScaleInner = 0.6;
            internal const double circleScaleOuter = 1;
        } //class Scenario

        internal static class Result {
            const string earthRadiusLegend = "Earth's curvature radius:";
            const string promptReload = "Please load new image file or time-lapse image file set to try again";
            internal static string Flat(double radius) => $"{earthRadiusLegend} {radius:G5} kpc;\nvirtually flat Earth";
            internal static string Normal(double radius) => $"{earthRadiusLegend}  {radius:G5} km";
            internal static string Cat(double radius) => $"This is your fat cat\nRadius: {radius:G5} cm";
            internal const string congratulation = "Congratulations on International Fool's day, April 1st!";
            internal static string Final(string radius) => $"{radius}\n\n{promptReload}\n\n{congratulation}";
        } //class Result

    } //class DefinitionSet

}
