﻿// Measurements of Earth's Flatness
//
// Copyright (c) Sergey A Kryukov, 2023
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
//
// Original publication:
// https://www.codeproject.com/Articles/5358102/Measurements-of-Earth-Flatness
//
namespace SA.Main {

    static class ApplicationStart {
        [System.STAThread]
        static void Main() {
            View.WindowMain.AddKeyGestures();
            new UI.AdvancedApplication<View.WindowMain>().Run();
        } //Main
    } //class ApplicationStart

}

