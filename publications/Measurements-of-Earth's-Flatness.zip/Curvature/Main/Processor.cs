// Measurements of Earth's Flatness
//
// Copyright (c) Sergey A Kryukov, 2023
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
//
// Original publication:
// https://www.codeproject.com/Articles/5358102/Measurements-of-Earth-Flatness
//
namespace SA.Main {
    using Thread = System.Threading.Thread;
    using ThreadInterruptedException = System.Threading.ThreadInterruptedException;
    using AutoResetEvent = System.Threading.AutoResetEvent;

    class Processor {

        internal enum Phase { Stopped, Running, AbortRequested, QuitRequested, Aborted }

        class UserAbortException : System.ApplicationException {
            internal UserAbortException() { }
        } // UserAbortException

        internal Processor(View.Controller controller) {
            this.controller = controller;
            controller.ImageOpacity = DefinitionSet.Image.loadOpacity;
            thread = new(ThreadBody);
            thread.Start();
        } //Processor

        internal void Start() {
            controller.Result = null;
            waiter.Set();
            controller.ImageOpacity = DefinitionSet.Image.processOpacity;
            ProcessPhase = Phase.Running;
        } //Start

        internal void Stop(bool quit = false) {
            controller.ImageOpacity = DefinitionSet.Image.processedOpacity;
            ProcessPhase = Phase.AbortRequested;
            waiter.Set();
            thread.Interrupt();
            if (quit) {
                ProcessPhase = Phase.QuitRequested;
                thread.Join();
            } else
                ProcessPhase = Phase.AbortRequested;
        } //Stop

        void ThreadBody() {
            while (ProcessPhase != Phase.QuitRequested) {
                try {
                    Phase currentPhase = ProcessPhase;
                    if (currentPhase == Phase.AbortRequested || currentPhase == Phase.QuitRequested)
                        throw new UserAbortException();
                    waiter.WaitOne();
                    currentPhase = ProcessPhase;
                    if (currentPhase == Phase.AbortRequested || currentPhase == Phase.QuitRequested)
                        throw new UserAbortException();
                    if (currentPhase == Phase.QuitRequested)
                        break;
                    controller.Status = DefinitionSet.Status.Processing(DisplayFilename);
                    scenario.Run(controller);
                    controller.Status = DefinitionSet.Status.Processed(displayFilename);
                    controller.ImageOpacity = DefinitionSet.Image.processedOpacity;
                    controller.Result = scenario.Result;
                } catch (System.Exception exception) {
                    if (exception is ThreadInterruptedException || exception is UserAbortException) {
                        if (ProcessPhase != Phase.QuitRequested) {
                            ShowAbort();
                            ProcessPhase = Phase.Aborted;
                            waiter.Reset();
                        } else
                            break;
                    } else
                        controller.ShowException(exception);
                } finally {
                    if (ProcessPhase != Phase.QuitRequested) {
                        controller.ClearMystification();
                        if (ProcessPhase != Phase.Aborted)
                            DisplayFilename = null;
                    } //if
                    if (ProcessPhase != Phase.Aborted)
                        ProcessPhase = Phase.Stopped;
                } //exception
            } //loop
        } //ThreadBody

        void ShowAbort() {
            controller.Status = DefinitionSet.Status.Aborted(displayFilename);
            controller.Result = DefinitionSet.Status.abortedResult;
        } //ShowAbort

        readonly Thread thread;
        readonly Scenario scenario = new();
        readonly AutoResetEvent waiter = new(false);
        readonly object lockObject = new();
        readonly View.Controller controller;

        Phase processPhase;
        internal Phase ProcessPhase {
            get { lock (lockObject) return processPhase; }
            set { lock (lockObject) processPhase = value; }
        } //ProcessPhase

        string displayFilename;
        internal string DisplayFilename {
            get { lock (lockObject) return displayFilename; }
            set { lock (lockObject) displayFilename = value; }
        } //DisplayFilename

    } //class Processor

}
