// Measurements of Earth's Flatness
//
// Copyright (c) Sergey A Kryukov, 2023
//
// http://www.SAKryukov.org
// http://www.codeproject.com/Members/SAKryukov
// https://github.com/SAKryukov
//
// Original publication:
// https://www.codeproject.com/Articles/5358102/Measurements-of-Earth-Flatness
//
namespace SA.Main {
   using Thread = System.Threading.Thread;
    using Random = System.Random;
    using Time = System.DateTime;

    class Scenario {

        enum FlattnessResult { Cat, Flat, Normal }

        internal void Run(View.Controller controller) {
            View.Mystification.LineDescriptor lineDown = null;
            View.Mystification.LineDescriptor lineUp = null;
            View.Mystification.LineDescriptor perspectiveLeft = null;
            View.Mystification.LineDescriptor perspectiveRight = null;
            View.Mystification.CircleDescriptor circleInner = null;
            View.Mystification.CircleDescriptor circleOuter = null;
            controller.WorkOnMystification(ms => {
                lineDown = new(ms) { Brush = DefinitionSet.Scenario.brushLineDown, X1 = 0, X2 = 1, Thickness = DefinitionSet.Scenario.thicknessLineDown };
                lineUp = new(ms) { Brush = DefinitionSet.Scenario.brushLineUp, X1 = 0, X2 = 1, Thickness = DefinitionSet.Scenario.thicknessLineUp };
                perspectiveLeft = new(ms) { Brush = DefinitionSet.Scenario.brushPerspective, X1 = 0, X2 = DefinitionSet.Scenario.shapeCenter, Thickness = DefinitionSet.Scenario.thicknessPerspective };
                perspectiveRight = new(ms) { Brush = DefinitionSet.Scenario.brushPerspective, X1 = DefinitionSet.Scenario.shapeCenter, X2 = 1, Thickness = DefinitionSet.Scenario.thicknessPerspective };
                perspectiveLeft.Add();
                perspectiveRight.Add();
                lineDown.Add();
                lineUp.Add();
            });
            int steps = DefinitionSet.Scenario.stepCount;
            for (int step = 0; step <= steps; step++) {
                controller.WorkOnMystification(ms => {
                    lineDown.Y1 = CalculateStep(0, DefinitionSet.Scenario.horizonFinish, step, steps);
                    lineDown.Y2 = lineDown.Y1;
                    lineDown.Move();
                    lineUp.Y1 = CalculateStep(1, DefinitionSet.Scenario.horizonFinish, step, steps);
                    lineUp.Y2 = lineUp.Y1;
                    lineUp.Move();
                    perspectiveLeft.Y1 = CalculateStep(DefinitionSet.Scenario.perspectiveOuterStart, DefinitionSet.Scenario.perspectiveFinish, step, steps);
                    perspectiveLeft.Y2 = CalculateStep(DefinitionSet.Scenario.perspectiveCenterStart, DefinitionSet.Scenario.perspectiveFinish, step, steps);
                    perspectiveLeft.Move();
                    perspectiveRight.Y2 = perspectiveLeft.Y1;
                    perspectiveRight.Y1 = perspectiveLeft.Y2;
                    perspectiveRight.Move();
                });
                if (step % DefinitionSet.Scenario.stepOpacityChangePeriod == 0)
                    controller.ImageOpacity = DefinitionSet.Image.processOpacity + random.NextDouble() * DefinitionSet.Scenario.opacityChangeDepth;
                Thread.Sleep(DefinitionSet.Scenario.stepDurationMs);
            } //loop
            controller.WorkOnMystification(ms => {
                perspectiveLeft.Remove();
                perspectiveRight.Remove();
                circleInner = new(ms) { CenterX = DefinitionSet.Scenario.shapeCenter, CenterY = DefinitionSet.Scenario.shapeCenter,
                    Brush = DefinitionSet.Scenario.brushCircleInner, Thickness = DefinitionSet.Scenario.thicknessCircle };
                circleOuter = new(ms) { CenterX = DefinitionSet.Scenario.shapeCenter, CenterY = DefinitionSet.Scenario.shapeCenter,
                    Brush = DefinitionSet.Scenario.brushCircleOuter, Thickness = DefinitionSet.Scenario.thicknessCircle };
                circleInner.Add();
                circleOuter.Add();
            });
            controller.ImageOpacity = DefinitionSet.Image.processOpacity;
            for (int step = 0; step <= steps; step++) {
                controller.WorkOnMystification(ms => {
                    lineDown.Y1 = CalculateStep(0, 1, step, steps);
                    lineDown.Y2 = lineDown.Y1;
                    lineDown.Move();
                    lineUp.Y1 = lineDown.Y1 + DefinitionSet.Scenario.doubleLineGap;
                    lineUp.Y2 = lineUp.Y1;
                    lineUp.Move();
                    circleInner.Radius = DefinitionSet.Scenario.circleScaleInner * (step * DefinitionSet.Scenario.circleExpantionAcceleration % steps) / steps;
                    circleInner.Move();
                    circleOuter.Radius = DefinitionSet.Scenario.circleScaleOuter * (step * DefinitionSet.Scenario.circleExpantionAcceleration % steps) / steps;
                    circleOuter.Move();
                });
                Thread.Sleep(DefinitionSet.Scenario.stepDurationMs);
            } //loop
            static double CalculateStep(double start, double finish, int step, int steps) {
                double distance = finish - start;
                return start + distance * step / steps;
            } //CalculateStep
            result = CalculateResult();
        } //Run

        string CalculateResult() {
            static double CalculateRadius(double known, double addedRandom, Random random) =>
                known + known * random.NextDouble() * addedRandom;
            int flatnessValue = random.Next(DefinitionSet.RandomInput.flatnessDescriptor);
            FlattnessResult flattness;
            if (flatnessValue < DefinitionSet.RandomInput.flatnessDescriptorCat)
                flattness = FlattnessResult.Cat;
            else if (flatnessValue > DefinitionSet.RandomInput.flatnessDescriptorFlat)
                flattness = FlattnessResult.Flat;
            else
                flattness = FlattnessResult.Normal;
            double randomFactor = random.NextDouble();
            double radius = flattness == FlattnessResult.Flat
                ? randomFactor * CalculateRadius(DefinitionSet.RandomInput.curvatureRadiusFlat, DefinitionSet.RandomInput.curvatureRadiusAccuracy, random)
                : (flattness == FlattnessResult.Cat
                    ? CalculateRadius(DefinitionSet.RandomInput.curvatureRadiusCat, DefinitionSet.RandomInput.curvatureRadiusAccuracy, random)
                    : CalculateRadius(DefinitionSet.RandomInput.curvatureRadiusNormal, DefinitionSet.RandomInput.curvatureRadiusAccuracy, random));
            return DefinitionSet.Result.Final(flattness == FlattnessResult.Flat
                ? DefinitionSet.Result.Flat(radius)
                : (flattness == FlattnessResult.Normal
                    ? DefinitionSet.Result.Normal(radius)
                    : DefinitionSet.Result.Cat(radius)));
        } //CalculateResult

        string result;
        readonly Random random = new(Time.Now.Millisecond);
        internal string Result { get { return result; } }

    }

}
