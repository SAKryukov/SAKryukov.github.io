﻿namespace SAWPFRotatingWindow.Ui {
    using System.Windows;

    public partial class MainWindow : Window {

        public MainWindow() {
            InitializeComponent();
        } //MainWindow

        protected override void OnContentRendered(System.EventArgs e) {
            base.OnContentRendered(e);
            RotatingWindow rotating = new RotatingWindow(this);
            rotating.Top = this.Top;
            rotating.Left = this.Left;
            rotating.Width = this.Width;
            rotating.Height = this.Height;
            this.Visibility = Visibility.Hidden;
            rotating.Show();
        } //OnContentRendered

    } //class MainWindow


} //namespace SAWPFRotatingWindow.Ui
