﻿namespace SAWPFRotatingWindow.Ui {
    using System.Windows;
    using System.Windows.Media;
    using System.Threading;

    static class DefinitionSet {
        internal static int StepCount = 200;
        internal static int RotationCount = 2;
        internal static int Delay = 10;
    } //class DefinitionSet

    public partial class RotatingWindow : Window {

        public RotatingWindow(Window mainWindow) {
            this.mainWindow = mainWindow;
            InitializeComponent();
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            WindowStyle = WindowStyle.None;
        } //class RotatingWindow

        protected override void OnContentRendered(System.EventArgs e) {
            base.OnContentRendered(e);
            ScaleTransform transform = new ScaleTransform(1, 1, this.Width / 2, this.Height);
            grid.RenderTransform = transform;
            thread = new ThreadWrapper(this, mainWindow, transform);
            thread.Start();
        } //OnContentRendered

        ThreadWrapper thread;
        Window mainWindow;

    } //class RotatingWindow

    internal class ThreadWrapper {
        internal ThreadWrapper(Window window, Window mainWindow, ScaleTransform transform) {
            this.transform = transform;
            this.window = window;
            this.mainWindow = mainWindow;
            Thread = new System.Threading.Thread(Body);
        } //ThreadWrapper
        Thread Thread;
        internal void Start() { this.Thread.Start(); }
        void Body() {
            double step = System.Math.PI * DefinitionSet.RotationCount / DefinitionSet.StepCount;
            for (int x = 0; x < DefinitionSet.StepCount * DefinitionSet.RotationCount; ++x) {
                window.Dispatcher.BeginInvoke(new System.Action(() => {
                    transform.ScaleX = System.Math.Cos(x * step);
                }));
                Thread.Sleep(DefinitionSet.Delay);
            } //loop
            window.Dispatcher.BeginInvoke(new System.Action(() => {
                mainWindow.Visibility = Visibility.Visible;
                window.Close();
            }));
        } //Body
        ScaleTransform transform;
        Window window, mainWindow;
    } //class ThreadWrapper

} //namespace SAWPFRotatingWindow.Ui
