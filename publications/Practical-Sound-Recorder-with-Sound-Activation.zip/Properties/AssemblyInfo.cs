﻿/*
Sound Recorder

Copyright (C) by Sergey A Kryukov, 2014
http://www.SAKryukov.org
*/

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Sound Recorder")]
[assembly: AssemblyDescription("Practical Sound Recorder with sound activation")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Sound Recorder")]
[assembly: AssemblyCopyright("© 2014 Sergey A Kryukov")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
