﻿namespace EnumerationDemo {

    enum NamingTest { One, Two, Three, Four, Count = One, }

    enum Status {
        Created = 0,
        Started = 1,
        Running = 2,
        Paused = 3,
        Terminated = 4,
        Invalid = 5,
        Deleted = 6,
        [SA.Universal.Enumerations.NonEnumerable]
        Redundant = 100,
        [SA.Universal.Enumerations.NonEnumerable]
        NonUnique = Paused,
        NonUniqueUsable = Running,
    } //enum Status

    enum CardSuit { Clubs, Diamonds, Spades, Hearts, }

} //namespace EnumerationDemo