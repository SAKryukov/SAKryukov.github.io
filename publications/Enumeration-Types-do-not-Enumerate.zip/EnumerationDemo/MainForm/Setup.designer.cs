/*
    Enumeration demo:
    Generic class Enumeration provides iteration capabilities based on enumeration or any other type with static fields;
    Generic class EnumerationIndexedArray implements enumeration-indexed arrays
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org
*/

using System;
using System.Windows.Forms;

namespace EnumerationDemo {
    using System.Threading;
    using System.IO;

    public partial class FormEnumerationDemo {

        const int padding = 8;
 
        void Setup() {
            Application.ThreadException += delegate(object sender, ThreadExceptionEventArgs e) {
                WriteLine("{0}: {1}", e.Exception.GetType().Name, e.Exception.Message);
            }; //Application.ThreadException
            Text = string.Format(" {0}", Application.ProductName);
            ListBox = new ListBox();
            ListBox.Dock = DockStyle.Fill;
            ListBox.IntegralHeight = false;
            ListBox.HorizontalScrollbar = true;
            this.panelListPad.Controls.Add(ListBox);
            this.panelListPad.Padding = new Padding(padding, padding, 0, padding);
            this.panelTests.Padding = new Padding(padding);
            ListBox.ContextMenuStrip = new ContextMenuStrip();
            SaveFileDialog.DefaultExt = "txt";
            SaveFileDialog.Filter = string.Format("Text files (*.{0})|*.{0}", SaveFileDialog.DefaultExt);
            ListBox.ContextMenuStrip.Items.Add("Save Contents As...").Click += delegate(object sender, EventArgs e) {
                if (SaveFileDialog.ShowDialog() != DialogResult.OK) return;
                StreamWriter writer = new StreamWriter(SaveFileDialog.FileName);
                try {
                    foreach (object item in ListBox.Items)
                        writer.WriteLine(item.ToString());
                } finally {
                    writer.Close();
                } //exception
            }; //ListBox.ContextMenuStrip item click event
            AssignButtons();
        } //Setup

        void WriteLine(string text) {
            if (text == null) text = string.Empty;
            ListBox.Items.Add(text);
            ListBox.SelectedIndex = ListBox.Items.Count - 1;
        } //WriteLine

        void WriteLine(string format, params object[] parameters) { WriteLine(string.Format(format, parameters)); }

        void WriteLine() { WriteLine(null); }

        void Clear() { ListBox.Items.Clear(); }

        Button AddButton(string text) {
            Button btn = new Button();
            btn.Text = text;
            btn.Dock = DockStyle.Bottom;
            Panel spacer = new Panel();
            spacer.Dock = DockStyle.Bottom;
            int lines = text.Split(new char[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries).Length;
            if (lines > 1)
                btn.Height += (btn.Height / 2) * lines;
            spacer.Height = this.panelTests.Padding.Top;
            this.panelTests.Controls.Add(btn);
            this.panelTests.Controls.Add(spacer);
            return btn;
        } //AddButton

        void ShowDeclarationSourceCode() {
            if (DeclarationSourceCode == null) {
                DeclarationSourceCode = new Form();
                this.AddOwnedForm(DeclarationSourceCode);
                TextBox textBox = new TextBox();
                textBox.ReadOnly = true;
                textBox.Dock = DockStyle.Fill;
                textBox.Text = EnumerationDemo.EnumerationDeclaration.SourceCode.Declarations;
                textBox.ScrollBars = ScrollBars.Both;
                textBox.Multiline = true;
                textBox.SelectionLength = 0;
                textBox.SelectionStart = 0;
                textBox.Margin = new Padding(20);
                DeclarationSourceCode.Controls.Add(textBox);
                DeclarationSourceCode.MaximizeBox = false;
                DeclarationSourceCode.MinimizeBox = false;
                DeclarationSourceCode.ShowInTaskbar = false;
                DeclarationSourceCode.Text = string.Format(" {0}: Enum Declarations", Application.ProductName);
                DeclarationSourceCode.FormClosing += delegate(object sender, FormClosingEventArgs e) {
                    if (e.CloseReason == CloseReason.UserClosing) {
                        e.Cancel = true;
                        ((Form)sender).Hide();
                    } //if
                }; //DeclarationSourceCode.FormClosing
            } //if
            DeclarationSourceCode.Show();
            DeclarationSourceCode.BringToFront();
        } //ShowDeclarationSourceCode

        ListBox ListBox;
        Form DeclarationSourceCode;
        SaveFileDialog SaveFileDialog = new SaveFileDialog();

    } //class FormEnumerationDemo

} //namespace EnumerationDemo
