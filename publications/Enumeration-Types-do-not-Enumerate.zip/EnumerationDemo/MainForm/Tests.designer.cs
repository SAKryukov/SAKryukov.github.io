/*
    Enumeration demo:
    Generic class Enumeration provides iteration capabilities based on enumeration or any other type with static fields;
    Generic class EnumerationIndexedArray implements enumeration-indexed arrays
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org
*/

using System;
using System.Windows.Forms;

namespace EnumerationDemo {
    using SA.Universal.Enumerations;
    using Real = System.Double;

    public partial class FormEnumerationDemo {

        void AssignButtons() {
            AddButton("Source &Declarations").Click += delegate(object sender, EventArgs e) { ShowSource(); };
            AddButton("Test &Enumeration").Click += delegate(object sender, EventArgs e) { Clear(); TestEnumeration(); };
            AddButton("Test &Arrays").Click += delegate(object sender, EventArgs e) { Clear(); TestArrays(); };
            AddButton("Test Non-&Iterated Array Index\n(will raise exception)").Click += delegate(object sender, EventArgs e) { Clear(); TestNonIteratedArrayIndex(); };
            AddButton("Test Non-&Unique Array Index").Click += delegate(object sender, EventArgs e) { Clear(); TestNonIteratedNonArrayIndexWithNonUniqueValue(); };
        } //AssignButtons

        void ShowSource() {
            ShowDeclarationSourceCode();
        } //ShowSource

        void TestEnumeration() {
            Enumeration<Status> statusEnumeration = new Enumeration<Status>();
            Enumeration<double> doubleEnumeration = new Enumeration<double>();
            Enumeration<int> intEnumeration = new Enumeration<int>();
            Type underlyingIntegerType = Enum.GetUnderlyingType(typeof(Status));
            WriteLine();
            WriteLine("StatusEnumeration:");
            foreach (EnumerationItem<Status> item in statusEnumeration) {
                object intValue = Convert.ChangeType(item.EnumValue, underlyingIntegerType);
                WriteLine("\t{0}={1}={2}", item.Name, item.EnumValue, intValue);
            } //loop
            WriteLine();
            WriteLine("StatusEnumeration in Reverse:");
            statusEnumeration.IsReverse = true;
            foreach (EnumerationItem<Status> item in statusEnumeration) {
                object intValue = Convert.ChangeType(item.EnumValue, underlyingIntegerType);
                WriteLine("\t{0}={1}={2}", item.Name, item.EnumValue, intValue);
            } //loop
            WriteLine();
            WriteLine("DoubleEnumeration:");
            foreach (EnumerationItem<double> item in doubleEnumeration)
                WriteLine("\t{0}={1}", item.Name, item.Value);
            WriteLine();
            WriteLine("IntEnumeration:");
            foreach (EnumerationItem<int> item in intEnumeration)
                WriteLine("\t{0}={1}", item.Name, item.Value);
            WriteLine(); WriteLine();
        } //TestEnumeration

        void TestArrays() {
            Enumeration<Status> statusEnumeration = new Enumeration<Status>();
            EnumerationIndexedArray<Status, int> IntArray = new EnumerationIndexedArray<Status, int>();
            EnumerationIndexedArray<Status, string> StringArray = new EnumerationIndexedArray<Status, string>();
            foreach (EnumerationItem<Status> item in statusEnumeration)
                StringArray[item.EnumValue] = @"""" + item.EnumValue.ToString() + @" string""";
            foreach (EnumerationItem<Status> item in statusEnumeration)
                IntArray[item.EnumValue] = item.GetHashCode();
            WriteLine("String Array:");
            foreach (EnumerationItem<Status> item in statusEnumeration)
                WriteLine("\tStringArray[{0}] = {1}", item.Name, StringArray[item.EnumValue]);
            WriteLine();
            statusEnumeration.IsReverse = true;
            WriteLine("Int Array, in reverse:");
            foreach (EnumerationItem<Status> item in statusEnumeration)
                WriteLine("\tIntArray[{0}] = {1}", item.Name, IntArray[item.EnumValue]);
            WriteLine(); WriteLine();
        } //TestArrays

        void TestNonIteratedArrayIndex() {
            EnumerationIndexedArray<Status, string> StringArray = new EnumerationIndexedArray<Status, string>();
            Status index = Status.Redundant;
            StringArray[index] = index.ToString();
            WriteLine("{0} enum member is ignored by Enumeration", index);
            WriteLine("Trying to access array by this index: {0}", StringArray[index].ToString());
        } //TestNonIteratedArrayIndex

        void TestNonIteratedNonArrayIndexWithNonUniqueValue() {
            EnumerationIndexedArray<Status, string> StringArray = new EnumerationIndexedArray<Status, string>();
            Status index = Status.NonUnique;
            string realEnumMemberName = "NonUnique"; //there is not access to this name
            StringArray[index] = index.ToString();
            WriteLine("{0} enum member is ignored by Enumeration", realEnumMemberName);
            WriteLine("Trying to access array by this index: {0}", StringArray[index].ToString());
            WriteLine();
            WriteLine("Compare values:");
            WriteLine("\t{0} = {1}", StringArray[index], (int)index);
            WriteLine("\t{0} = {1}", realEnumMemberName, (int)Status.NonUnique);
            WriteLine(); WriteLine();
        } //TestNonIteratedNonArrayIndexWithNonUniqueValue

    } //class FormEnumerationDemo

} //namespace EnumerationDemo