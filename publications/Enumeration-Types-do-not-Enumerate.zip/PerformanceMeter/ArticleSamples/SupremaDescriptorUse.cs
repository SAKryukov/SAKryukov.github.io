﻿/*
    Samples code snippets for article
    "Working around Language Limitations: Making Enumerations Enumerate
     Generic classes for enumeration-based iteration and array indexing"
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org    
*/
namespace JustTests {

    internal class SupremaDescriptorUse {

        enum CardSuit { Clubs, Diamonds, Spades, Hearts, Length, First = 0, Last = Length - 1, }

        internal void IterationSample() {

            for (CardSuit loopVariable = CardSuit.First; loopVariable <= CardSuit.Last; loopVariable++) {
                //use loopVarible
            } //loop CardSuit
            for (CardSuit loopVarible = CardSuit.Last; loopVarible <= CardSuit.First; loopVarible--) {
                //use loopVarible
            } //loop

        } //SupremaDescriptorUse

    } //class SimplestIteration

} //namespace JustTests