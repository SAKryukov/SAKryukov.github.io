﻿/*
    Samples code snippets for article
    "Working around Language Limitations: Making Enumerations Enumerate
     Generic classes for enumeration-based iteration and array indexing"
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org    
*/
namespace JustTests {
    using SA.Universal.Enumerations;

    public enum State { Initial, Running, Paused, Aborted, Finished, }

    public class EmptyTransitionException : System.ApplicationException {
        internal EmptyTransitionException(State from, State to)
            : base(FormatException(from, to)) {
            this.fFrom = from;
            this.fTo = to;
        } //EmptyTransitionException
        static string FormatException(State from, State to) { return string.Format("State transition from {0} to {1} is not allowed", from, to); }
        public State From { get { return fFrom; } }
        public State To { get { return fTo; } }
        State fFrom, fTo;
    } //class EmptyTransitionException

    public delegate void StateTransition(State from, State to);
    
    public abstract class StateMachine {

        public StateMachine() {
            StateGraph[State.Initial, State.Running] = Start;
            StateGraph[State.Running, State.Paused] = Pause;
            StateGraph[State.Paused, State.Running] = Resume;
            StateGraph[State.Running, State.Aborted] = Abort;
            StateGraph[State.Paused, State.Aborted] = Abort;
        } //StateMachine

        public void FireTransition(State from, State to) {
            StateTransition action = StateGraph[from, to];
            if (action == null)
                throw new EmptyTransitionException(from, to);
            else
                action(from, to);
        } //FireTransition

        protected abstract void Start(State from, State to);
        protected abstract void Stop(State from, State to);
        protected abstract void Pause(State from, State to);
        protected abstract void Resume(State from, State to);
        protected abstract void Abort(State from, State to);

        CartesianSquareIndexedArray<State, StateTransition> StateGraph = new CartesianSquareIndexedArray<State, StateTransition>();

    } //class StateMachine

} //namespace JustTests