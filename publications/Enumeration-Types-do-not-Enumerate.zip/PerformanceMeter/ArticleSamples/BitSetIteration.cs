﻿/*
    Samples code snippets for article
    "Working around Language Limitations: Making Enumerations Enumerate
     Generic classes for enumeration-based iteration and array indexing"
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org    
*/
namespace JustTests {

    internal class BitSetIteration {

        enum SearchOptionBitPosition {
            MatchCase, //other case-insensitive
            SearchBackward, //otherwise search forward
            UseRegularExpressions, 
            WholeText, //otherwise start from cursor
            Length,
        } //enum SearchOptionBitPosition

        [System.Flags]
        enum SearchOptions {
            Default = 0,
            MatchCase = 1 << SearchOptionBitPosition.MatchCase,
            SearchBackward = 1 << SearchOptionBitPosition.SearchBackward, //otherwise search forward
            UseRegularExpressions = 1 << SearchOptionBitPosition.UseRegularExpressions,
            WholeText = 1 << SearchOptionBitPosition.WholeText, //otherwise start from cursor
        } //enum SearchOptions

        internal void IterationSample() {

            SearchOptions options = SearchOptions.MatchCase | SearchOptions.UseRegularExpressions;
            bool caseSensitive = (options & SearchOptions.MatchCase) > 0;
            bool ignoreCase = (options & SearchOptions.MatchCase) > 0;

            for (SearchOptionBitPosition loopVariable = 0; loopVariable <= SearchOptionBitPosition.Length; loopVariable++) {
                SearchOptions option = (SearchOptions)(1 << (int)loopVariable);
                //use option and loopVarible
            } //loop CardSuit

        } //LengthDescriptorUse

    } //class BitSetIteration

} //namespace JustTests