﻿/*
    Samples code snippets for article
    "Working around Language Limitations: Making Enumerations Enumerate
     Generic classes for enumeration-based iteration and array indexing"
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org    
*/
namespace JustTests {

    internal class SimplestIteration {

        enum CardSuit { Clubs, Diamonds, Spades, Hearts, }

        internal void IterationSample() {
            for (CardSuit loopVariable = CardSuit.Clubs; loopVariable <= CardSuit.Hearts; loopVariable++) {
                //use loopVarible
            } //loop CardSuit
            for (CardSuit loopVarible = CardSuit.Hearts; loopVarible <= CardSuit.Clubs; loopVarible--) {
                //use loopVarible
            } //loop CardSuit
        } //IterationSample

    } //class SimplestIteration

} //namespace JustTests