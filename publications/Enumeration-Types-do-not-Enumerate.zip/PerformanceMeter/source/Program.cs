﻿/*
    Enumeration Performance Meter:
    Generic class Enumeration provides iteration capabilities based on enumeration or any other type with static fields;
    Generic class EnumerationIndexedArray implements enumeration-indexed arrays
    
    Copyright (C) 2008-2010 by Sergey A Kryukov
    http://www.SAKryukov.org
*/

using System;

namespace PerformanceMeter {
    using EnumerationItem = SA.Universal.Enumerations.EnumerationItem<TestEnumeration>;
    using Enumeration = SA.Universal.Enumerations.Enumeration<TestEnumeration>;
    using ArrayOfDouble = SA.Universal.Enumerations.EnumerationIndexedArray<TestEnumeration, double>;
    using Duration = System.Double;
    
    class Program {

        const int EnumerationCount = 1024;
        const int CycleCount = 1024;
        const string FmtEnumerationMember = "        en{0},";
        const double Nano = 1E+9;

        delegate void TimeAction();
        static void TimeIt(TimeAction initializationAction, TimeAction bodyAction) {
            DateTime start = DateTime.Now;
            initializationAction();
            DateTime initialization = DateTime.Now;
            bodyAction();
            DateTime finish = DateTime.Now;
            TimeSpan initializationSpan = initialization - start;
            TimeSpan iterationSpan = finish - initialization;
            TimeSpan totalSpan = finish - start;
            Duration initializationTime = initializationSpan.TotalSeconds;
            Duration iterationTime = iterationSpan.TotalSeconds;
            Duration totalTime = totalSpan.TotalSeconds;
            Duration accuracy = (initializationTime + iterationTime - totalTime) / totalTime;
            Duration reflectionIteration = initializationTime / EnumerationCount;
            Duration iteration = iterationTime / (EnumerationCount * CycleCount);
            reflectionIteration *= Nano;
            iteration *= Nano;
            WriteLine(
                "initialization: {0} ns; iteration: {1} ns ({2} times)",
                FormatDuration(reflectionIteration),
                FormatDuration(iteration),
                FormatDuration(reflectionIteration / iteration));
        } //TimeIt

        static void GenerateTestEnumDeclaration() {
            for (int index = 1; index <= EnumerationCount; index++)
                WriteLine(FmtEnumerationMember, index);
        } //GenerateTestEnumDeclaration

        static void TimeIterations() {
            Enumeration test = null;
            TimeIt(
                delegate() {
                    test = new Enumeration();
                },
                delegate() {
                    for (int cycle = 1; cycle <= CycleCount; cycle++)
                        foreach (EnumerationItem item in test)
                            Sink = item;
                });
        } //TimeIterations

        static void TimeArray() {
            Enumeration test = null;
            ArrayOfDouble dbl = null; 
            TimeIt(
                delegate() {
                    test = new Enumeration();
                    dbl = new ArrayOfDouble();
                },
                delegate() {
                    for (int cycle = 1; cycle <= CycleCount; cycle++)
                        foreach (EnumerationItem item in test)
                            dbl[item.EnumValue] = 0d;
                });
        } //TimeArray

        static void Measure() {
            WriteLine("Enumeration:");
            TimeIterations();
            WriteLine("\n\rArray:");
            TimeArray();
        } //Measure

        static string FormatDuration(double value) {
            return value.ToString("g3");
        } //FormatDuration

        static void Main(string[] args) {
            //GenerateTestEnumDeclaration();
            Measure();
        } //Main

        static EnumerationItem Sink = null;

        static void WriteLine(string line) { Console.WriteLine(line); }
        static void WriteLine(string format, params object[] parameters) { Console.WriteLine(format, parameters); }

    } //class Program

} //namespace PerformanceMeter 
